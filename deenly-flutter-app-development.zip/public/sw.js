/* Sajidin service worker — app-shell offline cache + notification display.
 *
 * Strategy (deliberately small):
 *  - App shell (the single index.html) and web fonts: cache-first with background refresh, so the
 *    app opens offline once it has been loaded once.
 *  - Everything else (AlAdhan, Al Quran Cloud, Overpass, tiles, audio): network only. Those services
 *    have their own in-app caching (localStorage / IndexedDB / memory) with explicit staleness rules,
 *    and caching location-bearing requests here would silently build a location history.
 *  - Notifications: the page posts {type:"show-notification"} and we display it via
 *    registration.showNotification, which is the only API Android Chrome supports.
 */
const VERSION = "sajidin-shell-v1";
const SHELL = ["./", "./index.html"];
const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(VERSION)
      .then((c) => c.addAll(SHELL).catch(() => undefined))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const isShell = req.mode === "navigate" || (url.origin === self.location.origin && (url.pathname.endsWith("/") || url.pathname.endsWith("/index.html")));
  const isFont = FONT_HOSTS.includes(url.hostname);
  if (!isShell && !isFont) return; // network only for APIs, tiles and audio

  event.respondWith(
    caches.open(VERSION).then(async (cache) => {
      const cached = await cache.match(req, { ignoreSearch: isShell });
      const refresh = fetch(req)
        .then((res) => {
          if (res && (res.ok || res.type === "opaque")) cache.put(isShell ? "./index.html" : req, res.clone());
          return res;
        })
        .catch(() => undefined);
      if (cached) {
        refresh.catch(() => undefined);
        return cached;
      }
      const fresh = await refresh;
      if (fresh) return fresh;
      const fallback = isShell ? await cache.match("./index.html") : undefined;
      return fallback || new Response("Offline", { status: 503, headers: { "Content-Type": "text/plain" } });
    }),
  );
});

self.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || data.type !== "show-notification") return;
  event.waitUntil(self.registration.showNotification(String(data.title || "Sajidin"), { body: String(data.body || ""), tag: data.tag ? String(data.tag) : undefined, silent: false }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      const existing = list.find((c) => "focus" in c);
      return existing ? existing.focus() : self.clients.openWindow("./");
    }),
  );
});
