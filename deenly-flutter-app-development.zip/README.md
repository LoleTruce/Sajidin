# Sajidin — Islamic Companion (Web)

> **Rebrand notice.** This application was previously named *Deenly*. The public brand is now **Sajidin**.
> Internal persistence keys still use the `deenly:` / `deenly_` prefix on purpose — see §0.

**Publisher:** UA Digital Labs · **Model:** free, non-profit, ad-free, no tracking
**Stack:** React 19 · TypeScript · Vite 7 · Tailwind CSS 4 · Framer Motion · Vitest

> This repository is the **web / PWA-style implementation** of the Sajidin specification (the original brief
> targeted Flutter). Every feature is functional — not a mockup — and the visual identity, animation language,
> architecture and acceptance criteria from the brief are implemented for the browser. The app is a single
> self-contained `dist/index.html` and can be wrapped with Capacitor/TWA for store distribution (see §7).

---

## 0. Rebrand: Deenly → Sajidin (what changed, what was kept)

**Changed (user-facing):** `<title>` and meta description, splash and header wordmark, onboarding heading in all five
languages, privacy/explanatory copy (Home, Qibla, prayer settings, account sheet, appearance settings, finder),
notification title (`Sajidin · Fajr`), Media Session album name, share footers, the logo (new original `SajidinMark`,
a sujūd arc — the previous crescent was also original in-house artwork, so no third-party art is carried over),
documentation and test names. All brand strings now come from `src/core/brand.ts`. The installable-app identity
(web manifest `name`/`short_name`, favicon, Apple touch icon, `apple-mobile-web-app-title`) is generated from the
SajidinMark artwork by `scripts/brand-assets.mjs` and inlined into `index.html` on every build — the web analogue of
the Android launcher label and iOS `CFBundleDisplayName`.

**Intentionally preserved (compatibility identifiers, not brand):** localStorage keys `deenly:settings`,
`deenly:prayer-cache`, `deenly:bookmarks`, `deenly:tasbih`, `deenly:quran-prefs`, `deenly:profile:{uid}:appearance`,
`deenly_isFirstLaunch`, `deenly_onboarding_schema`, `deenly_theme_mode`, `deenly_accent_color`,
`deenly_appearance_updated_at`, `deenly_appearance_schema`, `deenly_language`; IndexedDB database `deenly-cache`;
Leaflet CSS class names `deenly-pin` / `deenly-origin` / `deenly-osm-fallback`; the Firestore document path examples.
Renaming these would reset every existing user's theme, language, onboarding flag, bookmarks and counters for zero
user benefit, so **no migration is performed**. A regression test (`brand.test.tsx`) asserts both that no old brand
text renders and that these keys are unchanged and still read correctly.

**Application / bundle identifiers:** this web build has none. For the native wrapper, the previously documented
Android ID `com.uadigitallabs.deenly` is *not* changed here: if the app has been published or connected to
Firebase/OAuth/push, changing it would create a different app in the stores and break updates. If it has never
shipped, pick `com.uadigitallabs.sajidin` **before** the first release and update the Capacitor config, Firebase
project apps, OAuth redirect URIs and associated domains together.

**Remaining manual actions (outside this repository):** store listings and screenshots; Firebase/OAuth consent-screen
app name and sender name for any auth emails; domain/support URLs; any marketing material. This is a technical
rebrand only and does not constitute trademark or copyright clearance.

## 1. Features

| Tab | What works |
| --- | --- |
| **Home** | AlAdhan prayer times (device location *or* manual city/country), timezone/DST-aware epoch conversion, live HH:MM:SS countdown isolated from the rest of the tree, next-prayer highlight & progress, Hijri date, 19 calculation methods, cached times with explicit *stale* banner, Hadith of the Day (Sahih collections, references, grades, bookmark & share), prayer reminders via the Web Notifications API with per-prayer toggles and lead time. |
| **Quran** | All 114 Surahs from Al Quran Cloud (Tanzil Uthmani text), search by name/number/Arabic, skeleton/empty/error/retry states, verse-by-verse reader (RTL Arabic, adjustable size, 4 translations, transliteration, optional side-by-side on wide screens), ayah bookmarks, reading-progress tracking (IntersectionObserver), persistent mini-player with play/pause/prev/next/seek, 5 reciters, buffering + retry, Media Session lock-screen controls, auto-scroll to the recited ayah, IndexedDB caching of visited Surahs for offline reading. |
| **Qibla** | Great-circle bearing to the Kaaba computed locally in TypeScript (no network), haversine distance, fused device heading (`webkitCompassHeading` on iOS, `deviceorientationabsolute` on Android) with screen-rotation compensation, wrap-aware low-pass filter, spring-animated dial, magnetic-declination setting for true north, configurable tolerance with hysteresis, background `#121214 → #00B388` transition, **single** haptic on entering alignment, calibration / denied / unsupported / no-data guidance. |
| **Tools** | Digital Tasbih (pointer-event counting so rapid taps are never lost, ripple + scale animation, SVG progress ring, presets 33/99/100/1000 + custom target, round celebration, confirm-guarded reset, persistence), Daily Duas from Hisn al-Muslim (8 categories, search, bookmark, copy, share, references). |

Cross-cutting: splash animation, custom 4-tab bottom nav with layout-animated indicator, browser/hardware **back button** support via `history.pushState`, reduced-motion respect, optional haptics (user toggle), screen-reader labels/roles, safe-area insets, toast system, app-shell service worker (`public/sw.js`: offline shell + notification display; APIs are never cached by it), 96 automated tests.

## 1b. Appearance & Customization engine

A central theme engine lets users switch **Dark / Light / Sepia** and pick one of four accents
(**Mint Emerald `#00B388`**, Royal Blue `#2F60FF`, Warm Amber Gold `#D4AF37`, Deep Orchid Purple `#8A2BE2`)
from **Home ▸ palette icon** or **Tools ▸ palette icon** → *Appearance & Customization*.

### How it works
```
src/theme/
  tokens.ts       ThemeMode / AccentId enums, mode surfaces, accent palette, resolveTheme() → CSS vars (memoised)
  color.ts        WCAG contrast, ensureContrast(), pickOnColor()  (keeps accents legible on every surface)
  preferences.ts  versioned keys deenly_theme_mode / deenly_accent_color / deenly_appearance_updated_at, safe parsing
  apply.ts        writes tokens + data-theme/data-accent + color-scheme + <meta theme-color> onto <html>
  themeStore.ts   single source of truth (themeController.setThemeMode / setAccent / resetToDefaults / init / applyRemote)
  sync.ts         authSession integration point, AppearanceSyncService, LocalProfileAdapter, parseCloudDoc
src/features/settings/CustomizationSettings.tsx   the settings screen (mode cards, swatches, live preview, sync status, confirmed reset)
```
* **Design tokens.** `index.css` declares Tailwind colours via `@theme inline` pointing at runtime custom
  properties (`--t-bg`, `--t-card`, `--t-brand`, `--t-brand-ink`, `--t-on-brand`, …). Every component uses
  `bg-card`, `text-brand-ink`, `bg-brand text-on-brand`, `border-line`, etc. — **no hardcoded hex in screens**.
  Changing a theme updates ~20 properties on `<html>`; the browser restyles everything, **zero React re-renders**
  outside the settings screen (hooks are selector-based: `useThemeMode()`, `useAccent()`).
* **Root wiring.** `main.tsx` calls `themeController.init()` *before* `createRoot(...).render` — a synchronous
  localStorage read + DOM apply, so the first paint is already the user's theme. Corrupt/missing values fall back
  field-by-field to Dark + Mint; a throwing storage backend is tolerated (in-memory only, surfaced in the UI).
  `App.tsx` owns the `appearance` route (history-integrated, so back works) and routes the Qibla "aligned"
  status-bar colour through `themeController.reapply()`.
* **Sepia** is a first-class mode (`#F4ECD8` background, cream cards, warm-brown ink, slightly heavier Arabic) —
  not a remapped light theme. It is described in-app as a warm reading option, not a medical treatment.
* **Accents** are applied as the exact hex for fills (`--t-brand`) with a contrast-corrected variant for text
  (`--t-brand-ink`) and an automatically chosen on-accent foreground (`--t-on-brand`). Tests assert ≥ 4.5:1 for
  all 12 mode × accent combinations.

### Top header, Account sheet & Settings navigation
The app shell (`App.tsx`) renders a single persistent **`TopBar`** (`components/TopBar.tsx`) on the four tab roots:
Sajidin wordmark (white, mint dot) on the left; **Account** and **Settings** icon actions (48 × 48 targets, tooltips,
accent tint on hover/press/focus only) on the right. Full-screen routes (Surah reader, Appearance) keep their own
back headers, so the header never stacks. It inverts onto the accent while aligned to the Qibla, like the bottom nav.

* **Settings** → pushes the existing *Appearance & Customization* route (history-integrated; back returns to the
  same tab and tool; repeated taps are de-duplicated by `navigate`).
* **Account** → `features/account/AccountSheet.tsx`, a modal sheet showing the **real** session from
  `src/auth/session.ts`, the **real** appearance-sync status from the theme store, and on-device data counts.
  *Log out* confirms, shows a loading state, blocks duplicate requests, surfaces failures, and ends only the session —
  theme preferences, bookmarks and counters are untouched (tested). When signed out it shows *Sign in* **only if** a
  provider is registered; otherwise an honest "Accounts aren't available in this build" state. Nothing is fabricated.

### Authentication integration point
This web build ships **without** an identity provider (privacy-first). `src/auth/session.ts` holds the session state
and a registration point; wire a real provider like so:

```ts
import { registerAuthProvider, authActions, authSession } from "./theme"; // re-exported from src/auth/session
// Firebase example
registerAuthProvider({ signIn: () => signInWithPopup(auth, new GoogleAuthProvider()).then(() => {}), signOut: () => signOut(auth) });
onAuthStateChanged(auth, (u) => (u ? authActions.setSignedIn({ uid: u.uid, displayName: u.displayName, email: u.email }) : authActions.setSignedOut()));
```
`authSession.uid` drives the appearance sync service below.
`AppearanceSyncService` reacts to `authSession` and to local theme changes:

| Situation | Behaviour |
| --- | --- |
| Signed out | Everything works; saved locally only (`sync: signed-out`). |
| Sign in, cloud record exists & is newer | Cloud prefs applied (not echoed back). |
| Sign in, no record / invalid identifiers / local newer | Local prefs uploaded. |
| Change while signed in | UI + local first; debounced (400 ms) write with the uid captured at change time. |
| Sign out / account switch before write | Queued write **dropped**; local appearance preserved; new uid gets the current local prefs, never a stale queue. |
| Write fails / offline | `pending` with message; retried on `online` event, next sign-in of the same uid, or *Sync now*. |

**Conflict policy: last-write-wins by `updatedAt`** (local `updatedAt` is set on every user change; the cloud
timestamp is read from the document). Ties favour the cloud record so a fresh device converges to the profile.

**Document structure** (`users/{uid}/preferences/appearance`):
```json
{ "themeMode": "dark" | "light" | "sepia", "accentColor": "mint" | "blue" | "amber" | "orchid", "updatedAt": <serverTimestamp> }
```
Default adapter: `LocalProfileAdapter` (per-uid record in localStorage, same shape) so the logic is testable now.
Firestore adapter (drop-in, modular SDK — install `firebase` and pass it to `new AppearanceSyncService({ adapter })`):
```ts
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
export class FirestoreAppearanceAdapter implements AppearanceSyncAdapter {
  constructor(private db: Firestore) {}
  async read(uid: string) { const s = await getDoc(doc(this.db, "users", uid, "preferences", "appearance")); return s.exists() ? s.data() : null; }
  async write(uid: string, p: AppearancePrefs) {
    await setDoc(doc(this.db, "users", uid, "preferences", "appearance"),
      { themeMode: p.mode, accentColor: p.accent, updatedAt: serverTimestamp(), clientUpdatedAt: p.updatedAt }, { merge: true });
  }
}
```
Security rules (users may read/write only their own appearance document; identifiers validated server-side):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /users/{uid}/preferences/appearance {
      allow read: if request.auth != null && request.auth.uid == uid;
      allow write: if request.auth != null && request.auth.uid == uid
        && request.resource.data.themeMode in ['dark', 'light', 'sepia']
        && request.resource.data.accentColor in ['mint', 'blue', 'amber', 'orchid'];
    }
  }
}
```
No credentials live in the client; the UID (never the email) identifies the profile.

### Verification (run in this environment)
`npm test` → 50 tests pass, including `theme.test.ts` (contrast for every combination, parsing/persistence,
restart restore, reset, debounce, account isolation, last-write-wins, offline retry) and an end-to-end widget test
that opens the settings screen, switches to Sepia + Royal Blue, checks `<html>` tokens and localStorage, and resets via
the confirmation dialog. `npm run build` succeeds.

## 1d. First-launch onboarding wizard

On a genuinely fresh install `App` renders `features/onboarding/OnboardingWizard.tsx` instead of the main shell.
The decision is made **synchronously before the first render** from `deenly_isFirstLaunch` (`readLaunchState()`),
so the shell never flashes behind the wizard. A failed storage read is reported as `storage-error` → the wizard runs
with a visible warning; it is *never* treated as "setup already done". Installs that pre-date the wizard
(`deenly:settings.hasSeenWelcome === true`) are migrated to *completed* so existing users are not re-onboarded.

| Step | What it does |
| --- | --- |
| **Welcome** | Logo, "Welcome to Sajidin", "Your premium, privacy-first Deen companion.", **Get Started**. No permissions or network. |
| **Language** | English · العربية · اردو · Türkçe · Bahasa Indonesia as radio cards (mint border + check). Applied immediately (`<html lang/dir>`), persisted as `deenly_language`, and the Quran reader's default translation follows it (verified editions: `ur.jalandhry`, `tr.diyanet`, `id.indonesian`; Arabic keeps the Arabic text with Saheeh International). **Scope is stated honestly in-app**: the wizard and navigation labels are translated; other screens are English. |
| **Location** | "Set Your Location" with the required copy plus a concrete privacy note (Qibla on-device; prayer times fetched from AlAdhan, which receives approximate coordinates/city + method). **Enable Device Location** runs the real browser permission prompt (Permissions API consulted first so a blocked state routes to site settings instead of re-prompting); coordinates are validated. Manual fallback: searchable **country** (252) → **city** (6,366 GeoNames cities ≥100k + capitals, CC BY 4.0, bundled offline) with an **online lookup** for other cities via the existing AlAdhan `timingsByCity` (coordinates come back in its metadata). A regional **calculation-method default** is derived from the country (`lib/calculationDefaults.ts`, e.g. US→ISNA, TR→Diyanet, PK→Karachi, else MWL) and is editable here and later in Prayer settings. |

**Complete Setup** validates → persists language → writes location + method into the existing `settingsStore`
(the same store Home/Qibla read) → sets the Quran edition → verifies the writes round-trip → *only then* writes
`deenly_isFirstLaunch=false`. Any failure shows a friendly, localised error and leaves the flag unset. "Continue
without location" is offered because the existing Home and Qibla screens already handle a missing location.
Swipe or Back/Next between steps; selections survive going backwards; duplicate taps are guarded.

Prayer-time maths is **not** done locally in this build (AlAdhan is the existing engine and is used as such); Qibla
bearing is local. Regenerate the dataset: download GeoNames `cities15000.zip` + `countryInfo.txt`, filter
population ≥ 100k or `PPLC`, emit `[name, cc, lat, lng, popK, capital]` (see `src/data/GEO_LICENSE.md`).

## 1e. Halal Places & Masjid Finder (Tools tab)

`features/finder/` — opened from a card at the top of the Tools tab (full-screen route `screen: "finder"`,
history-integrated back). Files: `nearbyPlace.ts` (model, haversine, formatting), `halalFinderService.ts`
(Overpass QL builder, untrusted-JSON parser, endpoint fallback, bounded in-memory cache, OSRM walking route,
navigation URLs), `useFinder.ts` (screen state, stale-response guards, abort on unmount), `FinderMap.tsx`
(Leaflet + CARTO Dark Matter tiles, inline-SVG pins, auto-fit, recenter), `HalalFinderView.tsx` (category
selector, overlays, detail card, manual city sheet, privacy sheet).

**Data & services — all called directly from the device over HTTPS, no Sajidin backend exists:**

| Service | What it receives | Notes |
| --- | --- | --- |
| Overpass API (`overpass-api.de`, fallback `overpass.kumi.systems`) | query coordinates, 5 km radius, tags | `credentials: omit`, no referrer, 25 s server timeout, one fallback on 429/5xx. **Verified live.** |
| CARTO basemaps (`basemaps.cartocdn.com/dark_all`) + OSM fallback | tile x/y/z | OSM + CARTO attribution rendered; CARTO terms allow non-commercial use. **Verified live.** |
| OSRM demo (`router.project-osrm.org`, foot) | origin + venue coords, only when a card is opened | Community demo server; falls back to straight-line with an explicit note. **Verified live.** |
| User's maps app | venue coordinates on *Navigate* | Google Maps universal URL / Apple Maps on iOS / OSM directions fallback. |

**Tags.** Mosques: `amenity=place_of_worship` + `religion~"^(muslim|islam)$"` — live checks showed OSM uses
`religion=muslim` (36 hits in central London vs **0** for `islam`), so both are matched. Halal: union of
`diet:halal=yes`, `cuisine~halal`, `name~"[Hh]alal"`; results are de-duplicated by `type/id` and the matched rule is
shown ("matched by name only"). Nodes use `lat/lon`; ways/relations use `out center`. Elements without usable
coordinates are skipped; names/addresses/hours are shown only when present (unnamed → "Unnamed mosque").
All venue text is rendered as plain text (control characters stripped, non-http(s) websites dropped).

**Privacy.** Origin, results and selection live only in component state plus a 12-entry / 10-minute **memory**
cache (never written to storage; *Clear cached results* in the ⓘ sheet). The finder seeds its origin from the
location the user already set for prayer times (if any) and otherwise asks — explaining first — via the browser's
permission prompt, with manual city selection (bundled GeoNames dataset, no lookup request) as the fallback.
A test asserts that every request carrying coordinates targets Overpass/AlAdhan only.

**Verified:** 14 finder tests (query shape, parser edge cases, 429 fallback, cache bounds, OSRM parsing, URL
encoding, Tools integration, category switching clears stale results). **Not verified here:** real device GPS,
opening a native maps app, and behaviour under Overpass rate limiting at scale.

## 2. Project structure

```
src/
  App.tsx                     – shell, routing (tabs + history), splash, welcome/privacy sheet
  core/   store.ts            – typed external store (useSyncExternalStore) + localStorage persistence
          motion.ts           – shared animation tokens (200–350 ms, easeOutCubic)
          haptics.ts          – Vibration API wrapper
  lib/    qibla.ts            – bearing / distance / angle math (pure, tested)
          prayer.ts           – timezone resolution, next-prayer, countdown (pure, tested)
  services/ http.ts           – fetch + timeout + error classification
            aladhan.ts        – prayer-times client & parser
            quranApi.ts       – Surah list / content client, audio URLs, IndexedDB cache
            geolocation.ts    – device location with typed errors
            compass.ts        – DeviceOrientation heading provider (iOS permission flow)
            notifications.ts  – Web Notifications scheduling
            idb.ts            – IndexedDB key/value helper
  state/  stores.ts           – settings, prayer cache, bookmarks, tasbih, quran prefs
          audio.ts            – singleton audio engine + Media Session
  data/   hadiths.ts, duas.ts – curated content with primary-source references
  components/ ui.tsx, BottomNav.tsx, Splash.tsx
  features/ home | quran | qibla | tools
  __tests__/                  – vitest unit + widget tests
```

## 3. Setup

```bash
# Node 20+ recommended
npm install
npm run dev        # http://localhost:5173
npm test           # vitest (unit + widget tests)
npm run build      # produces dist/index.html (single-file)
npm run preview    # serve the production build
```

### API configuration
No API keys are required:

* **AlAdhan** (`https://api.aladhan.com/v1/timings`, `/timingsByCity`) — public, documented, no auth.
* **Al Quran Cloud** (`https://api.alquran.cloud/v1/surah`, `/surah/{n}/editions/...`) — public, no auth; Arabic is the Tanzil Uthmani text.
* **Islamic Network CDN** (`https://cdn.islamic.network/quran/audio/128/{reciter}/{ayah}.mp3`) — public recitation audio.

If you prefer the Quran Foundation (Quran.com) API, it requires OAuth2 client credentials; keep them server-side (a small proxy) rather than in the bundle, then point `services/quranApi.ts` at the proxy.

## 4. Permissions & platform behaviour

| Capability | How it's requested | Notes |
| --- | --- | --- |
| Location | Only when the user taps *Use my current location* | Coordinates stay on-device; manual city entry is always available. |
| Notifications | Only when the user enables reminders | Browsers cannot run timers for closed pages: reminders fire while Sajidin is open or backgrounded (install to home screen for best results). No Adhan audio is claimed or played. |
| Motion & orientation | iOS requires a user tap (*Start compass*); Android starts automatically | Headings are magnetic; set declination in compass settings for true north. Desktop browsers have no compass — the numeric bearing is still shown. |
| Vibration | Never prompts | iOS Safari doesn't implement `navigator.vibrate`; it no-ops there. |

## 5. Testing

```bash
npm test
```
* `qibla.test.ts` — bearing accuracy for 5 cities, normalisation, wrap-aware delta/filter, alignment tolerance.
* `prayer.test.ts` — DST-aware offset resolution, HH:MM→epoch, next-prayer transitions incl. post-Isha rollover, countdown formatting, AlAdhan parsing + malformed-response rejection.
* `stores.test.ts` — Tasbih increment/wrap/reset, persistence round-trip, subscriber semantics, Quran parser alignment checks, dataset reference integrity.
* `app.test.tsx` — renders the app, navigates all four tabs, verifies offline error/retry state, counts Tasbih taps and checks localStorage persistence.

## 5b. Production-readiness audit (latest)

Performed against this web build: static sweeps (TODO/FIXME/mock markers, hardcoded colours, non-null assertions,
console logging, unused dependencies), a full journey test with successful data on every primary surface, and a
bundle external-host inventory. Findings fixed in this pass:

| Severity | Area | Finding → fix |
| --- | --- | --- |
| High | Notifications (`services/notifications.ts`) | `new Notification()` throws on Android Chrome, so reminders silently never showed there → display via the service worker (`registration.showNotification`) with page-API fallback; settings sheet now states when neither path exists. |
| High | Offline claim (README / `public/sw.js`) | No service worker existed, so the app shell could not load offline despite data caches → added a minimal app-shell SW (shell + fonts only; APIs, tiles and audio are deliberately *not* cached to avoid a location history). Registration is non-fatal. |
| Medium | Haptics (`core/haptics.ts`, settings) | No way to disable vibration; a dead `reduceMotion` setting existed → added persisted `hapticsEnabled` with a toggle (hidden as unsupported where `navigator.vibrate` is absent); all calls are try/catch no-ops; dead field removed. |
| Medium | Privacy policy | Google Fonts (and the CARTO/OSRM hosts) were missing from the policy template → template rebuilt from the actual bundle host inventory. |
| Low | Accessibility (`tools/Duas.tsx`) | Dua category chip "Home" shared its accessible name with the Home tab → chips now carry `aria-label="<Category> duas"`. |

Verified clean: no placeholder/mock markers, no `console.*`, zero hardcoded colours outside the brand pin SVGs,
all five dependencies in use, zero runtime console errors across the journey test, 96/96 tests, production build OK.

## 6. Known limitations

* Web notifications are not an OS-level alarm; see §4.
* Magnetic declination must be entered manually (no bundled World Magnetic Model).
* Audio caching for offline listening is not performed (streamed per ayah) pending licence review of the CDN terms.
* Hadith of the Day uses a curated verified set rather than a live API; extend `data/hadiths.ts` with additional referenced entries as needed.

## 7. Shipping to app stores (optional)

The build is a static bundle; wrap it with **Capacitor** to obtain native local notifications, true background audio and store listings. Choose the application ID per §0: keep the previously documented `com.uadigitallabs.deenly` **only** if that ID has already been published or bound to Firebase/OAuth/push; otherwise register `com.uadigitallabs.sajidin` before the first release. Set the native display name to **Sajidin** in `AndroidManifest.xml` (`android:label`) and `Info.plist` (`CFBundleDisplayName`), and regenerate launcher icons from the `SajidinMark` artwork (`scripts/brand-assets.mjs` holds the fixed-colour SVG). Native plugins to swap in: `@capacitor/local-notifications`, `@capacitor/geolocation`, `@capacitor/haptics`, `@capacitor/motion`.

## 8. Privacy policy (template for UA Digital Labs to review)

> **Sajidin Privacy Policy (draft)** — Sajidin has no accounts, no analytics and no Sajidin-operated servers.
> Everything you save (bookmarks, counters, prayer settings, appearance, language) is stored on your device.
>
> **Third-party services contacted directly by your device** (each receives your IP address and the request shown):
> - **AlAdhan** (api.aladhan.com) — your approximate coordinates *or* city name, date and calculation method, to fetch prayer times.
> - **Al Quran Cloud** (api.alquran.cloud) and **Islamic Network CDN** (cdn.islamic.network) — Surah/edition identifiers, to load Quran text and recitation audio.
> - **OpenStreetMap Overpass** (overpass-api.de; fallback overpass.kumi.systems) — search coordinates, 5 km radius and venue tags, only when you use the Halal Places & Masjid Finder.
> - **CARTO** (basemaps.cartocdn.com) and **OpenStreetMap tiles** (tile.openstreetmap.org) — map tile positions for the area you view in the finder.
> - **OSRM demo router** (router.project-osrm.org) — origin and venue coordinates, only when you open a venue card.
> - **Google Fonts** (fonts.googleapis.com, fonts.gstatic.com) — font file requests when the interface loads.
> - **Your maps app / Google Maps / Apple Maps / openstreetmap.org** — a venue's coordinates when you tap Navigate.
>
> Location is requested only when you use prayer times, Qibla or the finder, and can always be replaced by a manually chosen city. Notifications and motion sensors are optional. Nothing is sold or shared for advertising. Contact: *[publisher email]*.

## 9. Content attribution

Quran Arabic text: Tanzil Project (Uthmani). Translations: Saheeh International, Muhammad Asad, Pickthall, Yusuf Ali via Al Quran Cloud. Recitations: Islamic Network CDN. Hadith: Sahih al-Bukhari, Sahih Muslim, Jami` at-Tirmidhi (references shown in-app). Duas: Hisn al-Muslim with primary hadith references.
