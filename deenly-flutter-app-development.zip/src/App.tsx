import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { useCallback, useEffect, useRef, useState } from "react";
import { BottomNav, type Tab } from "./components/BottomNav";
import { TopBar } from "./components/TopBar";
import { Splash } from "./components/Splash";
import { SajidinMark, ToastProvider } from "./components/ui";
import { screenVariants } from "./core/motion";
import { useAuthSession } from "./auth/session";
import { AccountSheet } from "./features/account/AccountSheet";
import { HomeScreen } from "./features/home/HomeScreen";
import { AudioPlayer } from "./features/quran/AudioPlayer";
import { QuranScreen } from "./features/quran/QuranScreen";
import { QiblaScreen } from "./features/qibla/QiblaScreen";
import { CustomizationSettings } from "./features/settings/CustomizationSettings";
import { ToolsScreen, type Tool } from "./features/tools/ToolsScreen";
import { HalalFinderView } from "./features/finder/HalalFinderView";
import { OnboardingWizard } from "./features/onboarding/OnboardingWizard";
import { readLaunchState, type LaunchState } from "./features/onboarding/onboardingStore";
import { useLanguage } from "./i18n";
import { themeController, useAccent, useThemeMode } from "./theme/themeStore";
import { resolveTheme } from "./theme/tokens";
import { cn } from "./utils/cn";

export type Screen = "main" | "appearance" | "finder";

interface Route {
  tab: Tab;
  surah: number | null;
  tool: Tool;
  screen: Screen;
}

const DEFAULT_ROUTE: Route = { tab: "home", surah: null, tool: "tasbih", screen: "main" };

function readRoute(): Route {
  const st = window.history.state as Partial<Route> | null;
  return { ...DEFAULT_ROUTE, ...(st ?? {}) };
}

function sameRoute(a: Route, b: Route) {
  return a.tab === b.tab && a.surah === b.surah && a.tool === b.tool && a.screen === b.screen;
}

/** The existing main application shell (tabs, header, player, account sheet). Unchanged behaviour. */
function MainShell() {
  const [route, setRoute] = useState<Route>(() => readRoute());
  const [aligned, setAligned] = useState(false);
  const mode = useThemeMode();
  const accent = useAccent();
  const [accountOpen, setAccountOpen] = useState(false);
  const authStatus = useAuthSession().status;
  const routeRef = useRef(route);
  routeRef.current = route;

  /** Push a new route into history so the hardware/browser back button navigates within the app. */
  const navigate = useCallback((patch: Partial<Route>, replace = false) => {
    const prev = routeRef.current;
    const next = { ...prev, ...patch };
    if (sameRoute(prev, next)) return;
    if (replace) window.history.replaceState(next, "");
    else window.history.pushState(next, "");
    routeRef.current = next;
    setRoute(next);
  }, []);

  useEffect(() => {
    window.history.replaceState(route, "");
    const onPop = () => setRoute(readRoute());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Status-bar / browser-chrome colour: accent while aligned to the Qibla, otherwise the theme background.
  const showAligned = aligned && route.tab === "qibla" && route.screen === "main";
  useEffect(() => {
    themeController.reapply(showAligned ? resolveTheme(mode, accent).vars["--t-brand"] : undefined);
  }, [showAligned, mode, accent]);

  // Taps on the already-active tab are ignored by BottomNav, and `navigate` drops identical routes,
  // so repeated taps never create duplicate history entries.
  const onTab = (tab: Tab) => navigate({ tab, screen: "main" });
  // `navigate` ignores identical routes, so rapid taps on Settings push the screen once.
  const openAppearance = () => {
    setAccountOpen(false);
    navigate({ screen: "appearance" });
  };
  const closeAppearance = () => navigate({ screen: "main" });
  const openFinder = () => navigate({ screen: "finder" });
  const closeFinder = () => navigate({ screen: "main" });
  // The shell header is shown on the four primary tab roots; full-screen routes (Surah reader,
  // Appearance) provide their own back-navigation headers.
  const showShellHeader = route.screen === "main" && !(route.tab === "quran" && route.surah !== null);

  return (
    <div className={cn("min-h-[100dvh] transition-colors duration-500", showAligned ? "bg-brand" : "bg-bg")}>
          {showShellHeader && <TopBar onAccount={() => setAccountOpen(true)} onSettings={openAppearance} inverted={showAligned} accountBadge={authStatus === "signed-in"} />}
          <main id="main" className="relative">
            <AnimatePresence mode="wait" initial={false}>
              {route.screen === "appearance" ? (
                <motion.div key="appearance" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <CustomizationSettings onBack={closeAppearance} />
                </motion.div>
              ) : route.screen === "finder" ? (
                <motion.div key="finder" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <HalalFinderView onBack={closeFinder} />
                </motion.div>
              ) : route.tab === "home" ? (
                <motion.div key="home" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <HomeScreen onNavigate={(tab, payload) => navigate({ tab, surah: payload?.surah ?? (tab === "quran" ? null : route.surah), tool: payload?.tool ?? route.tool })} />
                </motion.div>
              ) : route.tab === "quran" ? (
                <motion.div key="quran" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <QuranScreen surah={route.surah} onSelectSurah={(n) => navigate({ surah: n })} />
                </motion.div>
              ) : route.tab === "qibla" ? (
                <motion.div key="qibla" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <QiblaScreen onAlignedChange={setAligned} />
                </motion.div>
              ) : (
                <motion.div key="tools" variants={screenVariants} initial="initial" animate="animate" exit="exit">
                  <ToolsScreen tool={route.tool} onChangeTool={(tool) => navigate({ tool }, true)} onOpenFinder={openFinder} />
                </motion.div>
              )}
            </AnimatePresence>
          </main>

          <AudioPlayer />
          <AccountSheet open={accountOpen} onClose={() => setAccountOpen(false)} onOpenSettings={openAppearance} />
          {route.screen === "main" && <BottomNav active={route.tab} onChange={onTab} inverted={showAligned} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Root: loading → onboarding (first launch) → main shell              */
/* ------------------------------------------------------------------ */

/**
 * Single application root. The launch state is read synchronously from persistent storage in
 * the initial state function, so the correct screen is chosen before the first paint — the main
 * shell never flashes behind the wizard. A `storage-error` result runs onboarding (we never treat a
 * failed read as proof that setup is done) and warns that settings may not persist.
 */
export default function App() {
  const [splashDone, setSplashDone] = useState(false);
  const [launch, setLaunch] = useState<LaunchState | null>(() => {
    try {
      return readLaunchState();
    } catch {
      return { kind: "storage-error" };
    }
  });
  useLanguage(); // re-render the root when the language (and <html dir>) changes

  useEffect(() => {
    if (launch === null) setLaunch(readLaunchState());
  }, [launch]);

  const showOnboarding = launch?.kind === "first-launch" || launch?.kind === "storage-error";

  return (
    <MotionConfig reducedMotion="user">
      <ToastProvider>
        {launch === null ? (
          <LoadingRoot />
        ) : showOnboarding ? (
          <OnboardingWizard storageWarning={launch.kind === "storage-error"} onComplete={() => setLaunch({ kind: "completed" })} />
        ) : (
          <MainShell />
        )}
        <AnimatePresence>{!splashDone && <Splash onDone={() => setSplashDone(true)} />}</AnimatePresence>
      </ToastProvider>
    </MotionConfig>
  );
}

/** Minimal, layout-stable loading surface shown only if launch state is still being resolved. */
function LoadingRoot() {
  return (
    <div className="grid min-h-[100dvh] place-items-center bg-bg" role="status" aria-label="Loading">
      <SajidinMark size={56} />
    </div>
  );
}
