import { AnimatePresence, motion } from "framer-motion";
import { AlertCircle, Inbox, RefreshCw, X } from "lucide-react";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { fadeIn, sheetVariants } from "../core/motion";
import { BRAND } from "../core/brand";
import { cn } from "../utils/cn";

/* ---------- Logo ---------- */
/**
 * Sajidin brand mark (original artwork, drawn in-house for this rebrand).
 * Sajidin — "those who prostrate" — is expressed as a figure in sujūd reduced to a
 * single mint arc resting on a baseline, with a dot for the forehead touching the ground.
 * Uses theme tokens so it follows the active mode and accent.
 */
export function SajidinMark({ size = 40, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" className={className} role="img" aria-label="Sajidin">
      <rect x="2" y="2" width="60" height="60" rx="18" fill="var(--t-card)" stroke="var(--t-line)" />
      {/* body arc (back) */}
      <path d="M14 40c2-12 9-20 20-20s16 7 18 15" stroke="var(--t-brand)" strokeWidth="5.5" strokeLinecap="round" />
      {/* forehead on the ground */}
      <circle cx="16" cy="43.5" r="4" fill="var(--t-brand)" />
      {/* baseline / prayer mat */}
      <rect x="11" y="49" width="42" height="3.5" rx="1.75" fill="var(--t-ink)" opacity="0.55" />
    </svg>
  );
}

/* ---------- Section header ---------- */
export function ScreenHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-3 px-5 pb-3 pt-4">
      <div>
        {subtitle && <p className="text-xs font-medium uppercase tracking-[0.14em] text-faint">{subtitle}</p>}
        <h1 className="text-[26px] font-semibold leading-tight tracking-tight">{title}</h1>
      </div>
      {right}
    </div>
  );
}

/* ---------- Icon button ---------- */
export function IconButton({
  label,
  onClick,
  children,
  active,
  className,
  disabled,
}: {
  label: string;
  onClick?: () => void;
  children: ReactNode;
  active?: boolean;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "press focus-ring inline-flex h-10 w-10 items-center justify-center rounded-full hairline bg-card-2 text-muted transition-colors disabled:opacity-40",
        active && "bg-brand-soft text-brand-ink border-brand/30",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function PrimaryButton({
  children,
  onClick,
  className,
  disabled,
  variant = "brand",
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
  variant?: "brand" | "ghost" | "danger";
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "press focus-ring inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-4 text-sm font-semibold transition-colors disabled:opacity-40",
        variant === "brand" && "bg-brand text-on-brand",
        variant === "ghost" && "hairline bg-card-2 text-ink",
        variant === "danger" && "bg-danger-bg text-danger-ink border border-danger-ink/25",
        className,
      )}
    >
      {children}
    </button>
  );
}

/* ---------- Toggle ---------- */
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        "focus-ring relative h-7 w-12 shrink-0 rounded-full transition-colors duration-200",
        checked ? "bg-brand" : "bg-track",
      )}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow", checked ? "left-6" : "left-1")}
      />
    </button>
  );
}

/* ---------- Chips ---------- */
export function Chip({
  active,
  onClick,
  children,
  label,
}: {
  active?: boolean;
  onClick?: () => void;
  children: ReactNode;
  /** Accessible name when the visible text would be ambiguous (e.g. "Home" vs the Home tab). */
  label?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      className={cn(
        "press focus-ring shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors",
        active ? "bg-brand text-on-brand" : "hairline bg-card-2 text-muted",
      )}
    >
      {children}
    </button>
  );
}

/* ---------- Skeleton ---------- */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton rounded-xl", className)} aria-hidden />;
}

/* ---------- State views ---------- */
export function ErrorState({ message, onRetry, compact }: { message: string; onRetry?: () => void; compact?: boolean }) {
  return (
    <motion.div
      variants={fadeIn}
      initial="hidden"
      animate="show"
      role="alert"
      className={cn("flex flex-col items-center text-center", compact ? "gap-2 py-4" : "gap-3 py-10")}
    >
      <span className="grid h-11 w-11 place-items-center rounded-full bg-danger-bg text-danger-ink">
        <AlertCircle size={20} />
      </span>
      <p className="max-w-[26ch] text-sm text-muted">{message}</p>
      {onRetry && (
        <PrimaryButton variant="ghost" onClick={onRetry} className="min-h-9 px-3 text-xs">
          <RefreshCw size={14} /> Retry
        </PrimaryButton>
      )}
    </motion.div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <motion.div variants={fadeIn} initial="hidden" animate="show" className="flex flex-col items-center gap-2 py-12 text-center">
      <span className="grid h-11 w-11 place-items-center rounded-full bg-card-2 text-faint">
        <Inbox size={20} />
      </span>
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="text-xs text-faint">{hint}</p>}
    </motion.div>
  );
}

/* ---------- Bottom sheet ---------- */
export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="backdrop"
            className="fixed inset-0 z-40 bg-black/60"
            variants={fadeIn}
            initial="hidden"
            animate="show"
            exit="exit"
            onClick={onClose}
          />
          <motion.div
            key="sheet"
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className="fixed inset-x-0 bottom-0 z-50 mx-auto max-h-[88dvh] w-full max-w-xl overflow-hidden rounded-t-[28px] bg-card hairline"
            variants={sheetVariants}
            initial="hidden"
            animate="show"
            exit="exit"
          >
            <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-faint/40" />
            <div className="flex items-center justify-between px-5 pb-2 pt-3">
              <h2 className="text-base font-semibold">{title}</h2>
              <IconButton label="Close" onClick={onClose} className="h-9 w-9">
                <X size={16} />
              </IconButton>
            </div>
            <div className="no-scrollbar overflow-y-auto px-5 pb-6" style={{ maxHeight: "calc(88dvh - 70px)", paddingBottom: "calc(24px + var(--safe-bottom))" }}>
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body,
  );
}

/* ---------- Confirm dialog ---------- */
export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  onConfirm,
  onCancel,
  danger,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  danger?: boolean;
}) {
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-6"
          variants={fadeIn}
          initial="hidden"
          animate="show"
          exit="exit"
          onClick={onCancel}
        >
          <motion.div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            initial={{ scale: 0.94, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.96, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.33, 1, 0.68, 1] }}
            className="w-full max-w-sm rounded-3xl bg-card p-5 hairline"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 id="confirm-title" className="text-base font-semibold">
              {title}
            </h3>
            <p className="mt-1.5 text-sm text-muted">{message}</p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <PrimaryButton variant="ghost" onClick={onCancel}>
                Cancel
              </PrimaryButton>
              <PrimaryButton variant={danger ? "danger" : "brand"} onClick={onConfirm}>
                {confirmLabel}
              </PrimaryButton>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

/* ---------- Toasts ---------- */
interface ToastItem {
  id: number;
  text: string;
  tone: "neutral" | "success" | "error";
}
const ToastCtx = createContext<(text: string, tone?: ToastItem["tone"]) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const idRef = useRef(0);
  const push = useCallback((text: string, tone: ToastItem["tone"] = "neutral") => {
    const id = ++idRef.current;
    setItems((prev) => [...prev.slice(-2), { id, text, tone }]);
    window.setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 2600);
  }, []);
  const value = useMemo(() => push, [push]);
  return (
    <ToastCtx.Provider value={value}>
      {children}
      {createPortal(
        <div className="pointer-events-none fixed inset-x-0 z-[60] flex flex-col items-center gap-2 px-4" style={{ bottom: "calc(92px + var(--safe-bottom))" }} aria-live="polite">
          <AnimatePresence>
            {items.map((t) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 10, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 6, scale: 0.98 }}
                transition={{ duration: 0.22, ease: [0.33, 1, 0.68, 1] }}
                className={cn(
                  "rounded-full px-4 py-2 text-sm font-medium shadow-soft hairline",
                  t.tone === "success" && "bg-brand text-on-brand",
                  t.tone === "error" && "bg-danger-solid text-white",
                  t.tone === "neutral" && "bg-card-2 text-ink",
                )}
              >
                {t.text}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>,
        document.body,
      )}
    </ToastCtx.Provider>
  );
}

/* ---------- Share helper ---------- */
export async function shareOrCopy(text: string, title: string = BRAND.name): Promise<"shared" | "copied" | "failed"> {
  try {
    if (navigator.share) {
      await navigator.share({ title, text });
      return "shared";
    }
  } catch (e) {
    if ((e as DOMException)?.name === "AbortError") return "failed";
  }
  try {
    await navigator.clipboard.writeText(text);
    return "copied";
  } catch {
    return "failed";
  }
}
