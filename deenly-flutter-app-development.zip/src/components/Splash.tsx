import { motion } from "framer-motion";
import { BRAND } from "../core/brand";
import { SajidinMark } from "./ui";

export function Splash({ onDone }: { onDone: () => void }) {
  return (
    <motion.div
      className="fixed inset-0 z-[70] grid place-items-center bg-bg"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.35, ease: [0.65, 0, 0.35, 1] } }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.86 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.33, 1, 0.68, 1] }}
        onAnimationComplete={onDone}
        className="flex flex-col items-center gap-4"
      >
        <SajidinMark size={84} />
        <div className="text-center">
          <p className="text-2xl font-semibold tracking-tight">{BRAND.name}</p>
          <p className="mt-1 text-xs font-medium uppercase tracking-[0.2em] text-faint">by {BRAND.publisher}</p>
        </div>
      </motion.div>
    </motion.div>
  );
}
