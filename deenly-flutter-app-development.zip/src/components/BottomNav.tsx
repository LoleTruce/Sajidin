import { motion } from "framer-motion";
import { BookOpen, Compass, Home, LayoutGrid } from "lucide-react";
import { haptics } from "../core/haptics";
import { useT } from "../i18n";
import { cn } from "../utils/cn";

export type Tab = "home" | "quran" | "qibla" | "tools";

const TABS: { id: Tab; key: "tab.home" | "tab.quran" | "tab.qibla" | "tab.tools"; Icon: typeof Home }[] = [
  { id: "home", key: "tab.home", Icon: Home },
  { id: "quran", key: "tab.quran", Icon: BookOpen },
  { id: "qibla", key: "tab.qibla", Icon: Compass },
  { id: "tools", key: "tab.tools", Icon: LayoutGrid },
];

export function BottomNav({ active, onChange, inverted }: { active: Tab; onChange: (t: Tab) => void; inverted?: boolean }) {
  const t = useT();
  return (
    <nav
      aria-label="Primary"
      className={cn(
        "fixed inset-x-0 bottom-0 z-30 border-t backdrop-blur-xl transition-colors duration-500",
        inverted ? "border-on-brand/10 bg-brand/85" : "border-line bg-bg/85",
      )}
      style={{ paddingBottom: "var(--safe-bottom)" }}
    >
      <ul className="mx-auto grid h-[68px] max-w-xl grid-cols-4">
        {TABS.map(({ id, key, Icon }) => {
          const label = t(key);
          const isActive = id === active;
          return (
            <li key={id} className="relative">
              <button
                type="button"
                aria-current={isActive ? "page" : undefined}
                aria-label={label}
                onClick={() => {
                  if (!isActive) {
                    haptics.light();
                    onChange(id);
                  }
                }}
                className="focus-ring relative flex h-full w-full flex-col items-center justify-center gap-1"
              >
                {isActive && (
                  <motion.span
                    layoutId="nav-indicator"
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                    className={cn("absolute top-0 h-[2px] w-10 rounded-full", inverted ? "bg-on-brand" : "bg-brand")}
                  />
                )}
                <motion.span
                  animate={{ scale: isActive ? 1.08 : 1, y: isActive ? -1 : 0 }}
                  transition={{ type: "spring", stiffness: 420, damping: 26 }}
                  className={cn(
                    "transition-colors duration-200",
                    inverted ? (isActive ? "text-on-brand" : "text-on-brand/60") : isActive ? "text-brand-ink" : "text-faint",
                  )}
                >
                  <Icon size={22} strokeWidth={isActive ? 2.4 : 2} />
                </motion.span>
                <span
                  className={cn(
                    "text-[11px] font-semibold transition-colors duration-200",
                    inverted ? (isActive ? "text-on-brand" : "text-on-brand/60") : isActive ? "text-ink" : "text-faint",
                  )}
                >
                  {label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
