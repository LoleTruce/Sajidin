import { CircleUserRound, Settings } from "lucide-react";
import { memo, type ReactNode } from "react";
import { BRAND } from "../core/brand";
import { cn } from "../utils/cn";
import { SajidinMark } from "./ui";

/**
 * Persistent shell header: brand on the left, Account + Settings on the right.
 * Rendered once by the app shell (not per screen), so it never stacks across tabs.
 */
export const TopBar = memo(function TopBar({
  onAccount,
  onSettings,
  inverted,
  accountBadge,
}: {
  onAccount: () => void;
  onSettings: () => void;
  /** Qibla-aligned state: header sits on the accent background. */
  inverted?: boolean;
  /** Small status dot on the account icon (e.g. signed-in). */
  accountBadge?: boolean;
}) {
  return (
    <header
      role="banner"
      className={cn(
        "sticky top-0 z-30 border-b backdrop-blur-xl transition-colors duration-500",
        inverted ? "border-on-brand/10 bg-brand/85" : "border-line bg-bg/85",
      )}
      style={{ paddingTop: "var(--safe-top)" }}
    >
      <div className="mx-auto flex h-14 max-w-xl items-center justify-between pl-4 pr-1">
        <Wordmark inverted={inverted} />
        <nav aria-label="Account and settings" className="flex items-center">
          <TopAction label="Account" onClick={onAccount} inverted={inverted}>
            <CircleUserRound size={24} strokeWidth={1.8} />
            {accountBadge && <span aria-hidden className={cn("absolute right-2.5 top-2.5 h-2 w-2 rounded-full ring-2", inverted ? "bg-on-brand ring-brand" : "bg-brand ring-bg")} />}
          </TopAction>
          <TopAction label="Settings" onClick={onSettings} inverted={inverted}>
            <Settings size={24} strokeWidth={1.8} />
          </TopAction>
        </nav>
      </div>
    </header>
  );
});

function Wordmark({ inverted }: { inverted?: boolean }) {
  return (
    <a href="#main" className="focus-ring flex items-center gap-2 rounded-lg" aria-label={`${BRAND.name} home`}>
      <SajidinMark size={28} />
      <span className={cn("text-[17px] font-semibold tracking-tight transition-colors duration-500", inverted ? "text-on-brand" : "text-ink")}>
        {BRAND.name}
        <span className={cn("ml-0.5 inline-block h-1.5 w-1.5 translate-y-[-1px] rounded-full", inverted ? "bg-on-brand" : "bg-brand")} aria-hidden />
      </span>
    </a>
  );
}

/** 48×48 unbordered icon action; icon tints to the accent on hover/press/focus only. */
function TopAction({ label, onClick, children, inverted }: { label: string; onClick: () => void; children: ReactNode; inverted?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        "focus-ring relative grid h-12 w-12 place-items-center rounded-full transition-colors duration-200",
        "active:scale-95 active:transition-transform",
        inverted ? "text-on-brand/80 hover:text-on-brand focus-visible:text-on-brand active:text-on-brand" : "text-ink/85 hover:text-brand-ink focus-visible:text-brand-ink active:text-brand-ink",
      )}
    >
      {children}
    </button>
  );
}
