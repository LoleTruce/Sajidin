import { DEFAULT_ACCENT, DEFAULT_THEME_MODE, isAccentId, isThemeMode, type AccentId, type ThemeMode } from "./tokens";

/** Stable, versionable keys. Values are plain identifiers, never serialised runtime objects. */
export const PREF_KEYS = {
  schema: "deenly_appearance_schema",
  mode: "deenly_theme_mode",
  accent: "deenly_accent_color",
  updatedAt: "deenly_appearance_updated_at",
} as const;

export const APPEARANCE_SCHEMA_VERSION = 1;

export interface AppearancePrefs {
  mode: ThemeMode;
  accent: AccentId;
  /** Epoch ms of the last user-initiated change (used for last-write-wins sync). */
  updatedAt: number;
}

export const DEFAULT_PREFS: AppearancePrefs = { mode: DEFAULT_THEME_MODE, accent: DEFAULT_ACCENT, updatedAt: 0 };

/**
 * Validates arbitrary input (local storage, cloud documents, URL params…) into a safe
 * preference object. Unknown or corrupt values fall back field-by-field to defaults.
 * Returns `valid=false` when *nothing* usable was present so callers can distinguish
 * "no record" from "record with defaults".
 */
export function parsePrefs(input: unknown): { prefs: AppearancePrefs; valid: boolean } {
  if (!input || typeof input !== "object") return { prefs: DEFAULT_PREFS, valid: false };
  const o = input as Record<string, unknown>;
  const modeOk = isThemeMode(o.mode);
  const accentOk = isAccentId(o.accent);
  const updatedAt = typeof o.updatedAt === "number" && Number.isFinite(o.updatedAt) && o.updatedAt >= 0 ? o.updatedAt : 0;
  return {
    prefs: {
      mode: modeOk ? (o.mode as ThemeMode) : DEFAULT_THEME_MODE,
      accent: accentOk ? (o.accent as AccentId) : DEFAULT_ACCENT,
      updatedAt,
    },
    valid: modeOk || accentOk,
  };
}

export interface PrefStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

function storage(custom?: PrefStorage): PrefStorage | null {
  if (custom) return custom;
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null; // Access can throw in sandboxed iframes / disabled storage.
  }
}

/** Synchronous read so the theme can be applied before first paint. Never throws. */
export function loadLocalPrefs(custom?: PrefStorage): { prefs: AppearancePrefs; valid: boolean } {
  const s = storage(custom);
  if (!s) return { prefs: DEFAULT_PREFS, valid: false };
  try {
    const updatedRaw = s.getItem(PREF_KEYS.updatedAt);
    return parsePrefs({
      mode: s.getItem(PREF_KEYS.mode),
      accent: s.getItem(PREF_KEYS.accent),
      updatedAt: updatedRaw == null ? 0 : Number(updatedRaw),
    });
  } catch {
    return { prefs: DEFAULT_PREFS, valid: false };
  }
}

/** Best-effort write. Returns false if persistence is unavailable (quota, private mode, disabled). */
export function saveLocalPrefs(prefs: AppearancePrefs, custom?: PrefStorage): boolean {
  const s = storage(custom);
  if (!s) return false;
  try {
    s.setItem(PREF_KEYS.schema, String(APPEARANCE_SCHEMA_VERSION));
    s.setItem(PREF_KEYS.mode, prefs.mode);
    s.setItem(PREF_KEYS.accent, prefs.accent);
    s.setItem(PREF_KEYS.updatedAt, String(prefs.updatedAt));
    return true;
  } catch {
    return false;
  }
}

export function clearLocalPrefs(custom?: PrefStorage): void {
  const s = storage(custom);
  if (!s) return;
  try {
    Object.values(PREF_KEYS).forEach((k) => s.removeItem(k));
  } catch {
    /* ignore */
  }
}
