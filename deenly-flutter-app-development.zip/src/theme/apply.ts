import { resolveTheme, type AccentId, type ThemeMode } from "./tokens";

let appliedKey: string | null = null;

/**
 * Writes the resolved token set onto <html>. Because every Tailwind colour utility in
 * Sajidin references these custom properties, the whole UI re-themes via the browser's
 * style engine — no React subtree re-renders are required.
 */
export function applyThemeToDocument(mode: ThemeMode, accent: AccentId, overrideThemeColor?: string): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const theme = resolveTheme(mode, accent);
  const key = `${mode}:${accent}`;

  if (appliedKey !== key) {
    root.dataset.theme = mode;
    root.dataset.accent = accent;
    root.style.colorScheme = theme.colorScheme;
    for (const [k, v] of Object.entries(theme.vars)) root.style.setProperty(k, v);
    appliedKey = key;
  }
  setThemeColorMeta(overrideThemeColor ?? theme.themeColor);
}

export function setThemeColorMeta(color: string): void {
  if (typeof document === "undefined") return;
  let meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
  if (!meta) {
    meta = document.createElement("meta");
    meta.name = "theme-color";
    document.head.appendChild(meta);
  }
  if (meta.content !== color) meta.content = color;
}

/** Test hook: forget the memoised application so the next call re-applies. */
export function resetAppliedThemeCache(): void {
  appliedKey = null;
}
