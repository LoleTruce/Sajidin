import { parsePrefs, type AppearancePrefs } from "./preferences";
import { themeController, themeStore } from "./themeStore";

/* ------------------------------------------------------------------ */
/* Auth integration point                                              */
/* ------------------------------------------------------------------ */

/**
 * The sync service keys everything off `authSession.uid` (see src/auth/session.ts).
 * It is re-exported here so existing imports keep working.
 */
export { authSession } from "../auth/session";
export type { AuthSession } from "../auth/session";
import { authSession } from "../auth/session";

/* ------------------------------------------------------------------ */
/* Adapter contract                                                    */
/* ------------------------------------------------------------------ */

export interface AppearanceSyncAdapter {
  /** Returns the stored document (any shape — it will be validated) or null when none exists. */
  read(uid: string): Promise<unknown | null>;
  /** Persists the preference document for the given uid. Must throw on failure. */
  write(uid: string, prefs: AppearancePrefs): Promise<void>;
}

/**
 * Default adapter: a per-uid record in localStorage under `deenly:profile:{uid}:appearance`.
 * It mirrors the Firestore document shape (`users/{uid}/preferences/appearance`) so the
 * real adapter is a drop-in replacement, and it lets account-switching logic be exercised
 * and tested without a backend.
 */
export class LocalProfileAdapter implements AppearanceSyncAdapter {
  constructor(private readonly storage: Pick<Storage, "getItem" | "setItem"> = localStorage) {}
  private key(uid: string) {
    return `deenly:profile:${uid}:appearance`;
  }
  async read(uid: string): Promise<unknown | null> {
    const raw = this.storage.getItem(this.key(uid));
    return raw ? (JSON.parse(raw) as unknown) : null;
  }
  async write(uid: string, prefs: AppearancePrefs): Promise<void> {
    this.storage.setItem(this.key(uid), JSON.stringify({ themeMode: prefs.mode, accentColor: prefs.accent, updatedAt: prefs.updatedAt }));
  }
}

/** Normalises the cloud document shape ({themeMode, accentColor, updatedAt}) into AppearancePrefs. */
export function parseCloudDoc(doc: unknown): { prefs: AppearancePrefs; valid: boolean } {
  if (!doc || typeof doc !== "object") return parsePrefs(null);
  const o = doc as Record<string, unknown>;
  const updated = o.updatedAt;
  const updatedAt =
    typeof updated === "number"
      ? updated
      : updated && typeof updated === "object" && typeof (updated as { toMillis?: () => number }).toMillis === "function"
        ? (updated as { toMillis: () => number }).toMillis()
        : 0;
  return parsePrefs({ mode: o.themeMode ?? o.mode, accent: o.accentColor ?? o.accent, updatedAt });
}

/* ------------------------------------------------------------------ */
/* Service                                                             */
/* ------------------------------------------------------------------ */

export interface SyncServiceOptions {
  adapter: AppearanceSyncAdapter;
  /** Debounce for outbound writes so rapid taps produce one request. */
  debounceMs?: number;
  /** Injected for tests. */
  now?: () => number;
  isOnline?: () => boolean;
}

/**
 * Keeps the authenticated user's profile in step with the local theme store.
 *
 * Conflict resolution (documented): **last write wins by `updatedAt`.**
 *  - On sign-in, the cloud record is applied if it is newer than (or the local state is pristine
 *    relative to) the local record; otherwise the local record is uploaded.
 *  - If no cloud record exists, the current local settings are uploaded unchanged.
 *  - Every outbound write carries the uid captured *at the time of the change*; if the
 *    session changes before the write runs, the write is dropped — a signed-out or switched
 *    account can never receive the previous user's preferences.
 *  - Failed writes are marked `pending` and retried when the browser reports connectivity
 *    or on the next sign-in of the same uid. Failures never block local customisation.
 */
export class AppearanceSyncService {
  private readonly adapter: AppearanceSyncAdapter;
  private readonly debounceMs: number;
  private readonly now: () => number;
  private readonly isOnline: () => boolean;
  private unsubscribers: Array<() => void> = [];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private pending: { uid: string; prefs: AppearancePrefs } | null = null;
  private activeUid: string | null = null;
  private generation = 0;

  constructor(opts: SyncServiceOptions) {
    this.adapter = opts.adapter;
    this.debounceMs = opts.debounceMs ?? 400;
    this.now = opts.now ?? (() => Date.now());
    this.isOnline = opts.isOnline ?? (() => (typeof navigator === "undefined" ? true : navigator.onLine));
  }

  start(): void {
    this.stop();
    this.unsubscribers.push(authSession.subscribe(() => void this.handleAuthChange(authSession.get().uid)));
    this.unsubscribers.push(
      themeController.onChange((prefs, origin) => {
        if (origin === "cloud") return; // never echo remote changes back
        this.queueWrite(prefs);
      }),
    );
    if (typeof window !== "undefined") {
      const onOnline = () => void this.flush();
      window.addEventListener("online", onOnline);
      this.unsubscribers.push(() => window.removeEventListener("online", onOnline));
    }
    void this.handleAuthChange(authSession.get().uid);
  }

  stop(): void {
    this.unsubscribers.forEach((u) => u());
    this.unsubscribers = [];
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  /** Public, awaitable sync for the settings screen's "Sync now" action and for tests. */
  async syncNow(): Promise<void> {
    if (!this.activeUid) return;
    if (this.pending) await this.flush();
    else await this.handleAuthChange(this.activeUid, true);
  }

  private async handleAuthChange(uid: string | null, force = false): Promise<void> {
    if (uid === this.activeUid && !force) return;
    const gen = ++this.generation;
    this.activeUid = uid;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    // Drop any queued write that belongs to a different account.
    if (this.pending && this.pending.uid !== uid) this.pending = null;

    if (!uid) {
      themeController.setSyncStatus("signed-out");
      return;
    }

    themeController.setSyncStatus("syncing");
    try {
      const doc = await this.adapter.read(uid);
      if (gen !== this.generation) return; // session changed mid-flight
      const local = themeController.getPrefs();
      const { prefs: cloud, valid } = parseCloudDoc(doc);

      if (valid && cloud.updatedAt >= local.updatedAt) {
        // Cloud is newer (or local is pristine) → restore the user's saved appearance.
        if (cloud.mode !== local.mode || cloud.accent !== local.accent || cloud.updatedAt !== local.updatedAt) {
          themeController.applyRemote(cloud);
        }
        themeController.setSyncStatus("synced", null, this.now());
      } else {
        // No record, unsupported identifiers, or local is newer → upload local settings.
        await this.adapter.write(uid, local);
        if (gen !== this.generation) return;
        themeController.setSyncStatus("synced", null, this.now());
      }
      if (this.pending?.uid === uid) await this.flush();
    } catch (e) {
      if (gen !== this.generation) return;
      themeController.setSyncStatus("error", describeSyncError(e));
    }
  }

  private queueWrite(prefs: AppearancePrefs): void {
    const uid = this.activeUid;
    if (!uid) return; // signed out: local only
    this.pending = { uid, prefs };
    themeController.setSyncStatus("pending");
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.flush(), this.debounceMs);
  }

  private async flush(): Promise<void> {
    this.timer = null;
    const job = this.pending;
    if (!job) return;
    if (job.uid !== this.activeUid) {
      this.pending = null; // account changed → discard, never cross-write
      return;
    }
    if (!this.isOnline()) {
      themeController.setSyncStatus("pending", "Offline — will sync when you're back online.");
      return;
    }
    const gen = this.generation;
    themeController.setSyncStatus("syncing");
    try {
      await this.adapter.write(job.uid, job.prefs);
      if (gen !== this.generation || job.uid !== this.activeUid) return;
      if (this.pending === job) this.pending = null; // newer change may have been queued meanwhile
      themeController.setSyncStatus(this.pending ? "pending" : "synced", null, this.now());
    } catch (e) {
      if (gen !== this.generation) return;
      themeController.setSyncStatus("pending", describeSyncError(e));
    }
  }
}

function describeSyncError(e: unknown): string {
  const code = (e as { code?: string })?.code ?? "";
  if (code.includes("permission-denied")) return "Your account isn't allowed to update this profile.";
  if (code.includes("unauthenticated")) return "Your session has expired. Sign in again to sync.";
  if (code.includes("unavailable")) return "Sync service unavailable — will retry.";
  return e instanceof Error && e.message ? e.message : "Could not sync preferences.";
}

/* Convenience: single app-wide instance using the local adapter until a backend is connected. */
let defaultService: AppearanceSyncService | null = null;
export function startDefaultSync(): AppearanceSyncService {
  if (defaultService) return defaultService;
  let adapter: AppearanceSyncAdapter;
  try {
    adapter = new LocalProfileAdapter();
  } catch {
    adapter = { read: async () => null, write: async () => undefined };
  }
  defaultService = new AppearanceSyncService({ adapter });
  defaultService.start();
  return defaultService;
}

export function getDefaultSync(): AppearanceSyncService | null {
  return defaultService;
}

export function getSyncStatusSnapshot() {
  return themeStore.get().sync;
}
