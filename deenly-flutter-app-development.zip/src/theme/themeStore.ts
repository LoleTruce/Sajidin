import { createStore, useStore } from "../core/store";
import { applyThemeToDocument } from "./apply";
import { loadLocalPrefs, saveLocalPrefs, type AppearancePrefs, type PrefStorage } from "./preferences";
import { ACCENTS, DEFAULT_ACCENT, DEFAULT_THEME_MODE, MODES, resolveTheme, type AccentId, type ResolvedTheme, type ThemeMode } from "./tokens";

export type SyncStatus = "idle" | "signed-out" | "syncing" | "synced" | "pending" | "error";

export interface ThemeState {
  mode: ThemeMode;
  accent: AccentId;
  /** Epoch ms of last user change; 0 = never changed (pristine defaults). */
  updatedAt: number;
  /** True once local preferences have been read (synchronously at boot). */
  initialised: boolean;
  /** False when localStorage is unavailable — the app still works in-memory. */
  persistenceAvailable: boolean;
  sync: SyncStatus;
  syncError: string | null;
  lastSyncedAt: number | null;
}

type Listener = (prefs: AppearancePrefs, origin: "user" | "cloud" | "reset") => void;

/**
 * Central appearance state. Deliberately *not* persisted through `createStore`'s generic
 * key — we own the versioned `deenly_*` keys ourselves so identifiers stay stable.
 */
export const themeStore = createStore<ThemeState>({
  mode: DEFAULT_THEME_MODE,
  accent: DEFAULT_ACCENT,
  updatedAt: 0,
  initialised: false,
  persistenceAvailable: true,
  sync: "signed-out",
  syncError: null,
  lastSyncedAt: null,
});

const changeListeners = new Set<Listener>();
let storageOverride: PrefStorage | undefined;

function currentPrefs(): AppearancePrefs {
  const s = themeStore.get();
  return { mode: s.mode, accent: s.accent, updatedAt: s.updatedAt };
}

function commit(next: Partial<AppearancePrefs>, origin: "user" | "cloud" | "reset"): void {
  const prev = themeStore.get();
  const prefs: AppearancePrefs = {
    mode: next.mode ?? prev.mode,
    accent: next.accent ?? prev.accent,
    updatedAt: next.updatedAt ?? Date.now(),
  };
  if (prefs.mode === prev.mode && prefs.accent === prev.accent && origin !== "reset") return;

  // 1. Paint first — the UI must respond instantly, independent of persistence/network.
  applyThemeToDocument(prefs.mode, prefs.accent);
  // 2. In-memory state.
  const ok = saveLocalPrefs(prefs, storageOverride);
  themeStore.set({ ...prefs, persistenceAvailable: ok });
  // 3. Notify sync layer (async, fire-and-forget).
  changeListeners.forEach((l) => l(prefs, origin));
}

export const themeController = {
  /**
   * Reads saved preferences and applies them. Synchronous so `main.tsx` can call it
   * before the first render — the user never sees a flash of the wrong theme.
   * Safe to call multiple times; it only reads storage on the first call.
   */
  init(storage?: PrefStorage): ThemeState {
    storageOverride = storage;
    if (themeStore.get().initialised) return themeStore.get();
    const { prefs } = loadLocalPrefs(storage);
    applyThemeToDocument(prefs.mode, prefs.accent);
    themeStore.set({ ...prefs, initialised: true });
    return themeStore.get();
  },

  setThemeMode(mode: ThemeMode): void {
    if (!(mode in MODES)) return;
    commit({ mode }, "user");
  },

  setAccent(accent: AccentId): void {
    if (!(accent in ACCENTS)) return;
    commit({ accent }, "user");
  },

  /** Restores Dark + Mint Emerald. Affects appearance only — bookmarks, counters and settings are untouched. */
  resetToDefaults(): void {
    commit({ mode: DEFAULT_THEME_MODE, accent: DEFAULT_ACCENT }, "reset");
  },

  /** Applies preferences that arrived from the user's profile (does not echo back to the cloud). */
  applyRemote(prefs: AppearancePrefs): void {
    commit(prefs, "cloud");
  },

  /** Re-applies the current theme to the DOM (e.g. after a temporary status-bar override). */
  reapply(overrideThemeColor?: string): void {
    const s = themeStore.get();
    applyThemeToDocument(s.mode, s.accent, overrideThemeColor);
  },

  getPrefs: currentPrefs,

  resolved(): ResolvedTheme {
    const s = themeStore.get();
    return resolveTheme(s.mode, s.accent);
  },

  setSyncStatus(sync: SyncStatus, error: string | null = null, lastSyncedAt?: number): void {
    const cur = themeStore.get();
    if (cur.sync === sync && cur.syncError === error && (lastSyncedAt === undefined || cur.lastSyncedAt === lastSyncedAt)) return;
    themeStore.set({ sync, syncError: error, ...(lastSyncedAt !== undefined ? { lastSyncedAt } : {}) });
  },

  onChange(listener: Listener): () => void {
    changeListeners.add(listener);
    return () => changeListeners.delete(listener);
  },

  /** Test-only: wipe in-memory state. */
  _resetForTests(): void {
    changeListeners.clear();
    storageOverride = undefined;
    themeStore.set({
      mode: DEFAULT_THEME_MODE,
      accent: DEFAULT_ACCENT,
      updatedAt: 0,
      initialised: false,
      persistenceAvailable: true,
      sync: "signed-out",
      syncError: null,
      lastSyncedAt: null,
    });
  },
};

/* ------------------------------------------------------------------ */
/* React hooks — selector-based so unrelated components never re-render */
/* ------------------------------------------------------------------ */

export function useThemeMode(): ThemeMode {
  return useStore(themeStore, (s) => s.mode);
}
export function useAccent(): AccentId {
  return useStore(themeStore, (s) => s.accent);
}
export function useThemeSync(): Pick<ThemeState, "sync" | "syncError" | "lastSyncedAt" | "persistenceAvailable"> {
  const sync = useStore(themeStore, (s) => s.sync);
  const syncError = useStore(themeStore, (s) => s.syncError);
  const lastSyncedAt = useStore(themeStore, (s) => s.lastSyncedAt);
  const persistenceAvailable = useStore(themeStore, (s) => s.persistenceAvailable);
  return { sync, syncError, lastSyncedAt, persistenceAvailable };
}
export function useResolvedTheme(): ResolvedTheme {
  const mode = useThemeMode();
  const accent = useAccent();
  return resolveTheme(mode, accent);
}
