import { ensureContrast, pickOnColor, withAlpha } from "./color";

/* ------------------------------------------------------------------ */
/* Strongly-typed models                                               */
/* ------------------------------------------------------------------ */

export const THEME_MODES = ["dark", "light", "sepia"] as const;
export type ThemeMode = (typeof THEME_MODES)[number];

export const ACCENT_IDS = ["mint", "blue", "amber", "orchid"] as const;
export type AccentId = (typeof ACCENT_IDS)[number];

export const DEFAULT_THEME_MODE: ThemeMode = "dark";
export const DEFAULT_ACCENT: AccentId = "mint";

export function isThemeMode(v: unknown): v is ThemeMode {
  return typeof v === "string" && (THEME_MODES as readonly string[]).includes(v);
}
export function isAccentId(v: unknown): v is AccentId {
  return typeof v === "string" && (ACCENT_IDS as readonly string[]).includes(v);
}

/* ------------------------------------------------------------------ */
/* Accent palette                                                      */
/* ------------------------------------------------------------------ */

export interface AccentDefinition {
  id: AccentId;
  name: string;
  hex: string;
  /** Preferred dark foreground to place on top of the accent fill (tinted to match the hue). */
  darkOn: string;
}

export const ACCENTS: Record<AccentId, AccentDefinition> = {
  mint: { id: "mint", name: "Mint Emerald", hex: "#00B388", darkOn: "#06231C" },
  blue: { id: "blue", name: "Royal Blue", hex: "#2F60FF", darkOn: "#071233" },
  amber: { id: "amber", name: "Warm Amber Gold", hex: "#D4AF37", darkOn: "#2B2208" },
  orchid: { id: "orchid", name: "Deep Orchid Purple", hex: "#8A2BE2", darkOn: "#1E0836" },
};

/* ------------------------------------------------------------------ */
/* Mode surfaces                                                       */
/* ------------------------------------------------------------------ */

export interface ModeDefinition {
  id: ThemeMode;
  name: string;
  description: string;
  /** Tells the browser which built-in control styling to use. */
  colorScheme: "dark" | "light";
  bg: string;
  card: string;
  card2: string;
  ink: string;
  muted: string;
  faint: string;
  /** Hairline borders & dividers */
  line: string;
  /** Track colour for progress bars / inactive toggles */
  track: string;
  /** Shimmer highlight for skeletons */
  shimmer: string;
  warnBg: string;
  warnInk: string;
  dangerBg: string;
  dangerInk: string;
  shadow: string;
}

export const MODES: Record<ThemeMode, ModeDefinition> = {
  dark: {
    id: "dark",
    name: "Dark",
    description: "Sajidin's signature charcoal look.",
    colorScheme: "dark",
    bg: "#121214",
    card: "#1E1E24",
    card2: "#26262E",
    ink: "#FFFFFF",
    muted: "#A3A3AD",
    faint: "#6B6B75",
    line: "rgba(255, 255, 255, 0.07)",
    track: "rgba(255, 255, 255, 0.08)",
    shimmer: "rgba(255, 255, 255, 0.05)",
    warnBg: "rgba(245, 158, 11, 0.12)",
    warnInk: "#FCD79A",
    dangerBg: "rgba(239, 68, 68, 0.12)",
    dangerInk: "#FCA5A5",
    shadow: "0 8px 24px -12px rgba(0, 0, 0, 0.6)",
  },
  light: {
    id: "light",
    name: "Light",
    description: "Clean, bright and minimal.",
    colorScheme: "light",
    bg: "#F8F9FA",
    card: "#FFFFFF",
    card2: "#F1F3F5",
    ink: "#1B1C20",
    muted: "#5C6066",
    faint: "#8A8F98",
    line: "rgba(20, 20, 30, 0.08)",
    track: "rgba(20, 20, 30, 0.07)",
    shimmer: "rgba(255, 255, 255, 0.7)",
    warnBg: "rgba(217, 119, 6, 0.10)",
    warnInk: "#92400E",
    dangerBg: "rgba(220, 38, 38, 0.08)",
    dangerInk: "#B91C1C",
    shadow: "0 6px 20px -12px rgba(20, 20, 30, 0.18)",
  },
  sepia: {
    id: "sepia",
    name: "Sepia",
    description: "Warm cream tones for long reading sessions.",
    colorScheme: "light",
    bg: "#F4ECD8",
    card: "#FBF5E6",
    card2: "#EEE4CC",
    ink: "#45321F",
    muted: "#7A6652",
    faint: "#9C8B75",
    line: "rgba(69, 50, 31, 0.12)",
    track: "rgba(69, 50, 31, 0.10)",
    shimmer: "rgba(255, 250, 235, 0.7)",
    warnBg: "rgba(180, 100, 20, 0.12)",
    warnInk: "#7A4410",
    dangerBg: "rgba(170, 50, 40, 0.10)",
    dangerInk: "#8F2F26",
    shadow: "0 6px 20px -12px rgba(69, 50, 31, 0.22)",
  },
};

/* ------------------------------------------------------------------ */
/* Resolved theme → CSS custom properties                              */
/* ------------------------------------------------------------------ */

export interface ResolvedTheme {
  mode: ThemeMode;
  accent: AccentId;
  /** CSS custom properties applied to <html>. Keys include the leading `--`. */
  vars: Record<string, string>;
  /** Colour for the browser chrome / status bar. */
  themeColor: string;
  colorScheme: "dark" | "light";
}

const cache = new Map<string, ResolvedTheme>();

/**
 * Builds (and memoises) the complete token set for a mode + accent pair.
 * Pure and cheap; called once per change rather than per widget build.
 */
export function resolveTheme(mode: ThemeMode, accent: AccentId): ResolvedTheme {
  const key = `${mode}:${accent}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const m = MODES[mode];
  const a = ACCENTS[accent];
  const brand = a.hex;
  const onBrand = pickOnColor(brand, a.darkOn);
  // Accent used for text/icons on normal surfaces must stay legible on the page background and cards.
  const brandInk = ensureContrast(ensureContrast(brand, m.bg, 4.5), m.card, 4.5);

  const resolved: ResolvedTheme = {
    mode,
    accent,
    colorScheme: m.colorScheme,
    themeColor: m.bg,
    vars: {
      "--t-bg": m.bg,
      "--t-card": m.card,
      "--t-card-2": m.card2,
      "--t-ink": m.ink,
      "--t-muted": m.muted,
      "--t-faint": m.faint,
      "--t-line": m.line,
      "--t-track": m.track,
      "--t-shimmer": m.shimmer,
      "--t-warn-bg": m.warnBg,
      "--t-warn-ink": m.warnInk,
      "--t-danger-bg": m.dangerBg,
      "--t-danger-ink": m.dangerInk,
      "--t-shadow": m.shadow,
      "--t-brand": brand,
      "--t-brand-ink": brandInk,
      "--t-brand-soft": withAlpha(brand, mode === "dark" ? 0.14 : 0.12),
      "--t-on-brand": onBrand,
    },
  };
  cache.set(key, resolved);
  return resolved;
}
