import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { locale } from "./i18n";
import { themeController } from "./theme/themeStore";
import { startDefaultSync } from "./theme/sync";
import { registerServiceWorker } from "./services/serviceWorker";

/*
 * Boot order (all synchronous, all tolerant of missing/corrupt storage):
 *  1. Theme  — read saved appearance and apply tokens to <html> before React mounts (no flash).
 *  2. Locale — read the saved language (or detect from the browser) and set <html lang/dir>.
 *  3. Sync   — start the profile-sync service; inert until an auth session reports a uid.
 *  3b. SW    — register the app-shell service worker (offline shell + notification display).
 *              Asynchronous and non-fatal; the app never waits for it.
 *  4. Mount  — <App/> reads the first-launch flag in its initial state and renders either the
 *              onboarding wizard or the existing main shell; neither is ever shown by mistake
 *              because the decision is made before the first render.
 */
themeController.init();
locale.init();
startDefaultSync();
void registerServiceWorker();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
