/** Kaaba coordinates (Masjid al-Haram, Makkah). */
export const KAABA = { lat: 21.4225, lng: 39.8262 } as const;

const toRad = (d: number) => (d * Math.PI) / 180;
const toDeg = (r: number) => (r * 180) / Math.PI;

/** Normalise any angle to [0, 360). */
export function normalizeDegrees(deg: number): number {
  const d = deg % 360;
  return d < 0 ? d + 360 : d;
}

/**
 * Initial great-circle bearing (forward azimuth) from (lat, lng) to the Kaaba,
 * computed with spherical trigonometry. Result in degrees clockwise from true north.
 */
export function qiblaBearing(lat: number, lng: number): number {
  const φ1 = toRad(lat);
  const φ2 = toRad(KAABA.lat);
  const Δλ = toRad(KAABA.lng - lng);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return normalizeDegrees(toDeg(Math.atan2(y, x)));
}

/** Great-circle distance in kilometres (haversine). */
export function distanceToKaabaKm(lat: number, lng: number): number {
  const R = 6371;
  const dφ = toRad(KAABA.lat - lat);
  const dλ = toRad(KAABA.lng - lng);
  const a =
    Math.sin(dφ / 2) ** 2 + Math.cos(toRad(lat)) * Math.cos(toRad(KAABA.lat)) * Math.sin(dλ / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/** Signed shortest angular difference a→b in (-180, 180]. */
export function angleDelta(a: number, b: number): number {
  let d = normalizeDegrees(b) - normalizeDegrees(a);
  if (d > 180) d -= 360;
  if (d <= -180) d += 360;
  return d;
}

/** True if |heading - target| within tolerance, handling wrap-around. */
export function isAligned(heading: number, target: number, toleranceDeg: number): boolean {
  return Math.abs(angleDelta(heading, target)) <= toleranceDeg;
}

/**
 * Exponential low-pass filter for compass headings that is wrap-aware
 * (so 359° → 1° doesn't swing through 180°).
 */
export function smoothHeading(prev: number | null, next: number, alpha = 0.18): number {
  if (prev == null) return normalizeDegrees(next);
  return normalizeDegrees(prev + angleDelta(prev, next) * alpha);
}

/** Converts a continuous rotation value so CSS transitions never spin the long way round. */
export function continuousRotation(prevRotation: number, newHeading: number): number {
  const prevNorm = normalizeDegrees(prevRotation);
  return prevRotation + angleDelta(prevNorm, newHeading);
}
