import { CALCULATION_METHODS } from "../services/aladhan";

/**
 * Regional defaults for the prayer-time calculation method, keyed by ISO 3166-1 alpha-2 code.
 * These are *starting points* only — the method remains user-configurable in Prayer settings,
 * and method IDs are the ones already supported by the existing AlAdhan integration.
 */
export const DEFAULT_METHOD_ID = 3; // Muslim World League

const BY_COUNTRY: Record<string, number> = {
  // North America → ISNA
  US: 2,
  CA: 2,
  // Egypt & neighbours commonly following the Egyptian General Authority
  EG: 5,
  SD: 5,
  LY: 5,
  // Saudi Arabia → Umm al-Qura
  SA: 4,
  // South Asia → University of Islamic Sciences, Karachi
  PK: 1,
  IN: 1,
  BD: 1,
  AF: 1,
  // Gulf
  AE: 16,
  KW: 9,
  QA: 10,
  BH: 8,
  OM: 8,
  // Other national authorities already supported by AlAdhan
  SG: 11,
  FR: 12,
  TR: 13,
  RU: 14,
  MY: 17,
  ID: 20,
  MA: 21,
  PT: 22,
  JO: 23,
};

export function defaultMethodForCountry(countryCode: string | null | undefined): number {
  if (!countryCode) return DEFAULT_METHOD_ID;
  const id = BY_COUNTRY[countryCode.toUpperCase()];
  return id && CALCULATION_METHODS.some((m) => m.id === id) ? id : DEFAULT_METHOD_ID;
}

export function methodName(id: number): string {
  return CALCULATION_METHODS.find((m) => m.id === id)?.name ?? "Muslim World League";
}
