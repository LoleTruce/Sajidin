export const PRAYER_NAMES = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;
export type PrayerName = (typeof PRAYER_NAMES)[number];

export interface PrayerTimesDay {
  /** ISO date yyyy-mm-dd in the location's local day */
  date: string;
  /** Epoch ms for each prayer, already timezone-resolved */
  times: Record<PrayerName, number>;
  timezone: string;
  hijri?: { day: string; month: string; year: string; weekday: string };
  method?: string;
}

export interface NextPrayer {
  name: PrayerName;
  at: number;
  /** ms remaining (never negative) */
  remainingMs: number;
  /** Name of prayer currently in progress (previous one) */
  current?: PrayerName;
  /** 0..1 progress between previous prayer and the next */
  progress: number;
}

/**
 * Parse a "HH:MM" (optionally "HH:MM (TZ)") string from AlAdhan into epoch ms
 * for a given local calendar date and IANA timezone. Uses Intl to resolve offsets
 * correctly across DST boundaries without external libraries.
 */
export function timeStringToEpoch(hhmm: string, dateISO: string, timeZone: string): number {
  const clean = hhmm.trim().split(" ")[0];
  const [h, m] = clean.split(":").map(Number);
  const [y, mo, d] = dateISO.split("-").map(Number);
  // Guess in UTC then correct by the zone's offset at that instant (iterate twice for DST edges).
  let guess = Date.UTC(y, mo - 1, d, h, m, 0, 0);
  for (let i = 0; i < 2; i++) {
    const offset = tzOffsetMs(guess, timeZone);
    guess = Date.UTC(y, mo - 1, d, h, m, 0, 0) - offset;
  }
  return guess;
}

/** Offset (ms) of timeZone relative to UTC at a given instant. */
export function tzOffsetMs(epochMs: number, timeZone: string): number {
  try {
    const dtf = new Intl.DateTimeFormat("en-US", {
      timeZone,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    const parts = Object.fromEntries(dtf.formatToParts(new Date(epochMs)).map((p) => [p.type, p.value]));
    const asUTC = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second);
    return asUTC - Math.floor(epochMs / 1000) * 1000;
  } catch {
    return -new Date(epochMs).getTimezoneOffset() * 60_000;
  }
}

/**
 * Compute the next prayer for `now`. If all prayers of `today` have passed and
 * `tomorrow` is supplied, uses tomorrow's Fajr; otherwise estimates Fajr + 24h.
 */
export function nextPrayer(today: PrayerTimesDay, now: number, tomorrow?: PrayerTimesDay): NextPrayer {
  const ordered = PRAYER_NAMES.map((name) => ({ name, at: today.times[name] }));
  for (let i = 0; i < ordered.length; i++) {
    if (now < ordered[i].at) {
      const prevAt = i === 0 ? (today.times.Isha - 86_400_000) : ordered[i - 1].at;
      const span = Math.max(1, ordered[i].at - prevAt);
      return {
        name: ordered[i].name,
        at: ordered[i].at,
        remainingMs: ordered[i].at - now,
        current: i === 0 ? "Isha" : ordered[i - 1].name,
        progress: clamp01((now - prevAt) / span),
      };
    }
  }
  const fajrAt = tomorrow ? tomorrow.times.Fajr : today.times.Fajr + 86_400_000;
  const span = Math.max(1, fajrAt - today.times.Isha);
  return {
    name: "Fajr",
    at: fajrAt,
    remainingMs: Math.max(0, fajrAt - now),
    current: "Isha",
    progress: clamp01((now - today.times.Isha) / span),
  };
}

export function formatCountdown(ms: number): { h: string; m: string; s: string } {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return { h: pad(h), m: pad(m), s: pad(s) };
}

export function formatTime(epoch: number, timeZone?: string, hour12 = true): string {
  try {
    return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit", hour12, timeZone }).format(
      new Date(epoch),
    );
  } catch {
    return new Date(epoch).toLocaleTimeString();
  }
}

export function localDateISO(d = new Date(), timeZone?: string): string {
  try {
    const dtf = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" });
    return dtf.format(d); // en-CA yields yyyy-mm-dd
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

function clamp01(n: number) {
  return Math.min(1, Math.max(0, n));
}
