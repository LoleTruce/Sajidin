import { createStore, useStore } from "../core/store";

/**
 * Authentication session — the single source of truth for "who is signed in".
 *
 * Sajidin's web build ships without a backend identity provider. This module therefore
 * holds *state* and a *registration point*; it never fabricates a user. When a provider
 * (e.g. Firebase Auth) is added, it registers itself with `registerAuthProvider` and pushes
 * state changes with `authSession.set(...)`. Everything in the UI reacts to this store.
 */
export type AuthStatus = "unavailable" | "loading" | "signed-out" | "signed-in" | "error";

export interface AuthUser {
  uid: string;
  displayName?: string | null;
  email?: string | null;
}

export interface AuthSession {
  status: AuthStatus;
  /** Convenience mirror of user.uid, read by the preference sync service. */
  uid: string | null;
  user: AuthUser | null;
  error: string | null;
}

export const authSession = createStore<AuthSession>({ status: "unavailable", uid: null, user: null, error: null });

export interface AuthProvider {
  /** Starts the provider's sign-in flow (redirect, popup, native sheet…). Must resolve when the flow has been handed off or completed. */
  signIn(): Promise<void>;
  /** Ends the session. Must throw on failure so the UI can report it. */
  signOut(): Promise<void>;
}

let provider: AuthProvider | null = null;
const providerListeners = new Set<() => void>();

/** Called once by whichever auth integration is bundled. Switches the session out of `unavailable`. */
export function registerAuthProvider(p: AuthProvider | null): void {
  provider = p;
  const cur = authSession.get();
  if (p && cur.status === "unavailable") authSession.set({ status: "loading" });
  if (!p) authSession.set({ status: "unavailable", uid: null, user: null, error: null });
  providerListeners.forEach((l) => l());
}

export function getAuthProvider(): AuthProvider | null {
  return provider;
}

/** Helpers for providers to publish state. */
export const authActions = {
  setSignedIn(user: AuthUser): void {
    authSession.set({ status: "signed-in", uid: user.uid, user, error: null });
  },
  setSignedOut(): void {
    authSession.set({ status: "signed-out", uid: null, user: null, error: null });
  },
  setError(message: string): void {
    authSession.set((s) => ({ ...s, status: "error", error: message }));
  },
};

/* ---------- React hooks ---------- */

export function useAuthSession(): AuthSession {
  return useStore(authSession);
}

export function useHasAuthProvider(): boolean {
  return useStore(providerStore, (s) => s.has);
}

// Tiny derived store so components can subscribe to provider registration.
const providerStore = createStore<{ has: boolean }>({ has: false });
providerListeners.add(() => providerStore.set({ has: provider !== null }));

/** Display label for the current user without inventing data. */
export function describeUser(u: AuthUser | null): { title: string; subtitle: string | null } {
  if (!u) return { title: "Not signed in", subtitle: null };
  if (u.displayName && u.email) return { title: u.displayName, subtitle: u.email };
  if (u.displayName) return { title: u.displayName, subtitle: null };
  if (u.email) return { title: u.email, subtitle: null };
  return { title: "Signed in", subtitle: `ID ${u.uid.slice(0, 8)}…` };
}
