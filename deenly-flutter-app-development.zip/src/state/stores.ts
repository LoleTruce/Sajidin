import { createStore } from "../core/store";
import type { PrayerName, PrayerTimesDay } from "../lib/prayer";
import type { Coords } from "../services/geolocation";

/* ---------- Settings ---------- */
export interface Settings {
  location: Coords | null;
  calculationMethod: number;
  notificationsEnabled: boolean;
  notificationPrayers: Record<PrayerName, boolean>;
  notificationLeadMinutes: number;
  hour12: boolean;
  /** Degrees added to magnetic heading to obtain true heading (east positive). */
  magneticDeclination: number;
  qiblaToleranceDeg: number;
  /** Optional vibration feedback (Tasbih, Qibla alignment, selections). Ignored where the device has no vibrator. */
  hapticsEnabled: boolean;
  hasSeenWelcome: boolean;
}

export const settingsStore = createStore<Settings>(
  {
    location: null,
    calculationMethod: 3,
    notificationsEnabled: false,
    notificationPrayers: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true },
    notificationLeadMinutes: 0,
    hour12: true,
    magneticDeclination: 0,
    qiblaToleranceDeg: 5,
    hapticsEnabled: true,
    hasSeenWelcome: false,
  },
  "settings",
);

/* ---------- Prayer cache ---------- */
export interface PrayerCache {
  today: PrayerTimesDay | null;
  tomorrow: PrayerTimesDay | null;
  fetchedAt: number | null;
  /** Coordinates + method used to produce the cached data */
  key: string | null;
}

export const prayerCacheStore = createStore<PrayerCache>(
  { today: null, tomorrow: null, fetchedAt: null, key: null },
  "prayer-cache",
);

/* ---------- Bookmarks / favourites ---------- */
export interface Bookmarks {
  hadiths: string[];
  duas: string[];
  /** "surah:ayah" keys */
  ayahs: string[];
  /** last read position */
  lastRead: { surah: number; ayah: number; at: number } | null;
}

export const bookmarksStore = createStore<Bookmarks>({ hadiths: [], duas: [], ayahs: [], lastRead: null }, "bookmarks");

export function toggleInList(list: string[], id: string): string[] {
  return list.includes(id) ? list.filter((x) => x !== id) : [...list, id];
}

/* ---------- Tasbih ---------- */
export interface TasbihState {
  count: number;
  target: number;
  /** completed rounds (count wrapped past target) */
  rounds: number;
  totalLifetime: number;
}

export const tasbihStore = createStore<TasbihState>({ count: 0, target: 33, rounds: 0, totalLifetime: 0 }, "tasbih");

/** Pure increment logic (unit tested). Wraps the count when the target is reached. */
export function incrementTasbih(s: TasbihState): TasbihState {
  const next = s.count + 1;
  if (next >= s.target) {
    return { ...s, count: 0, rounds: s.rounds + 1, totalLifetime: s.totalLifetime + 1 };
  }
  return { ...s, count: next, totalLifetime: s.totalLifetime + 1 };
}

export function resetTasbih(s: TasbihState): TasbihState {
  return { ...s, count: 0, rounds: 0 };
}

/* ---------- Quran preferences ---------- */
export interface QuranPrefs {
  arabicScale: number; // 0.85 .. 1.6
  showTranslation: boolean;
  showTransliteration: boolean;
  translationEdition: string;
  reciter: string;
  sideBySide: boolean;
}

export const quranPrefsStore = createStore<QuranPrefs>(
  {
    arabicScale: 1,
    showTranslation: true,
    showTransliteration: false,
    translationEdition: "en.sahih",
    reciter: "ar.alafasy",
    sideBySide: false,
  },
  "quran-prefs",
);
