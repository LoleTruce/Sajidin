import { BRAND } from "../core/brand";
import { createStore } from "../core/store";
import { ayahAudioUrl, RECITERS, type Ayah, type SurahMeta } from "../services/quranApi";

export type PlaybackStatus = "idle" | "loading" | "playing" | "paused" | "error";

export interface AudioState {
  status: PlaybackStatus;
  surah: SurahMeta | null;
  ayahs: Ayah[];
  index: number; // index into ayahs
  reciter: string;
  currentTime: number;
  duration: number;
  error: string | null;
  autoAdvance: boolean;
}

export const audioStore = createStore<AudioState>({
  status: "idle",
  surah: null,
  ayahs: [],
  index: 0,
  reciter: "ar.alafasy",
  currentTime: 0,
  duration: 0,
  error: null,
  autoAdvance: true,
});

let audio: HTMLAudioElement | null = null;
let retryCount = 0;

function el(): HTMLAudioElement {
  if (audio) return audio;
  audio = new Audio();
  audio.preload = "auto";
  audio.addEventListener("timeupdate", () => {
    const a = audio!;
    audioStore.set({ currentTime: a.currentTime, duration: Number.isFinite(a.duration) ? a.duration : 0 });
    updatePositionState();
  });
  audio.addEventListener("waiting", () => {
    if (audioStore.get().status === "playing") audioStore.set({ status: "loading" });
  });
  audio.addEventListener("playing", () => {
    retryCount = 0;
    audioStore.set({ status: "playing", error: null });
    setSessionState("playing");
  });
  audio.addEventListener("pause", () => {
    const s = audioStore.get();
    if (s.status !== "idle" && s.status !== "error" && !audio!.ended) {
      audioStore.set({ status: "paused" });
      setSessionState("paused");
    }
  });
  audio.addEventListener("ended", () => {
    const s = audioStore.get();
    if (s.autoAdvance && s.index < s.ayahs.length - 1) {
      void loadAndPlay(s.index + 1);
    } else {
      audioStore.set({ status: "paused", currentTime: 0 });
      setSessionState("paused");
    }
  });
  audio.addEventListener("error", () => {
    const s = audioStore.get();
    if (retryCount < 2 && s.ayahs.length) {
      retryCount++;
      window.setTimeout(() => void loadAndPlay(s.index), 600 * retryCount);
      return;
    }
    audioStore.set({ status: "error", error: "Audio could not be loaded. Check your connection and try again." });
  });
  return audio;
}

function reciterName(id: string): string {
  return RECITERS.find((r) => r.id === id)?.name ?? "Quran recitation";
}

function setSessionState(state: MediaSessionPlaybackState) {
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = state;
}

function updatePositionState() {
  try {
    const a = audio;
    if (!a || !("mediaSession" in navigator) || !Number.isFinite(a.duration) || !navigator.mediaSession.setPositionState)
      return;
    navigator.mediaSession.setPositionState({ duration: a.duration, playbackRate: a.playbackRate, position: a.currentTime });
  } catch {
    /* ignore */
  }
}

function updateMetadata() {
  const s = audioStore.get();
  if (!("mediaSession" in navigator) || !s.surah) return;
  const ayah = s.ayahs[s.index];
  navigator.mediaSession.metadata = new MediaMetadata({
    title: `${s.surah.englishName} · Ayah ${ayah?.numberInSurah ?? ""}`,
    artist: reciterName(s.reciter),
    album: `${BRAND.name} — The Holy Quran`,
  });
  navigator.mediaSession.setActionHandler("play", () => void audioController.play());
  navigator.mediaSession.setActionHandler("pause", () => audioController.pause());
  navigator.mediaSession.setActionHandler("previoustrack", () => void audioController.prev());
  navigator.mediaSession.setActionHandler("nexttrack", () => void audioController.next());
  try {
    navigator.mediaSession.setActionHandler("seekto", (d) => {
      if (typeof d.seekTime === "number") audioController.seek(d.seekTime);
    });
  } catch {
    /* unsupported action */
  }
}

async function loadAndPlay(index: number): Promise<void> {
  const s = audioStore.get();
  const ayah = s.ayahs[index];
  if (!ayah) return;
  const a = el();
  audioStore.set({ index, status: "loading", error: null, currentTime: 0, duration: 0 });
  a.src = ayahAudioUrl(s.reciter, ayah.number);
  updateMetadata();
  try {
    await a.play();
  } catch (e) {
    // Autoplay policies / interrupted loads — surface as paused so the user can tap play.
    if ((e as DOMException)?.name === "AbortError") return;
    audioStore.set({ status: "paused" });
  }
}

export const audioController = {
  /** Loads a surah playlist and begins playback at the given ayah index. */
  async playSurah(surah: SurahMeta, ayahs: Ayah[], startIndex = 0, reciter?: string): Promise<void> {
    const r = reciter ?? audioStore.get().reciter;
    audioStore.set({ surah, ayahs, reciter: r });
    retryCount = 0;
    await loadAndPlay(startIndex);
  },
  async play(): Promise<void> {
    const s = audioStore.get();
    if (!s.ayahs.length) return;
    if (s.status === "error") return loadAndPlay(s.index);
    try {
      await el().play();
    } catch {
      /* ignore */
    }
  },
  pause(): void {
    el().pause();
  },
  async toggle(): Promise<void> {
    const s = audioStore.get();
    if (s.status === "playing" || s.status === "loading") this.pause();
    else await this.play();
  },
  async next(): Promise<void> {
    const s = audioStore.get();
    if (s.index < s.ayahs.length - 1) await loadAndPlay(s.index + 1);
  },
  async prev(): Promise<void> {
    const s = audioStore.get();
    if (el().currentTime > 3) {
      el().currentTime = 0;
      return;
    }
    if (s.index > 0) await loadAndPlay(s.index - 1);
  },
  async jumpTo(index: number): Promise<void> {
    await loadAndPlay(index);
  },
  seek(time: number): void {
    const a = el();
    if (Number.isFinite(a.duration)) a.currentTime = Math.min(Math.max(0, time), a.duration);
  },
  setReciter(reciter: string): void {
    const s = audioStore.get();
    const wasPlaying = s.status === "playing" || s.status === "loading";
    audioStore.set({ reciter });
    if (s.ayahs.length) {
      if (wasPlaying) void loadAndPlay(s.index);
      else updateMetadata();
    }
  },
  stop(): void {
    const a = el();
    a.pause();
    a.removeAttribute("src");
    a.load();
    audioStore.set({ status: "idle", surah: null, ayahs: [], index: 0, currentTime: 0, duration: 0, error: null });
    setSessionState("none");
  },
};
