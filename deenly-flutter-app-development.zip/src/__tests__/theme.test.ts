// @vitest-environment happy-dom
import { beforeEach, describe, expect, it, vi } from "vitest";
import { contrastRatio, ensureContrast, hexToRgb, mix, pickOnColor, rgbToHex } from "../theme/color";
import { ACCENTS, ACCENT_IDS, MODES, THEME_MODES, resolveTheme } from "../theme/tokens";
import { DEFAULT_PREFS, PREF_KEYS, clearLocalPrefs, loadLocalPrefs, parsePrefs, saveLocalPrefs } from "../theme/preferences";
import { resetAppliedThemeCache } from "../theme/apply";
import { themeController, themeStore } from "../theme/themeStore";
import { AppearanceSyncService, LocalProfileAdapter, authSession, parseCloudDoc, type AppearanceSyncAdapter } from "../theme/sync";

beforeEach(() => {
  localStorage.clear();
  clearLocalPrefs();
  resetAppliedThemeCache();
  themeController._resetForTests();
  authSession.set({ uid: null });
  document.documentElement.removeAttribute("style");
});

/* ------------------------------------------------------------------ */
describe("colour utilities", () => {
  it("round-trips hex", () => {
    expect(rgbToHex(hexToRgb("#00B388"))).toBe("#00B388");
    expect(rgbToHex(hexToRgb("#fff"))).toBe("#FFFFFF");
    expect(() => hexToRgb("#zzz")).toThrow();
  });
  it("computes WCAG contrast", () => {
    expect(contrastRatio("#000000", "#FFFFFF")).toBeCloseTo(21, 0);
    expect(contrastRatio("#FFFFFF", "#FFFFFF")).toBe(1);
  });
  it("ensureContrast reaches the target ratio on light and dark backgrounds", () => {
    const onWhite = ensureContrast("#00B388", "#FFFFFF", 4.5);
    expect(contrastRatio(onWhite, "#FFFFFF")).toBeGreaterThanOrEqual(4.5);
    const onDark = ensureContrast("#1E0836", "#121214", 4.5);
    expect(contrastRatio(onDark, "#121214")).toBeGreaterThanOrEqual(4.5);
    expect(ensureContrast("#FFFFFF", "#121214")).toBe("#FFFFFF"); // already passes → unchanged
  });
  it("pickOnColor chooses the higher-contrast foreground", () => {
    expect(pickOnColor("#00B388", "#06231C")).toBe("#06231C");
    expect(pickOnColor("#8A2BE2", "#1E0836")).toBe("#FFFFFF");
    expect(mix("#000000", "#FFFFFF", 0.5)).toBe("#808080");
  });
});

/* ------------------------------------------------------------------ */
describe("theme resolution", () => {
  it("produces the exact brand surfaces for each mode", () => {
    expect(resolveTheme("dark", "mint").vars["--t-bg"]).toBe("#121214");
    expect(resolveTheme("dark", "mint").vars["--t-card"]).toBe("#1E1E24");
    expect(resolveTheme("light", "mint").vars["--t-bg"]).toBe("#F8F9FA");
    expect(resolveTheme("light", "mint").vars["--t-card"]).toBe("#FFFFFF");
    expect(resolveTheme("sepia", "mint").vars["--t-bg"]).toBe("#F4ECD8");
    expect(resolveTheme("sepia", "mint").vars["--t-card"]).not.toBe("#FFFFFF"); // no pure white in sepia
    expect(resolveTheme("sepia", "mint").vars["--t-ink"]).not.toBe("#000000"); // no harsh black in sepia
  });

  it("uses the exact accent hex as the fill colour and a legible accent for text in every combination", () => {
    for (const mode of THEME_MODES) {
      for (const accent of ACCENT_IDS) {
        const t = resolveTheme(mode, accent);
        expect(t.vars["--t-brand"]).toBe(ACCENTS[accent].hex);
        expect(contrastRatio(t.vars["--t-brand-ink"], MODES[mode].bg)).toBeGreaterThanOrEqual(4.5);
        expect(contrastRatio(t.vars["--t-brand-ink"], MODES[mode].card)).toBeGreaterThanOrEqual(4.5);
        expect(contrastRatio(t.vars["--t-on-brand"], t.vars["--t-brand"])).toBeGreaterThanOrEqual(4.5);
        expect(contrastRatio(MODES[mode].ink, MODES[mode].bg)).toBeGreaterThanOrEqual(7);
        expect(contrastRatio(MODES[mode].muted, MODES[mode].card)).toBeGreaterThanOrEqual(4.5);
      }
    }
  });

  it("memoises resolved themes", () => {
    expect(resolveTheme("light", "blue")).toBe(resolveTheme("light", "blue"));
  });
});

/* ------------------------------------------------------------------ */
describe("preference parsing & persistence", () => {
  it("falls back field-by-field on unknown values", () => {
    expect(parsePrefs({ mode: "neon", accent: "blue", updatedAt: 5 })).toEqual({ prefs: { mode: "dark", accent: "blue", updatedAt: 5 }, valid: true });
    expect(parsePrefs({ mode: "sepia", accent: 42, updatedAt: "x" })).toEqual({ prefs: { mode: "sepia", accent: "mint", updatedAt: 0 }, valid: true });
    expect(parsePrefs(null)).toEqual({ prefs: DEFAULT_PREFS, valid: false });
    expect(parsePrefs({ foo: 1 }).valid).toBe(false);
  });

  it("stores plain identifiers under stable keys and reloads them", () => {
    expect(saveLocalPrefs({ mode: "sepia", accent: "amber", updatedAt: 123 })).toBe(true);
    expect(localStorage.getItem(PREF_KEYS.mode)).toBe("sepia");
    expect(localStorage.getItem(PREF_KEYS.accent)).toBe("amber");
    expect(loadLocalPrefs()).toEqual({ prefs: { mode: "sepia", accent: "amber", updatedAt: 123 }, valid: true });
  });

  it("survives corrupt storage and a throwing storage backend", () => {
    localStorage.setItem(PREF_KEYS.mode, "{broken");
    localStorage.setItem(PREF_KEYS.accent, "");
    expect(loadLocalPrefs().prefs).toEqual(DEFAULT_PREFS);
    const throwing = {
      getItem: () => {
        throw new Error("denied");
      },
      setItem: () => {
        throw new Error("denied");
      },
      removeItem: () => {},
    };
    expect(loadLocalPrefs(throwing).prefs).toEqual(DEFAULT_PREFS);
    expect(saveLocalPrefs(DEFAULT_PREFS, throwing)).toBe(false);
  });
});

/* ------------------------------------------------------------------ */
describe("themeController", () => {
  it("boots to Dark + Mint on a fresh install and applies tokens to <html>", () => {
    const s = themeController.init();
    expect(s.mode).toBe("dark");
    expect(s.accent).toBe("mint");
    expect(document.documentElement.dataset.theme).toBe("dark");
    expect(document.documentElement.style.getPropertyValue("--t-brand")).toBe("#00B388");
    expect(document.querySelector('meta[name="theme-color"]')?.getAttribute("content")).toBe("#121214");
  });

  it("applies changes immediately, persists them and restores after a restart", () => {
    themeController.init();
    themeController.setThemeMode("sepia");
    themeController.setAccent("orchid");
    expect(document.documentElement.dataset.theme).toBe("sepia");
    expect(document.documentElement.style.getPropertyValue("--t-brand")).toBe("#8A2BE2");
    expect(document.documentElement.style.colorScheme).toBe("light");

    // Simulate restart: fresh in-memory state, same storage.
    themeController._resetForTests();
    resetAppliedThemeCache();
    const s = themeController.init();
    expect(s.mode).toBe("sepia");
    expect(s.accent).toBe("orchid");
  });

  it("ignores unknown identifiers and does not notify on no-op changes", () => {
    themeController.init();
    const spy = vi.fn();
    themeController.onChange(spy);
    themeController.setThemeMode("neon" as never);
    themeController.setAccent("mint"); // already mint
    expect(spy).not.toHaveBeenCalled();
    themeController.setAccent("blue");
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it("resets to defaults and persists the reset", () => {
    themeController.init();
    themeController.setThemeMode("light");
    themeController.setAccent("amber");
    themeController.resetToDefaults();
    expect(themeStore.get()).toMatchObject({ mode: "dark", accent: "mint" });
    expect(loadLocalPrefs().prefs).toMatchObject({ mode: "dark", accent: "mint" });
  });

  it("init does not overwrite a stored choice on repeated calls", () => {
    saveLocalPrefs({ mode: "light", accent: "blue", updatedAt: 10 });
    themeController.init();
    themeController.init();
    expect(themeStore.get().mode).toBe("light");
  });
});

/* ------------------------------------------------------------------ */
describe("AppearanceSyncService", () => {
  const flush = () => new Promise((r) => setTimeout(r, 0));

  it("parses the cloud document shape including Firestore-style timestamps", () => {
    expect(parseCloudDoc({ themeMode: "light", accentColor: "blue", updatedAt: { toMillis: () => 99 } })).toEqual({ prefs: { mode: "light", accent: "blue", updatedAt: 99 }, valid: true });
    expect(parseCloudDoc({ themeMode: "plasma", accentColor: "neon" }).valid).toBe(false);
  });

  it("uploads local settings when the profile has no record, and restores cloud settings on sign-in elsewhere", async () => {
    themeController.init();
    const adapter = new LocalProfileAdapter(localStorage);
    const svc = new AppearanceSyncService({ adapter, debounceMs: 0 });
    svc.start();

    themeController.setThemeMode("light");
    authSession.set({ uid: "user-a" });
    await flush();
    await flush();
    expect(await adapter.read("user-a")).toMatchObject({ themeMode: "light", accentColor: "mint" });
    expect(themeStore.get().sync).toBe("synced");

    // "Another device": pristine local state, same account → cloud restored.
    svc.stop();
    authSession.set({ uid: null });
    themeController._resetForTests();
    clearLocalPrefs();
    resetAppliedThemeCache();
    themeController.init();
    expect(themeStore.get().mode).toBe("dark");
    const svc2 = new AppearanceSyncService({ adapter, debounceMs: 0 });
    svc2.start();
    authSession.set({ uid: "user-a" });
    await flush();
    await flush();
    expect(themeStore.get().mode).toBe("light");
    svc2.stop();
  });

  it("debounces rapid changes into one write and never writes to a previous account", async () => {
    themeController.init();
    const writes: Array<{ uid: string; mode: string }> = [];
    const adapter: AppearanceSyncAdapter = {
      read: async () => null,
      write: async (uid, p) => {
        writes.push({ uid, mode: p.mode });
      },
    };
    const svc = new AppearanceSyncService({ adapter, debounceMs: 20 });
    svc.start();
    authSession.set({ uid: "user-a" });
    await flush();
    writes.length = 0;

    themeController.setThemeMode("light");
    themeController.setThemeMode("sepia");
    themeController.setThemeMode("light");
    expect(themeStore.get().sync).toBe("pending");
    await new Promise((r) => setTimeout(r, 40));
    expect(writes).toEqual([{ uid: "user-a", mode: "light" }]);

    // Change, then sign out before the debounce fires → write must be dropped.
    themeController.setThemeMode("sepia");
    authSession.set({ uid: null });
    await new Promise((r) => setTimeout(r, 40));
    expect(writes).toHaveLength(1);
    expect(themeStore.get().sync).toBe("signed-out");
    expect(themeStore.get().mode).toBe("sepia"); // local preference preserved after sign-out

    // Switch to a different account: their (empty) profile receives the *current* local prefs, not a stale queue.
    authSession.set({ uid: "user-b" });
    await flush();
    await flush();
    expect(writes.filter((w) => w.uid === "user-b")).toEqual([{ uid: "user-b", mode: "sepia" }]);
    svc.stop();
  });

  it("last write wins: newer local changes are uploaded instead of being overwritten by older cloud data", async () => {
    themeController.init();
    const adapter = new LocalProfileAdapter(localStorage);
    await adapter.write("user-a", { mode: "light", accent: "blue", updatedAt: 1_000 });
    themeController.applyRemote({ mode: "sepia", accent: "amber", updatedAt: 2_000 }); // local newer
    const svc = new AppearanceSyncService({ adapter, debounceMs: 0 });
    svc.start();
    authSession.set({ uid: "user-a" });
    await flush();
    await flush();
    expect(themeStore.get().mode).toBe("sepia");
    expect(await adapter.read("user-a")).toMatchObject({ themeMode: "sepia", accentColor: "amber" });
    svc.stop();
  });

  it("keeps local changes working when the cloud fails, and retries when back online", async () => {
    themeController.init();
    let online = false;
    let fail = true;
    const writes: string[] = [];
    const adapter: AppearanceSyncAdapter = {
      read: async () => null,
      write: async (_uid, p) => {
        if (fail) throw Object.assign(new Error("boom"), { code: "unavailable" });
        writes.push(p.mode);
      },
    };
    const svc = new AppearanceSyncService({ adapter, debounceMs: 0, isOnline: () => online });
    svc.start();
    authSession.set({ uid: "user-a" });
    await flush();
    expect(themeStore.get().sync).toBe("error"); // initial upload failed
    themeController.setThemeMode("light");
    expect(themeStore.get().mode).toBe("light"); // UI updated regardless
    await flush();
    expect(themeStore.get().sync).toBe("pending");

    fail = false;
    online = true;
    window.dispatchEvent(new Event("online"));
    await flush();
    await flush();
    expect(writes).toEqual(["light"]);
    expect(themeStore.get().sync).toBe("synced");
    svc.stop();
  });
});
