import { describe, expect, it } from "vitest";
import { angleDelta, continuousRotation, distanceToKaabaKm, isAligned, normalizeDegrees, qiblaBearing, smoothHeading } from "../lib/qibla";

describe("qiblaBearing", () => {
  it("computes known bearings (±1°)", () => {
    expect(qiblaBearing(51.5074, -0.1278)).toBeCloseTo(118.99, 0); // London ≈ 119°
    expect(qiblaBearing(40.7128, -74.006)).toBeCloseTo(58.48, 0); // New York ≈ 58°
    expect(qiblaBearing(24.8607, 67.0011)).toBeCloseTo(267.7, 0); // Karachi ≈ 268°
    expect(qiblaBearing(-6.2088, 106.8456)).toBeCloseTo(295.1, 0); // Jakarta ≈ 295°
    expect(qiblaBearing(30.0444, 31.2357)).toBeCloseTo(136.1, 0); // Cairo ≈ 136°
  });

  it("returns a value in [0, 360)", () => {
    for (const [lat, lng] of [
      [0, 0],
      [-33.9, 151.2],
      [64.1, -21.9],
      [21.4225, 39.8262],
    ]) {
      const b = qiblaBearing(lat, lng);
      expect(b).toBeGreaterThanOrEqual(0);
      expect(b).toBeLessThan(360);
    }
  });

  it("distance to Kaaba from Madinah ≈ 340 km", () => {
    expect(distanceToKaabaKm(24.4672, 39.6111)).toBeGreaterThan(330);
    expect(distanceToKaabaKm(24.4672, 39.6111)).toBeLessThan(350);
  });
});

describe("angle helpers", () => {
  it("normalises degrees", () => {
    expect(normalizeDegrees(-10)).toBe(350);
    expect(normalizeDegrees(370)).toBe(10);
    expect(normalizeDegrees(360)).toBe(0);
  });

  it("computes shortest signed delta across the wrap", () => {
    expect(angleDelta(350, 10)).toBe(20);
    expect(angleDelta(10, 350)).toBe(-20);
    expect(angleDelta(0, 180)).toBe(180);
  });

  it("alignment respects tolerance and wrap-around", () => {
    expect(isAligned(357, 2, 5)).toBe(true);
    expect(isAligned(350, 2, 5)).toBe(false);
    expect(isAligned(119, 119.4, 1)).toBe(true);
  });

  it("smoothing is wrap-aware and converges", () => {
    let h: number | null = null;
    for (let i = 0; i < 60; i++) h = smoothHeading(h, 2);
    expect(h!).toBeCloseTo(2, 1);
    const s = smoothHeading(358, 2, 0.5);
    expect(s).toBeCloseTo(0, 5); // halfway from 358 → 2 through north, not through 180
  });

  it("continuous rotation never jumps the long way", () => {
    const r = continuousRotation(355, 5);
    expect(r).toBe(365);
    const r2 = continuousRotation(-355, 355);
    expect(r2).toBe(-365);
  });
});
