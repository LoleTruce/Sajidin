// @vitest-environment happy-dom
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import App from "../App";
import { FIRST_LAUNCH_KEY, onboarding, onboardingStore, readLaunchState } from "../features/onboarding/onboardingStore";
import { requestDeviceLocation } from "../features/onboarding/locationFlow";
import { LANGUAGE_PREF_KEY, locale } from "../i18n";
import { defaultMethodForCountry } from "../lib/calculationDefaults";
import { citiesFor, COUNTRIES, getCountry, isValidCoordinate, searchCities, searchCountries } from "../services/geoData";
import { quranPrefsStore, settingsStore } from "../state/stores";
import { themeController } from "../theme/themeStore";

beforeAll(() => {
  vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new Error("offline"))));
  vi.stubGlobal("IntersectionObserver", class {
    observe() {}
    disconnect() {}
    unobserve() {}
  });
  vi.stubGlobal("DeviceOrientationEvent", undefined);
  Object.defineProperty(window, "matchMedia", {
    value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }),
  });
});

beforeEach(() => {
  localStorage.clear();
  themeController._resetForTests();
  themeController.init();
  locale.setLanguage("en");
  onboarding._resetForTests();
  settingsStore.set({ location: null, calculationMethod: 3, hasSeenWelcome: false });
  quranPrefsStore.set({ translationEdition: "en.sahih" });
});

afterEach(() => {
  cleanup();
  window.history.replaceState(null, "");
});

/* ------------------------------------------------------------------ */
describe("first-launch detection", () => {
  it("fresh install → first-launch; completed flag → completed; never flips on rebuilds", () => {
    expect(readLaunchState()).toEqual({ kind: "first-launch" });
    expect(readLaunchState()).toEqual({ kind: "first-launch" }); // reading does not mutate
    localStorage.setItem(FIRST_LAUNCH_KEY, "false");
    expect(readLaunchState()).toEqual({ kind: "completed" });
    localStorage.setItem(FIRST_LAUNCH_KEY, "true");
    expect(readLaunchState()).toEqual({ kind: "first-launch" });
  });

  it("migrates pre-wizard installs (hasSeenWelcome) so existing users are not re-onboarded", () => {
    localStorage.setItem("deenly:settings", JSON.stringify({ hasSeenWelcome: true, calculationMethod: 2 }));
    expect(readLaunchState()).toEqual({ kind: "completed" });
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBe("false");
  });

  it("treats corrupt legacy settings as a fresh install and a failing storage as storage-error (never 'completed')", () => {
    localStorage.setItem("deenly:settings", "{nope");
    expect(readLaunchState()).toEqual({ kind: "first-launch" });
    const throwing = {
      getItem: () => {
        throw new Error("denied");
      },
      setItem: () => {},
    };
    expect(readLaunchState(throwing)).toEqual({ kind: "storage-error" });
  });
});

/* ------------------------------------------------------------------ */
describe("location dataset & defaults", () => {
  it("bundles every country and real GeoNames cities with valid coordinates", () => {
    expect(COUNTRIES.length).toBeGreaterThanOrEqual(240);
    expect(getCountry("SA")?.name).toBe("Saudi Arabia");
    const sa = citiesFor("SA");
    expect(sa[0].capital).toBe(true); // capital first
    const makkah = sa.find((c) => c.name === "Makkah")!;
    expect(makkah.lat).toBeCloseTo(21.4266, 3);
    expect(makkah.lng).toBeCloseTo(39.8256, 3);
    for (const code of ["GB", "US", "PK", "ID", "TR"]) for (const c of citiesFor(code)) expect(isValidCoordinate(c.lat, c.lng)).toBe(true);
    expect(searchCountries("kingd").map((c) => c.code)).toContain("GB");
    expect(searchCities("TR", "istan")[0].name).toBe("Istanbul");
    expect(searchCities("GB", "zzzz")).toEqual([]);
  });

  it("validates coordinates", () => {
    expect(isValidCoordinate(51.5, -0.12)).toBe(true);
    expect(isValidCoordinate(91, 0)).toBe(false);
    expect(isValidCoordinate(0, 181)).toBe(false);
    expect(isValidCoordinate(NaN, 0)).toBe(false);
    expect(isValidCoordinate("51" as unknown, 0)).toBe(false);
  });

  it("maps countries to regional calculation defaults with MWL fallback", () => {
    expect(defaultMethodForCountry("US")).toBe(2);
    expect(defaultMethodForCountry("pk")).toBe(1);
    expect(defaultMethodForCountry("TR")).toBe(13);
    expect(defaultMethodForCountry("DE")).toBe(3);
    expect(defaultMethodForCountry(null)).toBe(3);
  });
});

/* ------------------------------------------------------------------ */
describe("onboarding controller", () => {
  it("clamps steps and preserves selections when moving backward", () => {
    onboarding.back();
    expect(onboardingStore.get().step).toBe(0);
    onboarding.setLanguage("tr");
    onboarding.next();
    onboarding.next();
    onboarding.next();
    expect(onboardingStore.get().step).toBe(2);
    onboarding.back();
    expect(onboardingStore.get().language).toBe("tr");
    expect(document.documentElement.lang).toBe("tr");
  });

  it("rejects invalid coordinates and derives the method from the manual country", () => {
    expect(onboarding.setManualPlace({ countryCode: "PK", countryName: "Pakistan", city: "X", lat: 999, lng: 0, source: "dataset" })).toBe(false);
    expect(onboarding.setManualPlace({ countryCode: "PK", countryName: "Pakistan", city: "Lahore", lat: 31.558, lng: 74.351, source: "dataset" })).toBe(true);
    expect(onboardingStore.get().calculationMethod).toBe(1);
    onboarding.setCalculationMethod(3);
    onboarding.setManualPlace({ countryCode: "US", countryName: "United States", city: "Dearborn", lat: 42.32, lng: -83.18, source: "dataset" });
    expect(onboardingStore.get().calculationMethod).toBe(3); // user's explicit choice is kept
  });

  it("complete() persists language, location, method and Quran edition BEFORE flipping the flag", async () => {
    onboarding.setLanguage("ur");
    onboarding.setManualPlace({ countryCode: "PK", countryName: "Pakistan", city: "Lahore", lat: 31.558, lng: 74.351, source: "dataset" });
    const r = await onboarding.complete({ allowNoLocation: false });
    expect(r.ok).toBe(true);
    expect(localStorage.getItem(LANGUAGE_PREF_KEY)).toBe("ur");
    expect(settingsStore.get().location).toMatchObject({ lat: 31.558, lng: 74.351, label: "Lahore, Pakistan", source: "manual" });
    expect(settingsStore.get().calculationMethod).toBe(1);
    expect(quranPrefsStore.get().translationEdition).toBe("ur.jalandhry");
    expect(JSON.parse(localStorage.getItem("deenly:settings")!).location.lat).toBe(31.558);
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBe("false");
    expect(readLaunchState()).toEqual({ kind: "completed" });
  });

  it("refuses to complete without a location unless explicitly allowed, and never marks complete on failure", async () => {
    const r1 = await onboarding.complete({ allowNoLocation: false });
    expect(r1.ok).toBe(false);
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBeNull();
    const r2 = await onboarding.complete({ allowNoLocation: true });
    expect(r2.ok).toBe(true);
    expect(settingsStore.get().location).toBeNull(); // existing screens handle null gracefully
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBe("false");
  });

  it("does not flip the flag when the final write fails or the settings round-trip cannot be verified", async () => {
    const failingWrite = {
      getItem: (k: string) => localStorage.getItem(k),
      setItem: () => {
        throw new Error("QuotaExceeded");
      },
    };
    const r = await onboarding.complete({ allowNoLocation: true }, failingWrite);
    expect(r.ok).toBe(false);
    expect(onboardingStore.get().completeError).toBe(locale.t("ob.loc.saveFailed")); // friendly, never the raw exception
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBeNull();

    const unverifiable = { getItem: () => null, setItem: () => {} };
    const r2 = await onboarding.complete({ allowNoLocation: true }, unverifiable);
    expect(r2.ok).toBe(false);
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBeNull();
  });

  it("prevents duplicate completion requests", async () => {
    onboardingStore.set({ completing: true });
    expect((await onboarding.complete({ allowNoLocation: true })).ok).toBe(false);
    onboardingStore.set({ completing: false });
  });
});

/* ------------------------------------------------------------------ */
describe("device location flow", () => {
  it("does not re-prompt when permission is already denied", async () => {
    const getCurrentPosition = vi.fn();
    vi.stubGlobal("navigator", { ...navigator, geolocation: { getCurrentPosition }, permissions: { query: async () => ({ state: "denied" }) }, onLine: true, languages: ["en-US"], language: "en-US" });
    expect(await requestDeviceLocation()).toEqual({ ok: false, reason: "blocked" });
    expect(getCurrentPosition).not.toHaveBeenCalled();
    vi.unstubAllGlobals();
  });

  it("uses real coordinates from the OS fix and rejects invalid ones", async () => {
    const mk = (lat: number, lng: number) => ({
      ...navigator,
      geolocation: { getCurrentPosition: (ok: PositionCallback) => ok({ coords: { latitude: lat, longitude: lng } } as GeolocationPosition) },
      permissions: { query: async () => ({ state: "prompt" }) },
      onLine: true,
      languages: ["en-US"],
      language: "en-US",
    });
    vi.stubGlobal("navigator", mk(24.7136, 46.6753));
    const r = await requestDeviceLocation();
    expect(r.ok && r.coords.lat).toBeCloseTo(24.7136, 4);
    vi.stubGlobal("navigator", mk(NaN, 10));
    expect(await requestDeviceLocation()).toEqual({ ok: false, reason: "invalid" });
    vi.unstubAllGlobals();
  });
});

/* ------------------------------------------------------------------ */
describe("onboarding wizard (widget)", () => {
  it("fresh install → wizard → language → manual city → Complete Setup → main shell; restart bypasses wizard", async () => {
    const { unmount } = render(<App />);
    expect(screen.getByText("Welcome to Sajidin")).toBeTruthy();
    expect(screen.queryByRole("navigation", { name: "Primary" })).toBeNull(); // main shell not shown underneath

    fireEvent.click(screen.getByRole("button", { name: "Get Started" }));
    await screen.findByRole("radio", { name: /Turkish/ });
    fireEvent.click(screen.getByRole("radio", { name: /Turkish/ }));
    expect(document.documentElement.lang).toBe("tr");
    expect(screen.getByRole("radio", { name: /Turkish/ }).getAttribute("aria-checked")).toBe("true");
    // Wizard itself re-renders in the chosen language
    fireEvent.click(screen.getByRole("button", { name: /Devam/ }));
    await screen.findByText("Konumunuzu Ayarlayın");

    // Manual selection: country → city sheet (filtered to that country)
    fireEvent.click(screen.getByRole("button", { name: /Ülke:/ }));
    const countrySheet = await screen.findByRole("dialog", { name: "Ülke" });
    fireEvent.change(within(countrySheet).getByRole("textbox"), { target: { value: "Turkey" } });
    fireEvent.click(await within(countrySheet).findByRole("option", { name: /^Turkey/ }));
    const citySheet = await screen.findByRole("dialog", { name: /Şehir · Turkey/ });
    fireEvent.change(within(citySheet).getByRole("textbox"), { target: { value: "Ankara" } });
    fireEvent.click(await within(citySheet).findByRole("option", { name: /Ankara/ }));

    await waitFor(() => expect(screen.getByText(/Seçilen: Ankara, Turkey/)).toBeTruthy());
    expect(screen.getByText(/Hesaplama yöntemi/)).toBeTruthy();
    expect(onboardingStore.get().calculationMethod).toBe(13); // Diyanet default for TR

    const completeBtn = screen.getByRole("button", { name: /Kurulumu Tamamla/ });
    expect((completeBtn as HTMLButtonElement).disabled).toBe(false);
    await act(async () => {
      fireEvent.click(completeBtn);
    });
    await screen.findByRole("navigation", { name: "Primary" }); // main shell
    expect(screen.getByRole("button", { name: "Kıble" })).toBeTruthy(); // tab labels follow the language

    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBe("false");
    expect(localStorage.getItem(LANGUAGE_PREF_KEY)).toBe("tr");
    const saved = JSON.parse(localStorage.getItem("deenly:settings")!);
    expect(saved.location.label).toBe("Ankara, Turkey");
    expect(saved.location.lat).toBeCloseTo(39.92, 1);
    expect(saved.calculationMethod).toBe(13);
    expect(quranPrefsStore.get().translationEdition).toBe("tr.diyanet");

    // "Restart": fresh mount with the same storage bypasses onboarding.
    unmount();
    render(<App />);
    expect(screen.queryByText(/Welcome to Sajidin|Sajidin'e Hoş Geldiniz/)).toBeNull();
    expect(screen.getByRole("navigation", { name: "Primary" })).toBeTruthy();
    locale.setLanguage("en");
  });

  it("Complete Setup is disabled without a location; 'continue without location' is offered and works", async () => {
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Get Started" }));
    fireEvent.click(await screen.findByRole("button", { name: /Continue/ }));
    await screen.findByText("Set Your Location");
    expect((screen.getByRole("button", { name: /Complete Setup/ }) as HTMLButtonElement).disabled).toBe(true);
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /Continue without location/ }));
    });
    await screen.findByRole("navigation", { name: "Primary" });
    expect(localStorage.getItem(FIRST_LAUNCH_KEY)).toBe("false");
    expect(settingsStore.get().location).toBeNull();
  });

  it("shows the wizard with a warning when storage cannot be read, instead of assuming setup is done", () => {
    const real = localStorage;
    vi.stubGlobal("localStorage", {
      getItem: () => {
        throw new Error("denied");
      },
      setItem: () => {
        throw new Error("denied");
      },
      removeItem: () => {},
      clear: () => {},
      key: () => null,
      length: 0,
    });
    render(<App />);
    vi.stubGlobal("localStorage", real);
    expect(screen.getByText("Welcome to Sajidin")).toBeTruthy();
    expect(screen.getByRole("alert").textContent).toMatch(/couldn't be saved/);
  });
});
