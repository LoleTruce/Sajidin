// @vitest-environment happy-dom
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

afterEach(() => {
  cleanup();
  window.history.replaceState(null, "");
});

// These tests exercise the main shell; mark first-launch onboarding as already completed.
beforeEach(() => localStorage.setItem("deenly_isFirstLaunch", "false"));
import App from "../App";
import { tasbihStore } from "../state/stores";
import { themeController } from "../theme/themeStore";

beforeAll(() => {
  // Keep external services out of the test run.
  vi.stubGlobal(
    "fetch",
    vi.fn(() => Promise.reject(new Error("offline"))),
  );
  vi.stubGlobal("IntersectionObserver", class {
    observe() {}
    disconnect() {}
    unobserve() {}
  });
  vi.stubGlobal("DeviceOrientationEvent", undefined);
  Object.defineProperty(window, "matchMedia", {
    value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }),
  });
});

describe("Sajidin app shell", () => {
  it("renders the four tabs and navigates between them", async () => {
    render(<App />);
    expect(screen.getByRole("navigation", { name: "Primary" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Quran" })).toBeTruthy();

    await waitFor(() => expect(screen.getByText("Assalamu alaikum")).toBeTruthy());

    fireEvent.click(screen.getByRole("button", { name: "Qibla" }));
    await waitFor(() => expect(screen.getByText("Direction to the Kaaba")).toBeTruthy());
    expect(screen.getByRole("button", { name: /Set location/i })).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Tools" }));
    await waitFor(() => expect(screen.getByRole("tab", { name: "Tasbih" })).toBeTruthy());

    fireEvent.click(screen.getByRole("button", { name: "Quran" }));
    await waitFor(() => expect(screen.getByText("The Holy Quran")).toBeTruthy());
    // Offline → error state with retry rather than a blank screen.
    await waitFor(() => expect(screen.getByRole("alert")).toBeTruthy());
    expect(screen.getByRole("button", { name: /Retry/i })).toBeTruthy();
  });

  it("Appearance settings switch theme & accent instantly, persist, and reset with confirmation", async () => {
    localStorage.clear();
    localStorage.setItem("deenly_isFirstLaunch", "false");
    themeController._resetForTests();
    themeController.init();
    render(<App />);

    fireEvent.click(screen.getByRole("button", { name: "Settings" }));
    await waitFor(() => expect(screen.getByText("Appearance & Customization")).toBeTruthy());
    // The bottom navigation is hidden on the full-screen settings route, and back returns to it.
    expect(screen.queryByRole("navigation", { name: "Primary" })).toBeNull();

    fireEvent.click(screen.getByRole("radio", { name: /Sepia mode/ }));
    expect(document.documentElement.dataset.theme).toBe("sepia");
    expect(document.documentElement.style.getPropertyValue("--t-bg")).toBe("#F4ECD8");
    expect(localStorage.getItem("deenly_theme_mode")).toBe("sepia");
    expect(screen.getByRole("radio", { name: /Sepia mode/ }).getAttribute("aria-checked")).toBe("true");

    fireEvent.click(screen.getByRole("radio", { name: "Royal Blue" }));
    expect(document.documentElement.style.getPropertyValue("--t-brand")).toBe("#2F60FF");
    expect(localStorage.getItem("deenly_accent_color")).toBe("blue");
    expect(screen.getByText(/Sepia · Royal Blue/)).toBeTruthy(); // live preview reflects selection

    fireEvent.click(screen.getByRole("button", { name: /Reset to Defaults/ }));
    const dialog = await screen.findByRole("alertdialog");
    expect(dialog).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Reset" }));
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
    expect(document.documentElement.style.getPropertyValue("--t-brand")).toBe("#00B388");
    expect(localStorage.getItem("deenly_accent_color")).toBe("mint");

    fireEvent.click(screen.getByRole("button", { name: "Back" }));
    await waitFor(() => expect(screen.getByRole("navigation", { name: "Primary" })).toBeTruthy());
  });

  it("Tasbih increments on tap and persists", async () => {
    tasbihStore.set({ count: 0, target: 33, rounds: 0, totalLifetime: 0 });
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Tools" }));
    const counter = await screen.findByRole("button", { name: /Tasbih counter/ });
    await act(async () => {
      for (let i = 0; i < 5; i++) fireEvent.pointerDown(counter, { clientX: 10, clientY: 10 });
    });
    expect(tasbihStore.get().count).toBe(5);
    expect(JSON.parse(localStorage.getItem("deenly:tasbih")!).count).toBe(5);
    expect(screen.getByRole("button", { name: /Tasbih counter, 5 of 33/ })).toBeTruthy();
  });
});
