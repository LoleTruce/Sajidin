// @vitest-environment happy-dom
import { render, screen, fireEvent, within } from "@testing-library/react";
import { it, vi, expect } from "vitest";
import App from "../App";
import { themeController } from "../theme/themeStore";
import { settingsStore } from "../state/stores";

const aladhan = { code: 200, status: "OK", data: { timings: { Fajr: "04:30", Dhuhr: "13:05", Asr: "17:10", Maghrib: "20:45", Isha: "22:15" }, date: { gregorian: { date: "01-07-2025" }, hijri: { day: "5", month: { en: "Muharram" }, year: "1447", weekday: { en: "x" } } }, meta: { latitude: 51.5, longitude: -0.12, timezone: "Europe/London", method: { id: 3, name: "MWL" } } } };
const surahList = { code: 200, status: "OK", data: Array.from({ length: 114 }, (_, i) => ({ number: i + 1, name: "س", englishName: `S${i + 1}`, englishNameTranslation: "t", numberOfAyahs: 3, revelationType: "Meccan" })) };
const mk = (id: string, texts: string[]) => ({ number: 1, name: "الفاتحة", englishName: "Al-Faatiha", englishNameTranslation: "The Opening", numberOfAyahs: 3, revelationType: "Meccan", edition: { identifier: id }, ayahs: texts.map((t, i) => ({ number: i + 1, numberInSurah: i + 1, text: t, juz: 1, page: 1 })) });
const surah = { code: 200, status: "OK", data: [mk("quran-uthmani", ["بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", "ب", "ج"]), mk("en.sahih", ["a", "b", "c"]), mk("en.transliteration", ["x", "y", "z"])] };

/**
 * End-to-end journey through every primary surface with *successful* data, asserting that no
 * React/runtime error is logged. Complements the feature tests, which mostly exercise failure paths.
 */
it("returning user can traverse Home → Quran reader + audio → Qibla → Tasbih → Duas → prayer settings without runtime errors", async () => {
  vi.stubGlobal("IntersectionObserver", class { observe() {} disconnect() {} unobserve() {} });
  vi.stubGlobal("DeviceOrientationEvent", undefined);
  Object.defineProperty(window, "matchMedia", { value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }) });
  vi.stubGlobal("fetch", vi.fn(async (u: string) => { const s = String(u); const body = s.includes("aladhan") ? aladhan : s.includes("/surah/1/") ? surah : s.includes("/surah") ? surahList : {}; return new Response(JSON.stringify(body), { status: 200 }); }));
  Element.prototype.scrollIntoView = () => {};
  vi.stubGlobal("Audio", class { preload = ""; src = ""; currentTime = 0; duration = 10; paused = true; ended = false; addEventListener() {} removeEventListener() {} play = async () => {}; pause = () => {}; load = () => {}; removeAttribute() {} });
  const errors: string[] = [];
  const origErr = console.error; console.error = (...a: unknown[]) => { errors.push(String(a[0]).slice(0, 160)); };
  localStorage.setItem("deenly_isFirstLaunch", "false");
  themeController.init();
  settingsStore.set({ location: { lat: 51.5, lng: -0.12, label: "London", at: 1, source: "manual" } });
  render(<App />);
  await screen.findAllByText("Fajr", {}, { timeout: 3000 });
  expect(screen.getByRole("timer")).toBeTruthy();
  // Quran → reader
  fireEvent.click(screen.getByRole("button", { name: "Quran" }));
  const btns = await screen.findAllByRole("button", { name: /S1\b/ }, { timeout: 3000 });
  fireEvent.click(btns.find((b) => b.textContent?.startsWith("1S1"))!);
  await screen.findByText(/1\. Al-Faatiha/, {}, { timeout: 3000 });
  fireEvent.click(screen.getAllByRole("button", { name: /Play this Ayah/ })[1]);
  await screen.findByRole("region", { name: "Quran audio player" });
  fireEvent.click(screen.getByRole("button", { name: "Reading settings" }));
  await screen.findByRole("dialog", { name: "Reading settings" });
  fireEvent.click(screen.getByRole("button", { name: "Close" }));
  fireEvent.click(screen.getByRole("button", { name: "Back to Surah list" }));
  // Qibla with location
  fireEvent.click(screen.getByRole("button", { name: "Qibla" }));
  await screen.findByText(/Qibla direction ready|Turn|Almost/);
  // Tools → tasbih target sheet, duas expand
  fireEvent.click(screen.getByRole("button", { name: "Tools" }));
  fireEvent.click(await screen.findByRole("button", { name: /Target 33/ }));
  fireEvent.click(await screen.findByRole("button", { name: "99" }));
  fireEvent.click(screen.getByRole("tab", { name: "Daily Duas" }));
  fireEvent.click((await screen.findAllByRole("button", { expanded: false }))[0]);
  await screen.findByText(/Sahih Muslim 2723/);
  // Home settings sheet
  fireEvent.click(within(screen.getByRole("navigation", { name: "Primary" })).getByRole("button", { name: "Home" }));
  fireEvent.click(await screen.findByRole("button", { name: "Prayer settings" }));
  await screen.findByRole("dialog", { name: "Prayer settings" });
  console.error = origErr;
  expect(errors.filter((e) => !e.includes("act("))).toEqual([]);
});
