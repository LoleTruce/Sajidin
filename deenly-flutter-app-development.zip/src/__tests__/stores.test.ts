import { beforeEach, describe, expect, it } from "vitest";
import { createStore, readStorage } from "../core/store";
import { incrementTasbih, resetTasbih, toggleInList, type TasbihState } from "../state/stores";
import { parseSurahContent, parseSurahList } from "../services/quranApi";
import { hadithForDate, HADITHS } from "../data/hadiths";
import { DUAS } from "../data/duas";

/* Minimal localStorage polyfill for the node test environment. */
class MemoryStorage implements Storage {
  private m = new Map<string, string>();
  get length() {
    return this.m.size;
  }
  clear() {
    this.m.clear();
  }
  getItem(k: string) {
    return this.m.get(k) ?? null;
  }
  key(i: number) {
    return [...this.m.keys()][i] ?? null;
  }
  removeItem(k: string) {
    this.m.delete(k);
  }
  setItem(k: string, v: string) {
    this.m.set(k, v);
  }
}

beforeEach(() => {
  (globalThis as unknown as { localStorage: Storage }).localStorage = new MemoryStorage();
});

describe("Tasbih logic", () => {
  const base: TasbihState = { count: 0, target: 33, rounds: 0, totalLifetime: 0 };

  it("increments and wraps at the target, counting a round", () => {
    let s = base;
    for (let i = 0; i < 32; i++) s = incrementTasbih(s);
    expect(s.count).toBe(32);
    expect(s.rounds).toBe(0);
    s = incrementTasbih(s);
    expect(s.count).toBe(0);
    expect(s.rounds).toBe(1);
    expect(s.totalLifetime).toBe(33);
  });

  it("never loses rapid increments", () => {
    let s = base;
    for (let i = 0; i < 1000; i++) s = incrementTasbih(s);
    expect(s.totalLifetime).toBe(1000);
    expect(s.rounds).toBe(Math.floor(1000 / 33));
    expect(s.count).toBe(1000 % 33);
  });

  it("reset clears count and rounds but keeps lifetime", () => {
    const s = resetTasbih({ count: 10, target: 33, rounds: 2, totalLifetime: 76 });
    expect(s).toEqual({ count: 0, target: 33, rounds: 0, totalLifetime: 76 });
  });
});

describe("persisted store", () => {
  it("persists to localStorage and restores on recreation", () => {
    const a = createStore({ count: 0, target: 33 }, "t-tasbih");
    a.set({ count: 12 });
    expect(readStorage("t-tasbih", { count: 0, target: 33 })).toEqual({ count: 12, target: 33 });
    const b = createStore({ count: 0, target: 33 }, "t-tasbih");
    expect(b.get().count).toBe(12);
  });

  it("notifies subscribers once per change and not on identity", () => {
    const s = createStore({ n: 1 });
    let calls = 0;
    s.subscribe(() => calls++);
    s.set({ n: 2 });
    s.set((p) => p);
    expect(calls).toBe(1);
  });

  it("toggleInList adds then removes", () => {
    expect(toggleInList([], "a")).toEqual(["a"]);
    expect(toggleInList(["a"], "a")).toEqual([]);
  });
});

describe("Quran API parsing", () => {
  it("rejects a Surah list that is not exactly 114", () => {
    expect(() => parseSurahList({ code: 200, status: "OK", data: [] })).toThrow();
  });

  it("aligns Arabic and translation editions", () => {
    const mk = (id: string, texts: string[]) => ({
      number: 112,
      name: "سُورَةُ الإِخۡلَاصِ",
      englishName: "Al-Ikhlaas",
      englishNameTranslation: "Sincerity",
      numberOfAyahs: 2,
      revelationType: "Meccan" as const,
      edition: { identifier: id },
      ayahs: texts.map((t, i) => ({ number: 6222 + i, numberInSurah: i + 1, text: t, juz: 30, page: 604 })),
    });
    const parsed = parseSurahContent({ code: 200, status: "OK", data: [mk("quran-uthmani", ["أ", "ب"]), mk("en.sahih", ["a", "b"])] }, "en.sahih");
    expect(parsed.ayahs).toHaveLength(2);
    expect(parsed.ayahs[1]).toMatchObject({ number: 6223, arabic: "ب", translation: "b" });
    expect(() => parseSurahContent({ code: 200, status: "OK", data: [mk("quran-uthmani", ["أ"]), mk("en.sahih", ["a", "b"])] }, "en.sahih")).toThrow();
  });
});

describe("content datasets", () => {
  it("every hadith and dua carries a reference", () => {
    HADITHS.forEach((h) => expect(h.reference.length).toBeGreaterThan(5));
    DUAS.forEach((d) => expect(d.reference.length).toBeGreaterThan(5));
  });
  it("hadith of the day is stable within a day", () => {
    const d = new Date(2025, 5, 10, 9);
    expect(hadithForDate(d).id).toBe(hadithForDate(new Date(2025, 5, 10, 23)).id);
  });
});
