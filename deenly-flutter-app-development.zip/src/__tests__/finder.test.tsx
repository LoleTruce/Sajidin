// @vitest-environment happy-dom
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import App from "../App";
import { buildOverpassQuery, cacheKey, cacheSize, clearFinderCache, fetchNearby, fetchWalkingRoute, getCached, navigationUrls, parseOverpassResponse, setCached } from "../features/finder/halalFinderService";
import { displayName, distanceMeters, formatDistance } from "../features/finder/nearbyPlace";
import { themeController } from "../theme/themeStore";
import { settingsStore } from "../state/stores";

const LONDON = { lat: 51.5074, lng: -0.1278 };

const sample = {
  elements: [
    { type: "node", id: 1, lat: 51.51, lon: -0.13, tags: { name: "East London Mosque", "addr:street": "Whitechapel Road", "addr:housenumber": "82", "addr:city": "London", opening_hours: "05:00-23:00", website: "eastlondonmosque.org.uk" } },
    { type: "way", id: 2, center: { lat: 51.505, lon: -0.12 }, tags: { denomination: "sunni" } }, // unnamed way with centre
    { type: "relation", id: 3, center: { lat: 51.5, lon: -0.1 }, tags: { name: "Relation Masjid" } },
    { type: "way", id: 4, tags: { name: "No coords way" } }, // skipped: no centre
    { type: "node", id: 5, lat: 999, lon: 0, tags: { name: "Bad coords" } }, // skipped: invalid
    { type: "node", id: 1, lat: 51.51, lon: -0.13, tags: { name: "Duplicate" } }, // skipped: dedupe
    { type: "node", id: 6, lat: 52.9, lon: -0.13, tags: { name: "Too far" } }, // skipped: outside radius
    { type: "node", id: 7, lat: 51.509, lon: -0.128, tags: { name: "<img src=x onerror=alert(1)>\u0007Mosque", website: "javascript:alert(1)" } },
  ],
};

describe("Overpass query builder", () => {
  it("uses the required mosque tags with a 5 km radius and nwr + out center", () => {
    const q = buildOverpassQuery("mosque", LONDON.lat, LONDON.lng);
    expect(q).toContain('nwr["amenity"="place_of_worship"]["religion"~"^(muslim|islam)$"](around:5000,51.507400,-0.127800)');
    expect(q).toContain("out center tags");
    expect(q).toMatch(/^\[out:json\]\[timeout:\d+\];/);
  });
  it("unions the three halal rules with the [Hh]alal regex", () => {
    const q = buildOverpassQuery("halal", LONDON.lat, LONDON.lng);
    expect(q).toContain('nwr["diet:halal"="yes"](around:5000,');
    expect(q).toContain('nwr["cuisine"~"halal"](around:5000,');
    expect(q).toContain('nwr["name"~"[Hh]alal"](around:5000,');
    expect(q.startsWith("[out:json]")).toBe(true);
  });
  it("rejects invalid coordinates and clamps the radius", () => {
    expect(() => buildOverpassQuery("mosque", 91, 0)).toThrow();
    expect(buildOverpassQuery("mosque", 0, 0, 1)).toContain("around:100,");
  });
});

describe("Overpass parsing (untrusted input)", () => {
  it("resolves nodes/ways/relations, skips invalid/duplicate/out-of-radius elements, sanitises text", () => {
    const places = parseOverpassResponse(sample, "mosque", LONDON);
    expect(places.map((p) => p.id)).toEqual(["node/1", "way/2", "relation/3", "node/7"]);
    expect(places[0]).toMatchObject({ name: "East London Mosque", address: "82 Whitechapel Road", locality: "London", openingHours: "05:00-23:00", website: "https://eastlondonmosque.org.uk/" });
    expect(places[1].name).toBeUndefined();
    expect(displayName(places[1])).toBe("Unnamed mosque"); // never invented
    expect(places[1].subtype).toBe("sunni");
    expect(places[3].name).toBe("<img src=x onerror=alert(1)> Mosque"); // kept as plain text, control char removed
    expect(places[3].website).toBeUndefined(); // javascript: URL dropped
  });
  it("records halal evidence and drops elements that match no halal rule", () => {
    const places = parseOverpassResponse(
      { elements: [
        { type: "node", id: 1, lat: 51.508, lon: -0.128, tags: { name: "A", "diet:halal": "yes" } },
        { type: "node", id: 2, lat: 51.508, lon: -0.128, tags: { name: "B", cuisine: "turkish;halal" } },
        { type: "node", id: 3, lat: 51.508, lon: -0.128, tags: { name: "Halal Grill" } },
        { type: "node", id: 4, lat: 51.508, lon: -0.128, tags: { name: "Unrelated" } },
      ] },
      "halal",
      LONDON,
    );
    expect(places.map((p) => p.halalEvidence)).toEqual(["diet:halal", "cuisine", "name"]);
  });
  it("throws on malformed payloads", () => {
    expect(() => parseOverpassResponse(null, "mosque")).toThrow();
    expect(() => parseOverpassResponse({ elements: "nope" }, "mosque")).toThrow();
    expect(parseOverpassResponse({ elements: [null, 5, { type: "node" }] }, "mosque")).toEqual([]);
  });
});

describe("fetchNearby", () => {
  it("POSTs the query without credentials and falls back once on 429/5xx, surfacing rate-limit text", async () => {
    const calls: { url: string; init: RequestInit }[] = [];
    const fetchImpl = vi.fn(async (url: string | URL | Request, init?: RequestInit) => {
      calls.push({ url: String(url), init: init! });
      if (calls.length === 1) return new Response("busy", { status: 429 });
      return new Response(JSON.stringify(sample), { status: 200, headers: { "Content-Type": "application/json" } });
    }) as unknown as typeof fetch;
    const places = await fetchNearby("mosque", LONDON.lat, LONDON.lng, undefined, { fetchImpl, endpoints: ["https://a.example/api", "https://b.example/api"] });
    expect(places).toHaveLength(4);
    expect(calls).toHaveLength(2);
    expect(calls[0].init.method).toBe("POST");
    expect(calls[0].init.credentials).toBe("omit");
    expect(String(calls[0].init.body)).toMatch(/^data=%5Bout%3Ajson%5D/);
    expect(calls[1].url).toBe("https://b.example/api");

    const always429 = vi.fn(async () => new Response("", { status: 429 })) as unknown as typeof fetch;
    await expect(fetchNearby("mosque", LONDON.lat, LONDON.lng, undefined, { fetchImpl: always429, endpoints: ["https://a.example"] })).rejects.toThrow(/rate limited/);
  });
  it("does not fall back on parse errors or 4xx client errors", async () => {
    const fetchImpl = vi.fn(async () => new Response("<html>", { status: 200 })) as unknown as typeof fetch;
    await expect(fetchNearby("halal", LONDON.lat, LONDON.lng, undefined, { fetchImpl, endpoints: ["https://a.example", "https://b.example"] })).rejects.toThrow(/read the places response/);
    expect(fetchImpl).toHaveBeenCalledTimes(1);
  });
});

describe("session cache", () => {
  beforeEach(() => clearFinderCache());
  it("is keyed by category + ~110 m cell, expires after 10 min and is bounded", () => {
    expect(cacheKey("mosque", 51.50741, -0.12779)).toBe(cacheKey("mosque", 51.50749, -0.12771));
    expect(cacheKey("mosque", 51.5074, -0.1278)).not.toBe(cacheKey("halal", 51.5074, -0.1278));
    setCached("mosque", LONDON.lat, LONDON.lng, [], 1_000);
    expect(getCached("mosque", LONDON.lat, LONDON.lng, 2_000)).toEqual([]);
    expect(getCached("mosque", LONDON.lat, LONDON.lng, 1_000 + 11 * 60_000)).toBeNull();
    for (let i = 0; i < 20; i++) setCached("halal", i, i, []);
    expect(cacheSize()).toBeLessThanOrEqual(12);
    clearFinderCache();
    expect(cacheSize()).toBe(0);
    expect(Object.keys(localStorage).some((k) => k.includes("finder"))).toBe(false); // never persisted
  });
});

describe("distances, routing and navigation URLs", () => {
  it("haversine + formatting", () => {
    expect(distanceMeters(51.5074, -0.1278, 51.5074, -0.1278)).toBe(0);
    expect(Math.round(distanceMeters(51.5074, -0.1278, 51.5155, -0.0922))).toBeCloseTo(2630, -2);
    expect(formatDistance(340)).toBe("340 m");
    expect(formatDistance(2630)).toBe("2.6 km");
  });
  it("walking route parses OSRM and rejects non-Ok responses", async () => {
    const ok = vi.fn(async () => new Response(JSON.stringify({ code: "Ok", routes: [{ distance: 971.5, duration: 700 }] }))) as unknown as typeof fetch;
    expect(await fetchWalkingRoute(LONDON, { lat: 51.51, lng: -0.12 }, undefined, ok)).toEqual({ distanceM: 971.5, durationS: 700 });
    const bad = vi.fn(async () => new Response(JSON.stringify({ code: "NoRoute" }))) as unknown as typeof fetch;
    await expect(fetchWalkingRoute(LONDON, { lat: 51.52, lng: -0.12 }, undefined, bad)).rejects.toThrow();
    expect(String((ok as unknown as { mock: { calls: unknown[][] } }).mock.calls[0][0])).toContain("/route/v1/foot/-0.127800,51.507400;-0.120000,51.510000");
  });
  it("builds valid, encoded navigation URLs from coordinates only", () => {
    const u = navigationUrls({ lat: 51.51, lng: -0.13 }, 'Mosque & "Centre"');
    expect(u.primary).toBe("https://www.google.com/maps/dir/?api=1&destination=51.510000,-0.130000&travelmode=driving");
    expect(u.apple).toContain("daddr=51.510000,-0.130000");
    expect(u.apple).toContain("q=Mosque%20%26%20%22Centre%22");
    expect(() => navigationUrls({ lat: 200, lng: 0 })).toThrow();
  });
});

/* ---------- Integration ---------- */
describe("Tools tab integration", () => {
  beforeAll(() => {
    vi.stubGlobal("IntersectionObserver", class { observe() {} disconnect() {} unobserve() {} });
    vi.stubGlobal("DeviceOrientationEvent", undefined);
    Object.defineProperty(window, "matchMedia", { value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }) });
  });
  beforeEach(() => {
    localStorage.clear();
    localStorage.setItem("deenly_isFirstLaunch", "false");
    themeController._resetForTests();
    themeController.init();
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(sample), { status: 200 })));
  });
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
    window.history.replaceState(null, "");
  });

  it("opens the finder from Tools, explains location before asking, and returns to Tools on back", async () => {
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Tools" }));
    fireEvent.click(await screen.findByRole("button", { name: /Open Halal Places and Masjid Finder/ }));
    await screen.findByText("Halal Places & Masjid Finder");
    expect(screen.queryByRole("navigation", { name: "Primary" })).toBeNull();
    // No origin yet → explanation + both options; no fake markers/results are shown.
    await screen.findByText(/Find places near you/);
    expect(screen.getByRole("button", { name: /Use my location/ })).toBeTruthy();
    expect(screen.getByRole("button", { name: /Choose a city instead/ })).toBeTruthy();
    expect(screen.getByRole("radio", { name: /Mosques Only/ }).getAttribute("aria-checked")).toBe("true");
    expect(fetch).not.toHaveBeenCalled(); // nothing sent until a location exists

    fireEvent.click(screen.getByRole("button", { name: "Back to Tools" }));
    await screen.findByRole("tab", { name: "Tasbih" });
  });

  it("switching category after a search triggers a new query and clears stale results", async () => {
    // The user previously configured a prayer-times location (Home › location); the finder seeds from it.
    settingsStore.set({ location: { lat: LONDON.lat, lng: LONDON.lng, label: "London, UK", at: 1, source: "manual" } });
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Tools" }));
    fireEvent.click(await screen.findByRole("button", { name: /Open Halal Places and Masjid Finder/ }));
    await screen.findByText(/4 results/, {}, { timeout: 4000 });
    const overpassCalls = () => (fetch as unknown as { mock: { calls: [string, RequestInit][] } }).mock.calls.filter(([u]) => String(u).includes("overpass"));
    expect(overpassCalls()).toHaveLength(1);
    const firstBody = decodeURIComponent(String(overpassCalls()[0][1].body));
    expect(firstBody).toContain('"religion"~"^(muslim|islam)$"');
    expect(firstBody).toContain("around:5000,51.507400,-0.127800");
    // Privacy: the only requests carrying coordinates go to Overpass — none to any Sajidin host.
    expect((fetch as unknown as { mock: { calls: [string][] } }).mock.calls.every(([u]) => /overpass|aladhan/.test(String(u)))).toBe(true);

    fireEvent.click(screen.getByRole("radio", { name: /Halal Food Only/ }));
    await waitFor(() => expect(overpassCalls()).toHaveLength(2));
    const secondBody = decodeURIComponent(String(overpassCalls()[1][1].body));
    expect(secondBody).toContain('"diet:halal"="yes"');
    // The mocked payload is mosque data; the halal parser keeps only matching rules → honest empty state.
    await screen.findByText(/No halal food venues found within 5 km/);
  });
});
