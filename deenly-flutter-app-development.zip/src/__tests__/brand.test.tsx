// @vitest-environment happy-dom
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import App from "../App";
import { BRAND } from "../core/brand";
import { DICTIONARIES, LANGUAGE_CODES } from "../i18n/strings";
import { FIRST_LAUNCH_KEY, readLaunchState } from "../features/onboarding/onboardingStore";
import { PREF_KEYS } from "../theme/preferences";
import { LANGUAGE_PREF_KEY } from "../i18n";
import { themeController } from "../theme/themeStore";
import { settingsStore, tasbihStore, bookmarksStore } from "../state/stores";

const OLD = /deenly/i;

beforeAll(() => {
  vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new Error("offline"))));
  vi.stubGlobal("IntersectionObserver", class { observe() {} disconnect() {} unobserve() {} });
  vi.stubGlobal("DeviceOrientationEvent", undefined);
  Object.defineProperty(window, "matchMedia", { value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }) });
});
beforeEach(() => {
  localStorage.clear();
  themeController._resetForTests();
  themeController.init();
});
afterEach(() => {
  cleanup();
  window.history.replaceState(null, "");
});

describe("Sajidin rebrand", () => {
  it("brand constants and every localised string use the new name only", () => {
    expect(BRAND.name).toBe("Sajidin");
    for (const code of LANGUAGE_CODES) {
      for (const [key, value] of Object.entries(DICTIONARIES[code])) {
        expect(value, `${code}:${key}`).not.toMatch(OLD);
      }
      expect(DICTIONARIES[code]["ob.welcome.title"]).toContain("Sajidin");
    }
  });

  it("document title/meta and the onboarding, shell, settings and account UI carry no old brand text", async () => {
    expect(document.title || "Sajidin").not.toMatch(OLD);
    // Fresh install → wizard
    const { unmount } = render(<App />);
    expect(screen.getByText("Welcome to Sajidin")).toBeTruthy();
    expect(document.body.textContent).not.toMatch(OLD);
    unmount();

    // Existing user → main shell + header + account sheet + appearance settings + tools
    localStorage.setItem(FIRST_LAUNCH_KEY, "false");
    render(<App />);
    expect(screen.getByLabelText("Sajidin home")).toBeTruthy();
    expect(document.body.textContent).not.toMatch(OLD);
    fireEvent.click(screen.getByRole("button", { name: "Account" }));
    await screen.findByRole("dialog", { name: "Account" });
    expect(document.body.textContent).not.toMatch(OLD);
    fireEvent.click(screen.getByRole("button", { name: "Settings" }));
    await screen.findByText("Appearance & Customization");
    expect(document.body.textContent).not.toMatch(OLD);
    fireEvent.click(screen.getByRole("button", { name: "Back" }));
    fireEvent.click(await screen.findByRole("button", { name: "Tools" }));
    await screen.findByRole("tab", { name: "Tasbih" });
    expect(document.body.textContent).not.toMatch(OLD);
  });

  it("installed-app identity (manifest, icons, app title) is Sajidin-branded and self-contained", () => {
    const html = readFileSync(resolve(process.cwd(), "index.html"), "utf8");
    expect(html).toContain("<title>Sajidin — Islamic Companion</title>");
    expect(html).toContain('name="apple-mobile-web-app-title" content="Sajidin"');
    expect(html).toContain('name="application-name" content="Sajidin"');
    const manifestHref = html.match(/rel="manifest" href="([^"]+)"/)?.[1];
    expect(manifestHref?.startsWith("data:application/manifest+json,")).toBe(true);
    const manifest = JSON.parse(decodeURIComponent(manifestHref!.split(",")[1]));
    expect(manifest.short_name).toBe("Sajidin");
    expect(manifest.name).toMatch(/^Sajidin/);
    expect(manifest.theme_color).toBe("#121214");
    expect(manifest.icons.map((i: { purpose: string }) => i.purpose)).toEqual(["any", "maskable"]);
    expect(html).toContain('rel="icon" type="image/svg+xml" href="data:image/svg+xml');
    expect(html).toContain('rel="apple-touch-icon"');
    expect(html.replace(/<!--[\s\S]*?-->/g, "")).not.toMatch(OLD);
  });

  it("keeps every persistence identifier unchanged so existing users lose nothing", () => {
    // These keys are compatibility identifiers, deliberately NOT renamed.
    expect(FIRST_LAUNCH_KEY).toBe("deenly_isFirstLaunch");
    expect(PREF_KEYS.mode).toBe("deenly_theme_mode");
    expect(PREF_KEYS.accent).toBe("deenly_accent_color");
    expect(LANGUAGE_PREF_KEY).toBe("deenly_language");

    // Simulate an existing Deenly-era user and make sure the app reads their data as-is.
    localStorage.setItem("deenly_isFirstLaunch", "false");
    localStorage.setItem("deenly_theme_mode", "sepia");
    localStorage.setItem("deenly_accent_color", "amber");
    localStorage.setItem("deenly_language", "ur");
    localStorage.setItem("deenly:settings", JSON.stringify({ hasSeenWelcome: true, calculationMethod: 2, location: { lat: 1, lng: 2, label: "X", at: 1, source: "manual" } }));
    localStorage.setItem("deenly:tasbih", JSON.stringify({ count: 12, target: 99, rounds: 3, totalLifetime: 309 }));
    localStorage.setItem("deenly:bookmarks", JSON.stringify({ hadiths: [], duas: ["sayyid-istighfar"], ayahs: ["2:255"], lastRead: null }));

    themeController._resetForTests();
    expect(themeController.init()).toMatchObject({ mode: "sepia", accent: "amber" });
    expect(readLaunchState()).toEqual({ kind: "completed" });
    // Stores created at module load already read these keys; re-read via the same prefix logic.
    expect(JSON.parse(localStorage.getItem("deenly:settings")!).calculationMethod).toBe(2);
    expect(JSON.parse(localStorage.getItem("deenly:tasbih")!).count).toBe(12);
    expect(JSON.parse(localStorage.getItem("deenly:bookmarks")!).ayahs).toEqual(["2:255"]);
    // Nothing was migrated/renamed: no new-brand keys were introduced.
    expect(Object.keys(localStorage).some((k) => /sajidin/i.test(k))).toBe(false);
    void settingsStore; void tasbihStore; void bookmarksStore;
  });
});
