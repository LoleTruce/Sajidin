// @vitest-environment happy-dom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { haptics } from "../core/haptics";
import { settingsStore } from "../state/stores";
import { schedulePrayerNotifications, clearScheduled } from "../services/notifications";
import type { PrayerTimesDay } from "../lib/prayer";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
  clearScheduled();
});

describe("haptics safety", () => {
  beforeEach(() => settingsStore.set({ hapticsEnabled: true }));

  it("is a silent no-op where navigator.vibrate is missing or throws", () => {
    vi.stubGlobal("navigator", { userAgent: "x" });
    expect(haptics.supported).toBe(false);
    expect(() => haptics.light()).not.toThrow();
    vi.stubGlobal("navigator", { vibrate: () => { throw new Error("blocked"); } });
    expect(() => haptics.success()).not.toThrow();
  });

  it("vibrates only when supported AND the user preference is on", () => {
    const vibrate = vi.fn(() => true);
    vi.stubGlobal("navigator", { vibrate });
    haptics.light();
    expect(vibrate).toHaveBeenCalledWith(8);
    settingsStore.set({ hapticsEnabled: false });
    haptics.success();
    expect(vibrate).toHaveBeenCalledTimes(1);
    expect(JSON.parse(localStorage.getItem("deenly:settings")!).hapticsEnabled).toBe(false); // persisted
  });
});

describe("notification display", () => {
  const day: PrayerTimesDay = { date: "2025-07-01", timezone: "UTC", times: { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: Date.now() + 1000 } };

  it("schedules only future, enabled prayers and clears them", () => {
    vi.stubGlobal("Notification", Object.assign(function () {}, { permission: "granted" }));
    const n = schedulePrayerNotifications(day, { enabled: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true }, leadMinutes: 0 });
    expect(n).toBe(1);
    expect(schedulePrayerNotifications(day, { enabled: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: false }, leadMinutes: 0 })).toBe(0);
  });

  it("does not throw when the page Notification constructor is illegal (Android Chrome) and no SW is active", () => {
    vi.useFakeTimers();
    vi.stubGlobal("Notification", Object.assign(function () { throw new TypeError("Illegal constructor"); }, { permission: "granted" }));
    schedulePrayerNotifications(day, { enabled: { Fajr: false, Dhuhr: false, Asr: false, Maghrib: false, Isha: true }, leadMinutes: 0 });
    expect(() => vi.advanceTimersByTime(1500)).not.toThrow();
  });
});
