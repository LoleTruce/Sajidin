import { describe, expect, it } from "vitest";
import { formatCountdown, nextPrayer, timeStringToEpoch, tzOffsetMs, type PrayerTimesDay } from "../lib/prayer";
import { parseTimings, type AladhanTimingsResponse } from "../services/aladhan";

const TZ = "Europe/London";

function day(date: string, tz = TZ): PrayerTimesDay {
  return {
    date,
    timezone: tz,
    times: {
      Fajr: timeStringToEpoch("04:30", date, tz),
      Dhuhr: timeStringToEpoch("13:05", date, tz),
      Asr: timeStringToEpoch("17:10", date, tz),
      Maghrib: timeStringToEpoch("20:45", date, tz),
      Isha: timeStringToEpoch("22:15", date, tz),
    },
  };
}

describe("timezone resolution", () => {
  it("resolves BST (+1h) and GMT (0h) offsets correctly", () => {
    expect(tzOffsetMs(Date.UTC(2025, 6, 1, 12), TZ)).toBe(3_600_000);
    expect(tzOffsetMs(Date.UTC(2025, 0, 1, 12), TZ)).toBe(0);
  });

  it("converts HH:MM in a zone to the right UTC instant across DST", () => {
    // 13:05 BST == 12:05 UTC
    expect(timeStringToEpoch("13:05", "2025-07-01", TZ)).toBe(Date.UTC(2025, 6, 1, 12, 5));
    // 13:05 GMT == 13:05 UTC
    expect(timeStringToEpoch("13:05", "2025-01-15", TZ)).toBe(Date.UTC(2025, 0, 15, 13, 5));
    // Handles the "(BST)" suffix AlAdhan sometimes appends
    expect(timeStringToEpoch("13:05 (BST)", "2025-07-01", TZ)).toBe(Date.UTC(2025, 6, 1, 12, 5));
    // Half-hour zones
    expect(timeStringToEpoch("12:00", "2025-03-10", "Asia/Kolkata")).toBe(Date.UTC(2025, 2, 10, 6, 30));
  });
});

describe("nextPrayer", () => {
  const today = day("2025-07-01");
  const tomorrow = day("2025-07-02");

  it("picks the first prayer still ahead", () => {
    const now = timeStringToEpoch("10:00", "2025-07-01", TZ);
    const np = nextPrayer(today, now, tomorrow);
    expect(np.name).toBe("Dhuhr");
    expect(np.remainingMs).toBe(3 * 3_600_000 + 5 * 60_000);
    expect(np.current).toBe("Fajr");
    expect(np.progress).toBeGreaterThan(0.6);
  });

  it("before Fajr returns Fajr with Isha as current", () => {
    const now = timeStringToEpoch("02:00", "2025-07-01", TZ);
    const np = nextPrayer(today, now, tomorrow);
    expect(np.name).toBe("Fajr");
    expect(np.current).toBe("Isha");
  });

  it("after Isha rolls over to tomorrow's Fajr", () => {
    const now = timeStringToEpoch("23:00", "2025-07-01", TZ);
    const np = nextPrayer(today, now, tomorrow);
    expect(np.name).toBe("Fajr");
    expect(np.at).toBe(tomorrow.times.Fajr);
    expect(np.remainingMs).toBe(5.5 * 3_600_000);
  });

  it("estimates Fajr + 24h when tomorrow is unknown", () => {
    const now = timeStringToEpoch("23:00", "2025-07-01", TZ);
    const np = nextPrayer(today, now);
    expect(np.at).toBe(today.times.Fajr + 86_400_000);
  });
});

describe("formatCountdown", () => {
  it("pads and never goes negative", () => {
    expect(formatCountdown(3_723_000)).toEqual({ h: "01", m: "02", s: "03" });
    expect(formatCountdown(-5000)).toEqual({ h: "00", m: "00", s: "00" });
  });
});

describe("AlAdhan parsing", () => {
  const sample: AladhanTimingsResponse = {
    code: 200,
    status: "OK",
    data: {
      timings: { Fajr: "04:30", Sunrise: "05:00", Dhuhr: "13:05", Asr: "17:10", Maghrib: "20:45", Isha: "22:15" },
      date: {
        gregorian: { date: "01-07-2025" },
        hijri: { day: "5", month: { en: "Muḥarram" }, year: "1447", weekday: { en: "Al Thulaathaa" } },
      },
      meta: { latitude: 51.5, longitude: -0.12, timezone: TZ, method: { id: 3, name: "Muslim World League" } },
    },
  };

  it("parses a valid response into epoch times", () => {
    const r = parseTimings(sample);
    expect(r.day.date).toBe("2025-07-01");
    expect(r.day.times.Dhuhr).toBe(Date.UTC(2025, 6, 1, 12, 5));
    expect(r.day.hijri?.year).toBe("1447");
    expect(r.meta.timezone).toBe(TZ);
  });

  it("rejects malformed responses", () => {
    expect(() => parseTimings({ ...sample, code: 500 })).toThrow();
    expect(() => parseTimings({ ...sample, data: { ...sample.data, timings: { Fajr: "bad" } } })).toThrow();
    expect(() => parseTimings(null as unknown as AladhanTimingsResponse)).toThrow();
  });
});
