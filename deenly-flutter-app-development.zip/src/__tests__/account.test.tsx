// @vitest-environment happy-dom
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import App from "../App";
import { authActions, authSession, registerAuthProvider, type AuthProvider } from "../auth/session";
import { themeController } from "../theme/themeStore";

beforeAll(() => {
  vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new Error("offline"))));
  vi.stubGlobal("IntersectionObserver", class {
    observe() {}
    disconnect() {}
    unobserve() {}
  });
  vi.stubGlobal("DeviceOrientationEvent", undefined);
  Object.defineProperty(window, "matchMedia", {
    value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }),
  });
});

beforeEach(() => {
  localStorage.clear();
  localStorage.setItem("deenly_isFirstLaunch", "false"); // main-shell tests: onboarding already done
  themeController._resetForTests();
  themeController.init();
  registerAuthProvider(null);
});

afterEach(() => {
  cleanup();
  window.history.replaceState(null, "");
});

const openSheet = async () => {
  render(<App />);
  fireEvent.click(screen.getByRole("button", { name: "Account" }));
  return screen.findByRole("dialog", { name: "Account" });
};

describe("Top header", () => {
  it("renders the wordmark with Account and Settings actions on every tab root, once", async () => {
    render(<App />);
    expect(screen.getByRole("banner")).toBeTruthy();
    expect(screen.getByLabelText("Sajidin home")).toBeTruthy();
    for (const tab of ["Quran", "Qibla", "Tools", "Home"]) {
      fireEvent.click(screen.getByRole("button", { name: tab }));
      await waitFor(() => expect(screen.getAllByRole("banner")).toHaveLength(1));
      expect(screen.getAllByRole("button", { name: "Account" })).toHaveLength(1);
      expect(screen.getAllByRole("button", { name: "Settings" })).toHaveLength(1);
    }
  });

  it("Settings opens the existing Appearance screen and back returns to the same tab", async () => {
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Tools" }));
    await screen.findByRole("tab", { name: "Tasbih" });
    fireEvent.click(screen.getByRole("button", { name: "Settings" }));
    await screen.findByText("Appearance & Customization");
    expect(screen.queryByLabelText("Sajidin home")).toBeNull(); // shell header hidden; full-screen route has its own back header
    fireEvent.click(screen.getByRole("button", { name: "Back" }));
    await screen.findByRole("tab", { name: "Tasbih" }); // navigation state preserved
    expect(screen.getByRole("banner")).toBeTruthy();
  });
});

describe("Account sheet", () => {
  it("shows an honest local-only state when no auth provider is bundled — no fake sign-in or sync success", async () => {
    await openSheet();
    expect(screen.getByText("Not signed in")).toBeTruthy();
    expect(screen.getByText("Local only")).toBeTruthy();
    expect(screen.getByText(/Accounts aren't available in this build/)).toBeTruthy();
    expect(screen.queryByRole("button", { name: /Sign in/ })).toBeNull();
    expect(screen.queryByRole("button", { name: /Log out/ })).toBeNull();
    expect(screen.getByText(/Not synchronised to a profile/)).toBeTruthy();
  });

  it("reflects a registered provider's real session and runs logout with confirmation, loading and state update", async () => {
    let resolveSignOut: () => void = () => {};
    const provider: AuthProvider = {
      signIn: vi.fn(async () => {}),
      signOut: vi.fn(
        () =>
          new Promise<void>((res) => {
            resolveSignOut = () => {
              authActions.setSignedOut();
              res();
            };
          }),
      ),
    };
    registerAuthProvider(provider);
    authActions.setSignedIn({ uid: "abc123xyz", displayName: "Aisha", email: "aisha@example.com" });
    themeController.setThemeMode("sepia"); // a real persisted preference that logout must not erase

    await openSheet();
    expect(screen.getByText("Aisha")).toBeTruthy();
    expect(screen.getByText("aisha@example.com")).toBeTruthy();
    expect(screen.getByText("Signed in")).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: /Log out/ }));
    const confirm = await screen.findByRole("alertdialog");
    fireEvent.click(within(confirm).getByRole("button", { name: "Log out" }));
    await waitFor(() => expect(provider.signOut).toHaveBeenCalledTimes(1));

    // Duplicate taps while the request is in flight do not trigger a second sign-out.
    const sheet = screen.getByRole("dialog", { name: "Account" });
    const btn = within(sheet).getByRole("button", { name: /Log out/ });
    expect((btn as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(btn);
    expect(provider.signOut).toHaveBeenCalledTimes(1);

    await act(async () => resolveSignOut());
    await waitFor(() => expect(authSession.get().status).toBe("signed-out"));
    // Theme preferences and local data are untouched by logout.
    expect(localStorage.getItem("deenly_theme_mode")).toBe("sepia");
    expect(document.documentElement.dataset.theme).toBe("sepia");
  });

  it("surfaces logout failures without crashing and keeps the session intact", async () => {
    registerAuthProvider({ signIn: async () => {}, signOut: async () => Promise.reject(new Error("Network unavailable")) });
    authActions.setSignedIn({ uid: "u1", email: "user@example.com" });
    await openSheet();
    fireEvent.click(screen.getByRole("button", { name: /Log out/ }));
    const confirm = await screen.findByRole("alertdialog");
    fireEvent.click(within(confirm).getByRole("button", { name: "Log out" }));
    await screen.findByText("Network unavailable");
    expect(authSession.get().status).toBe("signed-in");
  });

  it("offers Sign in only when a provider exists and the user is signed out", async () => {
    const signIn = vi.fn(async () => {});
    registerAuthProvider({ signIn, signOut: async () => {} });
    authActions.setSignedOut();
    await openSheet();
    fireEvent.click(screen.getByRole("button", { name: /Sign in/ }));
    await waitFor(() => expect(signIn).toHaveBeenCalledTimes(1));
  });
});
