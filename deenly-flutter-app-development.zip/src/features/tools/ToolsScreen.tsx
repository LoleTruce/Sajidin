import { AnimatePresence, motion } from "framer-motion";
import { ChevronRight, MapPinned } from "lucide-react";
import { ScreenHeader } from "../../components/ui";
import { screenVariants } from "../../core/motion";
import { cn } from "../../utils/cn";
import { Duas } from "./Duas";
import { Tasbih } from "./Tasbih";

export type Tool = "tasbih" | "duas";

export function ToolsScreen({ tool, onChangeTool, onOpenFinder }: { tool: Tool; onChangeTool: (t: Tool) => void; onOpenFinder: () => void }) {
  return (
    <div className="mx-auto max-w-xl pb-28">
      <ScreenHeader title="Tools" subtitle="Dhikr, supplication & nearby" />
      <div className="px-4 pb-3">
        <motion.button
          type="button"
          whileTap={{ scale: 0.98 }}
          onClick={onOpenFinder}
          aria-label="Open Halal Places and Masjid Finder"
          className="card focus-ring flex w-full items-center gap-3 p-4 text-left"
        >
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-ink">
            <MapPinned size={20} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-semibold">Halal Places & Masjid Finder</span>
            <span className="block text-xs text-faint">Mosques and halal food within 5 km · OpenStreetMap · no tracking</span>
          </span>
          <ChevronRight size={18} className="shrink-0 text-faint rtl:-scale-x-100" />
        </motion.button>
      </div>
      <div className="px-4 pb-4">
        <div className="relative grid grid-cols-2 rounded-2xl bg-card p-1 hairline" role="tablist" aria-label="Tools">
          {(["tasbih", "duas"] as Tool[]).map((t) => (
            <button key={t} role="tab" aria-selected={tool === t} type="button" onClick={() => onChangeTool(t)} className={cn("focus-ring relative z-10 rounded-xl py-2.5 text-sm font-semibold transition-colors", tool === t ? "text-on-brand" : "text-muted")}>
              {tool === t && <motion.span layoutId="tool-pill" transition={{ type: "spring", stiffness: 420, damping: 34 }} className="absolute inset-0 -z-10 rounded-xl bg-brand" />}
              {t === "tasbih" ? "Tasbih" : "Daily Duas"}
            </button>
          ))}
        </div>
      </div>
      <AnimatePresence mode="wait" initial={false}>
        <motion.div key={tool} variants={screenVariants} initial="initial" animate="animate" exit="exit">
          {tool === "tasbih" ? <Tasbih /> : <Duas />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
