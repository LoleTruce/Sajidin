import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { RotateCcw, Target } from "lucide-react";
import { useCallback, useRef, useState } from "react";
import { Chip, ConfirmDialog, Sheet, PrimaryButton } from "../../components/ui";
import { haptics } from "../../core/haptics";
import { useStore } from "../../core/store";
import { incrementTasbih, resetTasbih, tasbihStore } from "../../state/stores";
import { cn } from "../../utils/cn";

const PRESETS = [33, 99, 100, 1000];

interface Ripple {
  id: number;
  x: number;
  y: number;
}

export function Tasbih() {
  const s = useStore(tasbihStore);
  const reduce = useReducedMotion();
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [confirm, setConfirm] = useState(false);
  const [targetOpen, setTargetOpen] = useState(false);
  const [custom, setCustom] = useState("");
  const [celebrate, setCelebrate] = useState(false);
  const [bump, setBump] = useState(0);
  const idRef = useRef(0);

  const tap = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    // Pointer events fire once per touch/click — no lost taps under rapid input.
    const before = tasbihStore.get();
    tasbihStore.set(incrementTasbih);
    const after = tasbihStore.get();
    haptics.light();
    setBump((b) => b + 1);
    if (after.rounds > before.rounds) {
      haptics.success();
      setCelebrate(true);
      window.setTimeout(() => setCelebrate(false), 1400);
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const id = ++idRef.current;
    setRipples((r) => [...r.slice(-4), { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    window.setTimeout(() => setRipples((r) => r.filter((x) => x.id !== id)), 600);
  }, []);

  const progress = s.target > 0 ? s.count / s.target : 0;
  const r = 118;
  const circ = 2 * Math.PI * r;

  return (
    <div className="flex flex-col items-center px-4">
      <div className="flex w-full items-center justify-between">
        <button type="button" onClick={() => setTargetOpen(true)} className="press focus-ring flex items-center gap-2 rounded-full bg-card px-3.5 py-2 text-xs font-semibold hairline" aria-label={`Target ${s.target}. Change target`}>
          <Target size={14} className="text-brand-ink" /> Target {s.target}
        </button>
        <div className="text-right text-xs text-faint">
          <span className="font-semibold text-ink">{s.rounds}</span> rounds · <span className="font-semibold text-ink">{s.totalLifetime.toLocaleString()}</span> total
        </div>
      </div>

      <motion.button
        type="button"
        onPointerDown={tap}
        onKeyDown={(e) => {
          if (e.key === " " || e.key === "Enter") {
            e.preventDefault();
            tasbihStore.set(incrementTasbih);
            haptics.light();
          }
        }}
        whileTap={reduce ? undefined : { scale: 0.97 }}
        aria-label={`Tasbih counter, ${s.count} of ${s.target}. Tap to count.`}
        className="focus-ring relative mt-8 grid aspect-square w-[min(78vw,300px)] touch-manipulation select-none place-items-center overflow-hidden rounded-full bg-card hairline"
      >
        <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 260 260" aria-hidden>
          <circle cx="130" cy="130" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
          <motion.circle
            cx="130"
            cy="130"
            r={r}
            fill="none"
            stroke="var(--t-brand)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={circ}
            animate={{ strokeDashoffset: circ * (1 - progress) }}
            transition={{ duration: 0.3, ease: [0.33, 1, 0.68, 1] }}
          />
        </svg>
        <AnimatePresence>
          {ripples.map((rp) => (
            <motion.span
              key={rp.id}
              initial={{ scale: 0, opacity: 0.35 }}
              animate={{ scale: 3, opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="pointer-events-none absolute h-24 w-24 rounded-full bg-brand"
              style={{ left: rp.x - 48, top: rp.y - 48 }}
            />
          ))}
        </AnimatePresence>
        <div className="relative text-center">
          <motion.p key={bump} initial={reduce ? false : { scale: 1.12 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 500, damping: 22 }} className="text-[72px] font-semibold leading-none tabular-nums tracking-tight">
            {s.count}
          </motion.p>
          <p className="mt-2 text-xs font-medium uppercase tracking-[0.16em] text-faint">of {s.target}</p>
        </div>
        <AnimatePresence>
          {celebrate && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pointer-events-none absolute inset-0 grid place-items-center rounded-full bg-brand/90">
              <motion.p initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 300, damping: 16 }} className="text-center text-on-brand">
                <span className="block text-2xl font-bold">Round complete</span>
                <span className="block text-sm font-medium">Masha'Allah · {s.rounds} rounds</span>
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      <p className="mt-6 text-center text-xs text-faint">Tap anywhere on the circle. Your count is saved automatically.</p>

      <div className="mt-4 flex gap-2">
        <PrimaryButton variant="ghost" onClick={() => setConfirm(true)} className="min-h-10 px-4 text-xs">
          <RotateCcw size={14} /> Reset
        </PrimaryButton>
      </div>

      <ConfirmDialog
        open={confirm}
        title="Reset counter?"
        message={`This clears the current count (${s.count}) and ${s.rounds} completed round${s.rounds === 1 ? "" : "s"}. Lifetime total is kept.`}
        confirmLabel="Reset"
        danger
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          tasbihStore.set(resetTasbih);
          haptics.medium();
          setConfirm(false);
        }}
      />

      <Sheet open={targetOpen} onClose={() => setTargetOpen(false)} title="Set target">
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((p) => (
            <Chip
              key={p}
              active={s.target === p}
              onClick={() => {
                tasbihStore.set((st) => ({ ...st, target: p, count: Math.min(st.count, p - 1) }));
                setTargetOpen(false);
              }}
            >
              {p}
            </Chip>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const n = Math.floor(Number(custom));
            if (n >= 1 && n <= 100_000) {
              tasbihStore.set((st) => ({ ...st, target: n, count: Math.min(st.count, n - 1) }));
              setCustom("");
              setTargetOpen(false);
            }
          }}
          className="mt-4 flex gap-2"
        >
          <input value={custom} onChange={(e) => setCustom(e.target.value.replace(/\D/g, ""))} inputMode="numeric" placeholder="Custom target" aria-label="Custom target" className={cn("focus-ring flex-1 rounded-2xl bg-card-2 px-4 py-3 text-sm hairline placeholder:text-faint")} />
          <PrimaryButton type="submit" disabled={!custom || Number(custom) < 1}>
            Set
          </PrimaryButton>
        </form>
      </Sheet>
    </div>
  );
}
