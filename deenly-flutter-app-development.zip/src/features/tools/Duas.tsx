import { AnimatePresence, motion } from "framer-motion";
import { Bookmark, ChevronDown, Copy, Search, Share2, X } from "lucide-react";
import { useDeferredValue, useMemo, useState } from "react";
import { Chip, EmptyState, shareOrCopy, useToast } from "../../components/ui";
import { fadeUp, staggerContainer } from "../../core/motion";
import { BRAND } from "../../core/brand";
import { useStore } from "../../core/store";
import { DUA_CATEGORIES, DUAS, type Dua, type DuaCategory } from "../../data/duas";
import { bookmarksStore, toggleInList } from "../../state/stores";
import { cn } from "../../utils/cn";

export function Duas() {
  const [query, setQuery] = useState("");
  const deferred = useDeferredValue(query);
  const [category, setCategory] = useState<DuaCategory | "All" | "Saved">("All");
  const [openId, setOpenId] = useState<string | null>(null);
  const saved = useStore(bookmarksStore, (b) => b.duas);

  const list = useMemo(() => {
    const q = deferred.trim().toLowerCase();
    return DUAS.filter((d) => {
      if (category === "Saved" && !saved.includes(d.id)) return false;
      if (category !== "All" && category !== "Saved" && d.category !== category) return false;
      if (!q) return true;
      return (
        d.title.toLowerCase().includes(q) ||
        d.english.toLowerCase().includes(q) ||
        d.arabic.includes(q) ||
        (d.transliteration?.toLowerCase().includes(q) ?? false) ||
        d.reference.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q)
      );
    });
  }, [deferred, category, saved]);

  return (
    <div className="px-4">
      <label className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 hairline">
        <Search size={16} className="text-faint" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search duas, meanings, references" aria-label="Search duas" className="w-full bg-transparent text-sm outline-none placeholder:text-faint" />
        {query && (
          <button type="button" aria-label="Clear search" onClick={() => setQuery("")} className="text-faint">
            <X size={16} />
          </button>
        )}
      </label>

      <div className="no-scrollbar -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-1" role="tablist" aria-label="Dua categories">
        {(["All", "Saved", ...DUA_CATEGORIES] as const).map((c) => (
          <Chip key={c} active={category === c} onClick={() => setCategory(c)} label={`${c} duas`}>
            {c}
            {c === "Saved" && saved.length > 0 ? ` (${saved.length})` : ""}
          </Chip>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState title={category === "Saved" ? "No saved duas yet" : "No duas match"} hint={category === "Saved" ? "Tap the bookmark on any dua to save it here." : "Try a different word or category."} />
      ) : (
        <motion.ul key={`${category}-${deferred}`} variants={staggerContainer} initial="hidden" animate="show" className="mt-3 space-y-2">
          {list.map((d) => (
            <motion.li key={d.id} variants={fadeUp}>
              <DuaCard dua={d} open={openId === d.id} onToggle={() => setOpenId(openId === d.id ? null : d.id)} />
            </motion.li>
          ))}
        </motion.ul>
      )}
      <p className="mt-5 text-center text-[11px] leading-relaxed text-faint">Source: Hisn al-Muslim with primary hadith references. Stored on your device for offline use.</p>
    </div>
  );
}

function DuaCard({ dua, open, onToggle }: { dua: Dua; open: boolean; onToggle: () => void }) {
  const saved = useStore(bookmarksStore, (b) => b.duas.includes(dua.id));
  const toast = useToast();
  const text = `${dua.title}\n\n${dua.arabic}\n\n${dua.transliteration ? dua.transliteration + "\n\n" : ""}${dua.english}\n— ${dua.reference}`;

  return (
    <div className={cn("card overflow-hidden transition-colors", open && "border-brand/25")}>
      <button type="button" onClick={onToggle} aria-expanded={open} className="focus-ring flex w-full items-start gap-3 p-4 text-left">
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-brand-ink">{dua.category}</p>
          <p className="mt-0.5 text-sm font-semibold">{dua.title}</p>
          {!open && (
            <p lang="ar" dir="rtl" className="font-arabic mt-2 truncate text-left text-lg text-muted" style={{ direction: "rtl" }}>
              {dua.arabic}
            </p>
          )}
        </div>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.25 }} className="mt-1 text-faint">
          <ChevronDown size={18} />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.28, ease: [0.33, 1, 0.68, 1] }} className="overflow-hidden">
            <div className="px-4 pb-4">
              <p lang="ar" dir="rtl" className="font-arabic text-[24px] leading-[2] text-ink">
                {dua.arabic}
              </p>
              {dua.transliteration && <p className="mt-3 text-[13px] italic leading-relaxed text-muted">{dua.transliteration}</p>}
              <p className="mt-3 text-[15px] leading-relaxed text-ink/85">{dua.english}</p>
              {dua.note && <p className="mt-2 rounded-xl bg-card-2 px-3 py-2 text-xs leading-relaxed text-muted">{dua.note}</p>}
              <div className="mt-4 flex items-center justify-between gap-3">
                <p className="text-xs text-faint">{dua.reference}</p>
                <div className="flex gap-1">
                  <button type="button" aria-label={saved ? "Remove from saved" : "Save dua"} onClick={() => bookmarksStore.set((b) => ({ ...b, duas: toggleInList(b.duas, dua.id) }))} className={cn("focus-ring rounded-full p-2", saved ? "text-brand-ink" : "text-faint")}>
                    <Bookmark size={16} fill={saved ? "currentColor" : "none"} />
                  </button>
                  <button
                    type="button"
                    aria-label="Copy dua"
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(text);
                        toast("Copied", "success");
                      } catch {
                        toast("Copy not available", "error");
                      }
                    }}
                    className="focus-ring rounded-full p-2 text-faint"
                  >
                    <Copy size={16} />
                  </button>
                  <button
                    type="button"
                    aria-label="Share dua"
                    onClick={async () => {
                      const r = await shareOrCopy(`${text}\n\n${BRAND.shareSuffix}`, dua.title);
                      if (r === "copied") toast("Copied to clipboard", "success");
                    }}
                    className="focus-ring rounded-full p-2 text-faint"
                  >
                    <Share2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
