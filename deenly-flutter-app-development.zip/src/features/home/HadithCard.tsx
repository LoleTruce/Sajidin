import { Bookmark, Share2 } from "lucide-react";
import { useMemo } from "react";
import { IconButton, shareOrCopy, useToast } from "../../components/ui";
import { BRAND } from "../../core/brand";
import { useStore } from "../../core/store";
import { hadithForDate } from "../../data/hadiths";
import { bookmarksStore, toggleInList } from "../../state/stores";

export function HadithCard() {
  const hadith = useMemo(() => hadithForDate(), []);
  const saved = useStore(bookmarksStore, (b) => b.hadiths.includes(hadith.id));
  const toast = useToast();

  const share = async () => {
    const text = `${hadith.arabic}\n\n“${hadith.english}”\n— ${hadith.reference} (${hadith.grade})\n\n${BRAND.shareSuffix}`;
    const r = await shareOrCopy(text, "Hadith of the Day");
    if (r === "copied") toast("Copied to clipboard", "success");
    else if (r === "failed") toast("Could not share", "error");
  };

  return (
    <section className="card p-5" aria-labelledby="hadith-heading">
      <div className="mb-4 flex items-center justify-between">
        <h2 id="hadith-heading" className="text-xs font-medium uppercase tracking-[0.14em] text-muted">
          Hadith of the day
        </h2>
        <div className="flex gap-2">
          <IconButton label={saved ? "Remove bookmark" : "Bookmark hadith"} active={saved} onClick={() => bookmarksStore.set((b) => ({ ...b, hadiths: toggleInList(b.hadiths, hadith.id) }))} className="h-9 w-9">
            <Bookmark size={16} fill={saved ? "currentColor" : "none"} />
          </IconButton>
          <IconButton label="Share hadith" onClick={share} className="h-9 w-9">
            <Share2 size={16} />
          </IconButton>
        </div>
      </div>
      <p lang="ar" dir="rtl" className="font-arabic text-[22px] leading-[2] text-ink">
        {hadith.arabic}
      </p>
      <p className="mt-4 text-[15px] leading-relaxed text-ink/90">“{hadith.english}”</p>
      <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-faint">
        <span>Narrated by {hadith.narrator}</span>
        <span aria-hidden>·</span>
        <span>{hadith.reference}</span>
        <span className="rounded-full bg-brand-soft px-2 py-0.5 font-semibold text-brand-ink">{hadith.grade}</span>
      </div>
    </section>
  );
}
