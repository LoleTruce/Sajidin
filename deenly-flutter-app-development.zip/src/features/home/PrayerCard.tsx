import { AnimatePresence, motion } from "framer-motion";
import { Bell, BellOff, MapPin, RefreshCw, Settings2 } from "lucide-react";
import { memo, useEffect, useMemo, useState } from "react";
import { ErrorState, PrimaryButton, Skeleton } from "../../components/ui";
import { base } from "../../core/motion";
import { useStore } from "../../core/store";
import { formatCountdown, formatTime, nextPrayer, PRAYER_NAMES, type PrayerTimesDay } from "../../lib/prayer";
import { prayerCacheStore, settingsStore } from "../../state/stores";
import { cn } from "../../utils/cn";
import type { PrayerTimesVM } from "./usePrayerTimes";

/** Ticks once per second in isolation so the rest of the dashboard never re-renders. */
function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    const onVisible = () => document.visibilityState === "visible" && setNow(Date.now());
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [intervalMs]);
  return now;
}

const Digit = memo(function Digit({ value }: { value: string }) {
  return (
    <span className="relative inline-block h-[1em] w-[1.2ch] overflow-hidden tabular-nums">
      <AnimatePresence initial={false} mode="popLayout">
        <motion.span
          key={value}
          initial={{ y: "60%", opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: "-60%", opacity: 0 }}
          transition={{ duration: 0.22, ease: [0.33, 1, 0.68, 1] }}
          className="absolute inset-0 text-center"
        >
          {value}
        </motion.span>
      </AnimatePresence>
    </span>
  );
});

function Countdown({ today, tomorrow }: { today: PrayerTimesDay; tomorrow: PrayerTimesDay | null }) {
  const now = useNow();
  const np = useMemo(() => nextPrayer(today, now, tomorrow ?? undefined), [today, tomorrow, now]);
  const { h, m, s } = formatCountdown(np.remainingMs);
  const hour12 = useStore(settingsStore, (st) => st.hour12);

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Next prayer</p>
        <p className="text-xs text-faint">{formatTime(np.at, today.timezone, hour12)}</p>
      </div>
      <div className="mt-1 flex items-end justify-between gap-3">
        <AnimatePresence mode="wait">
          <motion.h2
            key={np.name}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={base}
            className="text-3xl font-semibold tracking-tight"
          >
            {np.name}
          </motion.h2>
        </AnimatePresence>
        <div
          className="flex items-baseline gap-0.5 text-[28px] font-semibold leading-none tracking-tight text-brand-ink"
          aria-label={`${h} hours ${m} minutes ${s} seconds remaining`}
          role="timer"
        >
          <Digit value={h[0]} />
          <Digit value={h[1]} />
          <span className="text-faint">:</span>
          <Digit value={m[0]} />
          <Digit value={m[1]} />
          <span className="text-faint">:</span>
          <Digit value={s[0]} />
          <Digit value={s[1]} />
        </div>
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-track" aria-hidden>
        <motion.div
          className="h-full rounded-full bg-brand"
          animate={{ width: `${Math.round(np.progress * 100)}%` }}
          transition={{ duration: 0.6, ease: "linear" }}
        />
      </div>
      <PrayerRows today={today} next={np.name} hour12={hour12} />
    </div>
  );
}

const PrayerRows = memo(function PrayerRows({ today, next, hour12 }: { today: PrayerTimesDay; next: string; hour12: boolean }) {
  const enabled = useStore(settingsStore, (s) => s.notificationPrayers);
  const notifOn = useStore(settingsStore, (s) => s.notificationsEnabled);
  return (
    <ul className="mt-4 divide-y divide-line">
      {PRAYER_NAMES.map((name) => {
        const active = name === next;
        return (
          <li key={name} className={cn("flex items-center justify-between py-2.5", active && "text-brand-ink")}>
            <div className="flex items-center gap-2.5">
              <span className={cn("h-1.5 w-1.5 rounded-full", active ? "bg-brand" : "bg-faint/40")} />
              <span className={cn("text-sm", active ? "font-semibold" : "font-medium")}>{name}</span>
            </div>
            <div className="flex items-center gap-3">
              {notifOn && (
                <button
                  type="button"
                  aria-label={`${enabled[name] ? "Disable" : "Enable"} ${name} reminder`}
                  onClick={() =>
                    settingsStore.set((s) => ({ ...s, notificationPrayers: { ...s.notificationPrayers, [name]: !s.notificationPrayers[name] } }))
                  }
                  className={cn("focus-ring rounded-full p-1", enabled[name] ? "text-brand-ink" : "text-faint")}
                >
                  {enabled[name] ? <Bell size={14} /> : <BellOff size={14} />}
                </button>
              )}
              <span className={cn("text-sm tabular-nums", active ? "font-semibold" : "text-muted")}>
                {formatTime(today.times[name], today.timezone, hour12)}
              </span>
            </div>
          </li>
        );
      })}
    </ul>
  );
});

export function PrayerCard({ vm, onOpenSettings, onSetLocation }: { vm: PrayerTimesVM; onOpenSettings: () => void; onSetLocation: () => void }) {
  const cache = useStore(prayerCacheStore);
  const location = useStore(settingsStore, (s) => s.location);

  return (
    <section className="card p-5" aria-labelledby="prayer-heading">
      <div className="mb-3 flex items-center justify-between">
        <button
          type="button"
          onClick={onSetLocation}
          className="focus-ring flex min-w-0 items-center gap-1.5 rounded-full text-xs font-medium text-muted"
          aria-label="Change location"
        >
          <MapPin size={13} className="shrink-0 text-brand-ink" />
          <span className="truncate">{location?.label ?? (location ? `${location.lat.toFixed(2)}, ${location.lng.toFixed(2)}` : "Set your location")}</span>
        </button>
        <div className="flex items-center gap-1.5">
          {vm.status === "ready" && (
            <button type="button" onClick={vm.refresh} aria-label="Refresh prayer times" className="focus-ring rounded-full p-1.5 text-faint">
              <RefreshCw size={14} />
            </button>
          )}
          <button type="button" onClick={onOpenSettings} aria-label="Prayer settings" className="focus-ring rounded-full p-1.5 text-faint">
            <Settings2 size={16} />
          </button>
        </div>
      </div>
      <h2 id="prayer-heading" className="sr-only">
        Prayer times
      </h2>

      {vm.status === "no-location" && (
        <div className="py-4 text-center">
          <p className="text-sm text-muted">Sajidin needs your approximate location to calculate accurate prayer times. It never leaves your device.</p>
          <PrimaryButton onClick={onSetLocation} className="mt-4 w-full">
            <MapPin size={16} /> Set location
          </PrimaryButton>
        </div>
      )}

      {vm.status === "loading" && (
        <div className="space-y-3" aria-busy>
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-9 w-48" />
          <Skeleton className="h-1.5 w-full" />
          {PRAYER_NAMES.map((n) => (
            <Skeleton key={n} className="h-8 w-full" />
          ))}
        </div>
      )}

      {vm.status === "error" && <ErrorState message={vm.error ?? "Could not load prayer times."} onRetry={vm.refresh} compact />}

      {vm.status === "ready" && cache.today && (
        <>
          {(vm.stale || vm.error) && (
            <div className="mb-3 rounded-xl bg-warn-bg px-3 py-2 text-xs text-warn-ink" role="status">
              {vm.stale
                ? `Showing cached times for ${cache.today.date}. They may not match today — reconnect to refresh.`
                : `Showing saved times. ${vm.error}`}
            </div>
          )}
          <Countdown today={cache.today} tomorrow={cache.tomorrow} />
          <p className="mt-3 text-[11px] text-faint">
            {cache.today.method ?? "Calculation"} · {cache.today.timezone} · Source: AlAdhan
          </p>
        </>
      )}
    </section>
  );
}
