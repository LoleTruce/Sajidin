import { useCallback, useEffect, useRef, useState } from "react";
import { useStore } from "../../core/store";
import { localDateISO } from "../../lib/prayer";
import { fetchTimings } from "../../services/aladhan";
import { describeError } from "../../services/http";
import { schedulePrayerNotifications, clearScheduled } from "../../services/notifications";
import { prayerCacheStore, settingsStore } from "../../state/stores";

export interface PrayerTimesVM {
  status: "no-location" | "loading" | "ready" | "error";
  error: string | null;
  /** true when the cached day is not today's date (couldn't refresh) */
  stale: boolean;
  fromCache: boolean;
  refresh: () => void;
}

export function usePrayerTimes(): PrayerTimesVM {
  const location = useStore(settingsStore, (s) => s.location);
  const method = useStore(settingsStore, (s) => s.calculationMethod);
  const cache = useStore(prayerCacheStore);
  const notifEnabled = useStore(settingsStore, (s) => s.notificationsEnabled);
  const notifPrayers = useStore(settingsStore, (s) => s.notificationPrayers);
  const notifLead = useStore(settingsStore, (s) => s.notificationLeadMinutes);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fromCache, setFromCache] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const [tick, setTick] = useState(0);

  const key = location ? `${location.lat},${location.lng},${method}` : null;
  const todayISO = cache.today ? localDateISO(new Date(), cache.today.timezone) : localDateISO();
  const cacheMatches = !!key && cache.key === key && !!cache.today;
  const cacheIsToday = cacheMatches && cache.today!.date === todayISO;

  const load = useCallback(async () => {
    if (!location) return;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    setError(null);
    try {
      const now = new Date();
      const tomorrow = new Date(now.getTime() + 86_400_000);
      const [t1, t2] = await Promise.all([
        fetchTimings({ lat: location.lat, lng: location.lng, method, date: now }, controller.signal),
        fetchTimings({ lat: location.lat, lng: location.lng, method, date: tomorrow }, controller.signal).catch(() => null),
      ]);
      if (controller.signal.aborted) return;
      prayerCacheStore.set({ today: t1.day, tomorrow: t2?.day ?? null, fetchedAt: Date.now(), key: `${location.lat},${location.lng},${method}` });
      setFromCache(false);
    } catch (e) {
      if (controller.signal.aborted) return;
      setError(describeError(e));
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, [location, method]);

  // Fetch when location/method change or when cache is not for today.
  useEffect(() => {
    if (!location) return;
    if (cacheIsToday) {
      setFromCache(true);
      return;
    }
    void load();
    return () => abortRef.current?.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, cacheIsToday, tick]);

  // Re-evaluate at the next local midnight so the date rollover triggers a refresh.
  useEffect(() => {
    const now = new Date();
    const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5);
    const id = window.setTimeout(() => setTick((t) => t + 1), next.getTime() - now.getTime());
    return () => clearTimeout(id);
  }, [tick]);

  // Refresh when coming back online after a failure.
  useEffect(() => {
    const onOnline = () => {
      if (error) setTick((t) => t + 1);
    };
    window.addEventListener("online", onOnline);
    return () => window.removeEventListener("online", onOnline);
  }, [error]);

  // (Re)schedule notifications whenever times or preferences change.
  useEffect(() => {
    if (!cache.today || !notifEnabled) {
      clearScheduled();
      return;
    }
    schedulePrayerNotifications(cache.today, { enabled: notifPrayers, leadMinutes: notifLead });
    return clearScheduled;
  }, [cache.today, notifEnabled, notifPrayers, notifLead]);

  let status: PrayerTimesVM["status"] = "ready";
  if (!location) status = "no-location";
  else if (!cacheMatches && loading) status = "loading";
  else if (!cacheMatches && error) status = "error";
  else if (!cacheMatches) status = "loading";

  return {
    status,
    error,
    stale: cacheMatches && !cacheIsToday,
    fromCache: fromCache && !loading,
    refresh: () => setTick((t) => t + 1),
  };
}
