import { motion } from "framer-motion";
import { BookOpen, Compass, Fingerprint, HandHeart } from "lucide-react";
import { useState } from "react";
import type { Tab } from "../../components/BottomNav";
import { ScreenHeader } from "../../components/ui";
import { fadeUp, staggerContainer } from "../../core/motion";
import { useStore } from "../../core/store";
import { bookmarksStore, prayerCacheStore } from "../../state/stores";
import { HadithCard } from "./HadithCard";
import { LocationSheet, PrayerSettingsSheet } from "./HomeSettings";
import { PrayerCard } from "./PrayerCard";
import { usePrayerTimes } from "./usePrayerTimes";

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return "Peaceful night";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  if (h < 21) return "Good evening";
  return "Peaceful night";
}

export function HomeScreen({ onNavigate }: { onNavigate: (t: Tab, payload?: { surah?: number; tool?: "tasbih" | "duas" }) => void }) {
  const vm = usePrayerTimes();
  const [sheet, setSheet] = useState<"none" | "location" | "settings">("none");
  const hijri = useStore(prayerCacheStore, (c) => c.today?.hijri);
  const lastRead = useStore(bookmarksStore, (b) => b.lastRead);

  return (
    <div className="mx-auto max-w-xl pb-28">
      <ScreenHeader
        title="Assalamu alaikum"
        subtitle={greeting()}
        right={
          hijri ? (
            <div className="text-right">
              <p className="text-sm font-semibold text-brand-ink">
                {hijri.day} {hijri.month}
              </p>
              <p className="text-xs text-faint">{hijri.year} AH</p>
            </div>
          ) : undefined
        }
      />

      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-4 px-4">
        <motion.div variants={fadeUp}>
          <PrayerCard vm={vm} onOpenSettings={() => setSheet("settings")} onSetLocation={() => setSheet("location")} />
        </motion.div>

        <motion.div variants={fadeUp}>
          <HadithCard />
        </motion.div>

        <motion.div variants={fadeUp} className="grid grid-cols-2 gap-3">
          <QuickAction
            icon={<BookOpen size={18} />}
            title={lastRead ? "Continue reading" : "Read Quran"}
            sub={lastRead ? `Surah ${lastRead.surah} · Ayah ${lastRead.ayah}` : "All 114 Surahs"}
            onClick={() => onNavigate("quran", { surah: lastRead?.surah })}
          />
          <QuickAction icon={<Compass size={18} />} title="Find Qibla" sub="Offline compass" onClick={() => onNavigate("qibla")} />
          <QuickAction icon={<Fingerprint size={18} />} title="Tasbih" sub="Digital counter" onClick={() => onNavigate("tools", { tool: "tasbih" })} />
          <QuickAction icon={<HandHeart size={18} />} title="Daily Duas" sub="Hisn al-Muslim" onClick={() => onNavigate("tools", { tool: "duas" })} />
        </motion.div>

        <motion.p variants={fadeUp} className="px-1 pt-2 text-center text-[11px] leading-relaxed text-faint">
          Sajidin is free, ad-free and collects no personal data. Prayer times by AlAdhan · Quran text by Tanzil via Al Quran Cloud.
        </motion.p>
      </motion.div>

      <LocationSheet open={sheet === "location"} onClose={() => setSheet("none")} />
      <PrayerSettingsSheet open={sheet === "settings"} onClose={() => setSheet("none")} />
    </div>
  );
}

function QuickAction({ icon, title, sub, onClick }: { icon: React.ReactNode; title: string; sub: string; onClick: () => void }) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className="card focus-ring flex flex-col items-start gap-3 p-4 text-left"
    >
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-soft text-brand-ink">{icon}</span>
      <span>
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs text-faint">{sub}</span>
      </span>
    </motion.button>
  );
}
