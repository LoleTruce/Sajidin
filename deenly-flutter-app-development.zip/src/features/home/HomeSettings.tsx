import { Bell, Crosshair, Loader2, Search } from "lucide-react";
import { useState } from "react";
import { PrimaryButton, Sheet, Toggle, useToast } from "../../components/ui";
import { useStore } from "../../core/store";
import { PRAYER_NAMES } from "../../lib/prayer";
import { CALCULATION_METHODS, fetchTimingsByCity } from "../../services/aladhan";
import { describeGeoError, getDeviceLocation } from "../../services/geolocation";
import { describeError } from "../../services/http";
import { canDisplayNotifications, notificationPermission, requestNotificationPermission } from "../../services/notifications";
import { settingsStore } from "../../state/stores";
import { cn } from "../../utils/cn";

/* ---------- Location sheet ---------- */
export function LocationSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [busy, setBusy] = useState<"device" | "city" | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  const method = useStore(settingsStore, (s) => s.calculationMethod);
  const toast = useToast();

  const useDevice = async () => {
    setBusy("device");
    setErr(null);
    try {
      const loc = await getDeviceLocation();
      settingsStore.set({ location: loc });
      toast("Location updated", "success");
      onClose();
    } catch (e) {
      setErr(describeGeoError(e));
    } finally {
      setBusy(null);
    }
  };

  const useCity = async () => {
    if (!city.trim() || !country.trim()) {
      setErr("Enter both a city and a country.");
      return;
    }
    setBusy("city");
    setErr(null);
    try {
      const res = await fetchTimingsByCity(city.trim(), country.trim(), method, new Date());
      settingsStore.set({
        location: { lat: res.meta.lat, lng: res.meta.lng, label: `${city.trim()}, ${country.trim()}`, at: Date.now(), source: "manual" },
      });
      toast("Location set", "success");
      onClose();
    } catch (e) {
      setErr(describeError(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Location">
      <p className="text-sm text-muted">Used only on your device to calculate prayer times and the Qibla direction.</p>
      <PrimaryButton onClick={useDevice} disabled={busy !== null} className="mt-4 w-full">
        {busy === "device" ? <Loader2 size={16} className="animate-spin" /> : <Crosshair size={16} />} Use my current location
      </PrimaryButton>
      <div className="my-5 flex items-center gap-3 text-xs text-faint">
        <span className="h-px flex-1 bg-track" /> or enter manually <span className="h-px flex-1 bg-track" />
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void useCity();
        }}
        className="space-y-2"
      >
        <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City (e.g. London)" aria-label="City" className="focus-ring w-full rounded-2xl bg-card-2 px-4 py-3 text-sm hairline placeholder:text-faint" />
        <input value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Country (e.g. United Kingdom)" aria-label="Country" className="focus-ring w-full rounded-2xl bg-card-2 px-4 py-3 text-sm hairline placeholder:text-faint" />
        <PrimaryButton type="submit" variant="ghost" disabled={busy !== null} className="w-full">
          {busy === "city" ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />} Find city
        </PrimaryButton>
      </form>
      {err && (
        <p role="alert" className="mt-3 rounded-xl bg-danger-bg px-3 py-2 text-xs text-danger-ink">
          {err}
        </p>
      )}
    </Sheet>
  );
}

/* ---------- Prayer settings sheet ---------- */
export function PrayerSettingsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useStore(settingsStore);
  const toast = useToast();
  const perm = notificationPermission();

  const toggleNotifications = async (v: boolean) => {
    if (!v) {
      settingsStore.set({ notificationsEnabled: false });
      return;
    }
    const p = await requestNotificationPermission();
    if (p === "granted") {
      settingsStore.set({ notificationsEnabled: true });
      toast("Reminders enabled", "success");
    } else if (p === "unsupported") {
      toast("Notifications aren't supported in this browser", "error");
    } else {
      toast("Notification permission was not granted", "error");
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Prayer settings">
      <h3 className="text-xs font-medium uppercase tracking-[0.14em] text-faint">Calculation method</h3>
      <select
        value={s.calculationMethod}
        onChange={(e) => settingsStore.set({ calculationMethod: Number(e.target.value) })}
        aria-label="Calculation method"
        className="focus-ring mt-2 w-full rounded-2xl bg-card-2 px-4 py-3 text-sm hairline"
      >
        {CALCULATION_METHODS.map((m) => (
          <option key={m.id} value={m.id} className="bg-card">
            {m.name}
          </option>
        ))}
      </select>

      <div className="mt-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">12-hour clock</p>
          <p className="text-xs text-faint">Display times as 5:42 PM</p>
        </div>
        <Toggle checked={s.hour12} onChange={(v) => settingsStore.set({ hour12: v })} label="12-hour clock" />
      </div>

      <h3 className="mt-7 text-xs font-medium uppercase tracking-[0.14em] text-faint">Prayer reminders</h3>
      <div className="mt-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={16} className="text-brand-ink" />
          <p className="text-sm font-medium">Enable reminders</p>
        </div>
        <Toggle checked={s.notificationsEnabled && perm === "granted"} onChange={(v) => void toggleNotifications(v)} label="Enable prayer reminders" />
      </div>
      {perm === "denied" && (
        <p className="mt-2 text-xs text-danger-ink">Notifications are blocked for this site. Re-enable them in your browser's site settings.</p>
      )}
      {perm === "granted" && s.notificationsEnabled && !canDisplayNotifications() && (
        <p className="mt-2 text-xs text-warn-ink">This browser can't display notifications from an uninstalled page. Install Sajidin to your home screen to receive reminders.</p>
      )}

      <div className={cn("mt-4 space-y-3 transition-opacity", !s.notificationsEnabled && "pointer-events-none opacity-40")}>
        <div>
          <label htmlFor="lead" className="text-sm font-medium">
            Remind me {s.notificationLeadMinutes === 0 ? "at prayer time" : `${s.notificationLeadMinutes} min before`}
          </label>
          <input id="lead" type="range" min={0} max={30} step={5} value={s.notificationLeadMinutes} onChange={(e) => settingsStore.set({ notificationLeadMinutes: Number(e.target.value) })} className="mt-1 w-full" />
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {PRAYER_NAMES.map((name) => {
            const on = s.notificationPrayers[name];
            return (
              <button
                key={name}
                type="button"
                aria-pressed={on}
                onClick={() => settingsStore.set((st) => ({ ...st, notificationPrayers: { ...st.notificationPrayers, [name]: !on } }))}
                className={cn("press focus-ring rounded-xl py-2 text-xs font-semibold", on ? "bg-brand text-on-brand" : "hairline bg-card-2 text-muted")}
              >
                {name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 rounded-2xl bg-card-2 p-3 text-xs leading-relaxed text-muted hairline">
        <strong className="text-ink">How reminders work.</strong> Sajidin schedules a notification for each enabled prayer using your browser's
        notification system. Web apps can't run while fully closed, so reminders fire when Sajidin is open or kept in the background — add it to your
        home screen for the most reliable experience. No Adhan audio is played by reminders.
      </div>
    </Sheet>
  );
}
