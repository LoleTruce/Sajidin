import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, BookOpenText, Check, Cloud, CloudOff, Loader2, Moon, RotateCcw, Sun } from "lucide-react";
import { useState } from "react";
import { ConfirmDialog, PrimaryButton, Toggle, useToast } from "../../components/ui";
import { fadeUp, staggerContainer } from "../../core/motion";
import { haptics } from "../../core/haptics";
import { pickOnColor } from "../../theme/color";
import { ACCENTS, ACCENT_IDS, MODES, THEME_MODES, type AccentId, type ThemeMode } from "../../theme/tokens";
import { themeController, useAccent, useThemeMode, useThemeSync } from "../../theme/themeStore";
import { useStore } from "../../core/store";
import { settingsStore } from "../../state/stores";
import { cn } from "../../utils/cn";

const MODE_ICONS: Record<ThemeMode, typeof Moon> = { dark: Moon, light: Sun, sepia: BookOpenText };

export function CustomizationSettings({ onBack }: { onBack: () => void }) {
  const mode = useThemeMode();
  const accent = useAccent();
  const sync = useThemeSync();
  const reduce = useReducedMotion();
  const toast = useToast();
  const [confirmReset, setConfirmReset] = useState(false);

  const isDefault = mode === "dark" && accent === "mint";

  return (
    <div className="mx-auto max-w-xl pb-28">
      <header className="sticky top-0 z-10 flex items-center gap-2 bg-bg/90 px-3 pb-3 backdrop-blur-xl" style={{ paddingTop: "calc(var(--safe-top) + 10px)" }}>
        <button type="button" onClick={onBack} aria-label="Back" className="focus-ring press grid h-10 w-10 place-items-center rounded-full text-ink">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-lg font-semibold tracking-tight">Appearance & Customization</h1>
      </header>

      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-6 px-4 pt-2">
        {/* ---------- Appearance mode ---------- */}
        <motion.section variants={fadeUp} aria-labelledby="appearance-heading">
          <SectionHeading id="appearance-heading" title="Appearance" text="Customise how Sajidin looks. Changes apply instantly across the whole app." />
          <div role="radiogroup" aria-labelledby="appearance-heading" className="grid grid-cols-3 gap-2">
            {THEME_MODES.map((m) => {
              const def = MODES[m];
              const Icon = MODE_ICONS[m];
              const selected = m === mode;
              return (
                <motion.button
                  key={m}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  aria-label={`${def.name} mode. ${def.description}`}
                  whileTap={reduce ? undefined : { scale: 0.97 }}
                  onClick={() => {
                    if (selected) return;
                    haptics.light();
                    themeController.setThemeMode(m);
                  }}
                  className={cn(
                    "focus-ring relative flex min-h-[112px] flex-col items-start gap-2 rounded-2xl border p-3 text-left transition-colors duration-200",
                    selected ? "border-brand bg-brand-soft" : "border-line bg-card",
                  )}
                >
                  {/* Miniature swatch of the mode's surfaces */}
                  <span className="flex h-7 w-full items-center gap-1 overflow-hidden rounded-lg border border-line px-1" style={{ background: def.bg }} aria-hidden>
                    <span className="h-4 w-4 rounded-md" style={{ background: def.card }} />
                    <span className="h-1.5 flex-1 rounded-full" style={{ background: def.muted, opacity: 0.6 }} />
                    <span className="h-3 w-3 rounded-full" style={{ background: ACCENTS[accent].hex }} />
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Icon size={15} className={selected ? "text-brand-ink" : "text-muted"} />
                    <span className="text-sm font-semibold">{def.name}</span>
                  </span>
                  <span className="text-[11px] leading-snug text-faint">{def.description}</span>
                  <AnimatePresence>
                    {selected && (
                      <motion.span
                        initial={{ scale: 0.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.5, opacity: 0 }}
                        transition={{ duration: 0.18 }}
                        className="absolute right-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-brand text-on-brand"
                      >
                        <Check size={12} strokeWidth={3} />
                      </motion.span>
                    )}
                  </AnimatePresence>
                </motion.button>
              );
            })}
          </div>
          {mode === "sepia" && <p className="mt-2 text-[11px] leading-relaxed text-faint">Sepia is a warm reading option many people find comfortable for long sessions; it isn't a medical treatment for eye strain.</p>}
        </motion.section>

        {/* ---------- Accent colour ---------- */}
        <motion.section variants={fadeUp} aria-labelledby="accent-heading">
          <SectionHeading id="accent-heading" title="Accent Colour" text="Personalise the colours used throughout Sajidin." />
          <div role="radiogroup" aria-labelledby="accent-heading" className="card grid grid-cols-4 gap-2 p-3">
            {ACCENT_IDS.map((id) => (
              <AccentSwatch key={id} id={id} selected={id === accent} reduce={!!reduce} />
            ))}
          </div>
        </motion.section>

        {/* ---------- Live preview ---------- */}
        <motion.section variants={fadeUp} aria-labelledby="preview-heading">
          <SectionHeading id="preview-heading" title="Preview" text="A quick look at your current configuration." />
          <PreviewCard />
        </motion.section>

        {/* ---------- Feedback ---------- */}
        <motion.section variants={fadeUp} aria-labelledby="feedback-heading">
          <SectionHeading id="feedback-heading" title="Feedback" />
          <HapticsRow />
        </motion.section>

        {/* ---------- Sync status ---------- */}
        <motion.section variants={fadeUp} aria-labelledby="sync-heading">
          <SectionHeading id="sync-heading" title="Sync" />
          <div className="card flex items-start gap-3 p-4">
            <span className={cn("mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl", sync.sync === "error" ? "bg-danger-bg text-danger-ink" : "bg-brand-soft text-brand-ink")}>
              {sync.sync === "syncing" ? <Loader2 size={16} className="animate-spin" /> : sync.sync === "signed-out" || sync.sync === "error" ? <CloudOff size={16} /> : <Cloud size={16} />}
            </span>
            <div className="min-w-0 text-sm">
              <p className="font-medium">{syncTitle(sync.sync)}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-faint">{sync.syncError ?? syncBody(sync.sync, sync.lastSyncedAt)}</p>
              {!sync.persistenceAvailable && <p className="mt-1 text-xs text-warn-ink">Storage is unavailable in this browser, so preferences will reset when you close the app.</p>}
            </div>
          </div>
        </motion.section>

        {/* ---------- Reset ---------- */}
        <motion.section variants={fadeUp}>
          <PrimaryButton variant="ghost" disabled={isDefault} onClick={() => setConfirmReset(true)} className="w-full">
            <RotateCcw size={16} /> Reset to Defaults
          </PrimaryButton>
          <p className="mt-2 text-center text-[11px] text-faint">Restores Dark mode and Mint Emerald. Your bookmarks, Tasbih counts and account are not affected.</p>
        </motion.section>
      </motion.div>

      <ConfirmDialog
        open={confirmReset}
        title="Reset appearance?"
        message="This restores Dark mode with the Mint Emerald accent. It only affects appearance preferences — not your account data, Quran bookmarks or counters."
        confirmLabel="Reset"
        onCancel={() => setConfirmReset(false)}
        onConfirm={() => {
          themeController.resetToDefaults();
          haptics.medium();
          setConfirmReset(false);
          toast("Appearance reset to defaults", "success");
        }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */

function SectionHeading({ id, title, text }: { id: string; title: string; text?: string }) {
  return (
    <div className="mb-2.5">
      <h2 id={id} className="text-xs font-semibold uppercase tracking-[0.14em] text-muted">
        {title}
      </h2>
      {text && <p className="mt-1 text-sm text-faint">{text}</p>}
    </div>
  );
}

function AccentSwatch({ id, selected, reduce }: { id: AccentId; selected: boolean; reduce: boolean }) {
  const def = ACCENTS[id];
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      aria-label={def.name}
      title={def.name}
      onClick={() => {
        if (selected) return;
        haptics.light();
        themeController.setAccent(id);
      }}
      className="focus-ring group flex min-h-[72px] flex-col items-center justify-center gap-1.5 rounded-xl py-1"
    >
      <motion.span
        animate={{ scale: selected ? 1.08 : 1 }}
        transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 420, damping: 26 }}
        className={cn("relative grid h-11 w-11 place-items-center rounded-full ring-offset-2 ring-offset-card transition-shadow duration-200", selected ? "ring-2 ring-ink/70" : "ring-1 ring-line")}
        style={{ background: def.hex }}
      >
        <AnimatePresence>
          {selected && (
            <motion.span initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.4, opacity: 0 }} transition={{ duration: 0.18 }} style={{ color: pickOnColor(def.hex, def.darkOn) }} className="grid place-items-center">
              <Check size={18} strokeWidth={3} />
            </motion.span>
          )}
        </AnimatePresence>
      </motion.span>
      <span className={cn("text-center text-[10px] font-medium leading-tight", selected ? "text-ink" : "text-faint")}>{def.name.split(" ")[0]}</span>
    </button>
  );
}

function PreviewCard() {
  const [demoToggle, setDemoToggle] = useState(true);
  const accent = useAccent();
  const mode = useThemeMode();
  return (
    <div className="card p-4" aria-label="Theme preview">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-base font-semibold">Fajr in 2h 14m</p>
          <p className="text-xs text-muted">
            {MODES[mode].name} · {ACCENTS[accent].name}
          </p>
        </div>
        <Toggle checked={demoToggle} onChange={setDemoToggle} label="Preview switch" />
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-track" aria-hidden>
        <motion.div className="h-full rounded-full bg-brand" animate={{ width: "62%" }} initial={false} />
      </div>
      <p lang="ar" dir="rtl" className="font-arabic mt-4 text-[22px] leading-[1.9] text-ink">
        بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
      </p>
      <p className="text-sm leading-relaxed text-ink/85">In the name of Allah, the Entirely Merciful, the Especially Merciful.</p>
      <div className="mt-4 flex items-center gap-2">
        <PrimaryButton className="flex-1">Primary action</PrimaryButton>
        <span className="rounded-full bg-brand-soft px-3 py-1.5 text-xs font-semibold text-brand-ink">Sahih</span>
      </div>
    </div>
  );
}

function HapticsRow() {
  const enabled = useStore(settingsStore, (s) => s.hapticsEnabled);
  const supported = haptics.supported;
  return (
    <div className="card flex items-center justify-between gap-3 p-4">
      <div className="min-w-0">
        <p className="text-sm font-medium">Haptic feedback</p>
        <p className="mt-0.5 text-xs leading-relaxed text-faint">{supported ? "Gentle vibration on Tasbih taps, Qibla alignment and selections." : "This device or browser doesn't expose vibration; visual feedback is always used."}</p>
      </div>
      <Toggle checked={enabled && supported} onChange={(v) => settingsStore.set({ hapticsEnabled: v })} label="Haptic feedback" />
    </div>
  );
}

function syncTitle(s: ReturnType<typeof useThemeSync>["sync"]): string {
  switch (s) {
    case "signed-out":
      return "Saved on this device";
    case "syncing":
      return "Syncing…";
    case "synced":
      return "Synced to your profile";
    case "pending":
      return "Waiting to sync";
    case "error":
      return "Sync unavailable";
    default:
      return "Appearance";
  }
}

function syncBody(s: ReturnType<typeof useThemeSync>["sync"], last: number | null): string {
  if (s === "signed-out") return "You don't need an account to customise Sajidin. When you sign in, your appearance follows you to other devices.";
  if (s === "synced" && last) return `Last synced ${new Date(last).toLocaleTimeString()}.`;
  if (s === "pending") return "Your change is saved locally and will upload shortly.";
  return "Your preferences are always saved locally first.";
}
