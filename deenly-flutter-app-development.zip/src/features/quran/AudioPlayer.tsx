import { AnimatePresence, motion } from "framer-motion";
import { Loader2, Pause, Play, SkipBack, SkipForward, X } from "lucide-react";
import { useStore } from "../../core/store";
import { audioController, audioStore } from "../../state/audio";
import { RECITERS } from "../../services/quranApi";

function fmt(s: number): string {
  if (!Number.isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

/** Persistent mini-player; mounted at app level so playback survives navigation. */
export function AudioPlayer() {
  const a = useStore(audioStore);
  const visible = a.status !== "idle" && a.surah;
  const ayah = a.ayahs[a.index];
  const pct = a.duration ? (a.currentTime / a.duration) * 100 : 0;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ duration: 0.3, ease: [0.33, 1, 0.68, 1] }}
          className="fixed inset-x-0 z-20 mx-auto max-w-xl px-3"
          style={{ bottom: "calc(74px + var(--safe-bottom))" }}
          role="region"
          aria-label="Quran audio player"
        >
          <div className="card overflow-hidden bg-card/95 backdrop-blur-xl">
            <div className="flex items-center gap-2 px-3 pt-2.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">
                  {a.surah!.englishName} <span className="text-faint">· Ayah {ayah?.numberInSurah}</span>
                </p>
                <p className="truncate text-[11px] text-faint">
                  {a.status === "error" ? <span className="text-danger-ink">{a.error}</span> : RECITERS.find((r) => r.id === a.reciter)?.name}
                </p>
              </div>
              <button type="button" aria-label="Previous Ayah" onClick={() => void audioController.prev()} className="focus-ring rounded-full p-2 text-muted">
                <SkipBack size={18} />
              </button>
              <motion.button
                type="button"
                whileTap={{ scale: 0.92 }}
                aria-label={a.status === "playing" ? "Pause" : "Play"}
                onClick={() => void audioController.toggle()}
                className="focus-ring grid h-10 w-10 place-items-center rounded-full bg-brand text-on-brand"
              >
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span key={a.status} initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }} transition={{ duration: 0.15 }}>
                    {a.status === "loading" ? <Loader2 size={18} className="animate-spin" /> : a.status === "playing" ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                  </motion.span>
                </AnimatePresence>
              </motion.button>
              <button type="button" aria-label="Next Ayah" onClick={() => void audioController.next()} className="focus-ring rounded-full p-2 text-muted">
                <SkipForward size={18} />
              </button>
              <button type="button" aria-label="Close player" onClick={() => audioController.stop()} className="focus-ring rounded-full p-2 text-faint">
                <X size={16} />
              </button>
            </div>
            <div className="flex items-center gap-2 px-3 pb-2.5 pt-1">
              <span className="w-9 text-[10px] tabular-nums text-faint">{fmt(a.currentTime)}</span>
              <input
                type="range"
                min={0}
                max={a.duration || 0}
                step={0.1}
                value={Math.min(a.currentTime, a.duration || 0)}
                onChange={(e) => audioController.seek(Number(e.target.value))}
                aria-label="Seek"
                aria-valuetext={`${fmt(a.currentTime)} of ${fmt(a.duration)}`}
                className="h-1 flex-1"
                style={{ background: `linear-gradient(90deg, var(--t-brand) ${pct}%, rgba(255,255,255,0.08) ${pct}%)`, appearance: "none", borderRadius: 999 }}
              />
              <span className="w-9 text-right text-[10px] tabular-nums text-faint">{fmt(a.duration)}</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
