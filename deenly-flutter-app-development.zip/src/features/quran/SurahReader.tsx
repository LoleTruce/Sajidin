import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Bookmark, ChevronLeft, ChevronRight, Loader2, Pause, Play, Settings2, Share2, Type } from "lucide-react";
import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chip, ErrorState, IconButton, Sheet, shareOrCopy, Skeleton, Toggle, useToast } from "../../components/ui";
import { fadeIn } from "../../core/motion";
import { useStore } from "../../core/store";
import { describeError } from "../../services/http";
import { getSurah, RECITERS, TRANSLATIONS, type Ayah, type SurahContent } from "../../services/quranApi";
import { audioController, audioStore } from "../../state/audio";
import { bookmarksStore, quranPrefsStore, toggleInList } from "../../state/stores";
import { BRAND } from "../../core/brand";
import { cn } from "../../utils/cn";

export function SurahReader({ number, onBack, onChangeSurah }: { number: number; onBack: () => void; onChangeSurah: (n: number) => void }) {
  const prefs = useStore(quranPrefsStore);
  const [content, setContent] = useState<SurahContent | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fromCache, setFromCache] = useState(false);
  const [retry, setRetry] = useState(0);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const playerVisible = useStore(audioStore, (a) => a.status !== "idle");
  const playingSurah = useStore(audioStore, (a) => a.surah?.number);
  const playingIndex = useStore(audioStore, (a) => a.index);
  const playStatus = useStore(audioStore, (a) => a.status);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctrl = new AbortController();
    setContent(null);
    setError(null);
    getSurah(number, prefs.translationEdition, ctrl.signal)
      .then((r) => {
        setContent(r.content);
        setFromCache(r.fromCache);
      })
      .catch((e) => !ctrl.signal.aborted && setError(describeError(e)));
    return () => ctrl.abort();
  }, [number, prefs.translationEdition, retry]);

  // Track reading progress: the ayah nearest the top of the viewport (throttled via IntersectionObserver).
  useEffect(() => {
    if (!content) return;
    const root = scrollRef.current;
    if (!root) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (!visible) return;
        const ayah = Number((visible.target as HTMLElement).dataset.ayah);
        if (ayah) bookmarksStore.set((b) => ({ ...b, lastRead: { surah: number, ayah, at: Date.now() } }));
      },
      { root: null, rootMargin: "-20% 0px -70% 0px" },
    );
    root.querySelectorAll("[data-ayah]").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, [content, number]);

  // Auto-scroll to the ayah currently being recited.
  useEffect(() => {
    if (playingSurah !== number || !content) return;
    const el = scrollRef.current?.querySelector(`[data-ayah="${content.ayahs[playingIndex]?.numberInSurah}"]`);
    el?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [playingIndex, playingSurah, number, content]);

  const playFrom = useCallback(
    (index: number) => {
      if (!content) return;
      if (playingSurah === number && playingIndex === index && playStatus === "playing") {
        audioController.pause();
        return;
      }
      if (playingSurah === number && playingIndex === index) {
        void audioController.play();
        return;
      }
      void audioController.playSurah(content.meta, content.ayahs, index, prefs.reciter);
    },
    [content, number, playingSurah, playingIndex, playStatus, prefs.reciter],
  );

  const isPlayingThis = playingSurah === number && (playStatus === "playing" || playStatus === "loading");
  const wide = prefs.sideBySide;
  const showBismillah = number !== 1 && number !== 9;

  return (
    <div ref={scrollRef} className={cn("mx-auto max-w-3xl", playerVisible ? "pb-44" : "pb-28")}>
      <header className="sticky top-0 z-10 flex items-center gap-2 bg-bg/90 px-3 pb-2 backdrop-blur-xl" style={{ paddingTop: "calc(var(--safe-top) + 10px)" }}>
        <IconButton label="Back to Surah list" onClick={onBack} className="bg-transparent border-0">
          <ArrowLeft size={20} />
        </IconButton>
        <div className="min-w-0 flex-1">
          {content ? (
            <>
              <p className="truncate text-sm font-semibold">
                {content.meta.number}. {content.meta.englishName}
              </p>
              <p className="truncate text-[11px] text-faint">
                {content.meta.englishNameTranslation} · {content.meta.numberOfAyahs} Ayahs · {content.meta.revelationType === "Meccan" ? "Makki" : "Madani"}
                {fromCache && " · offline copy"}
              </p>
            </>
          ) : (
            <Skeleton className="h-5 w-32" />
          )}
        </div>
        <IconButton label={isPlayingThis ? "Pause recitation" : "Play Surah"} onClick={() => (isPlayingThis ? audioController.pause() : playFrom(playingSurah === number ? playingIndex : 0))} disabled={!content} active={isPlayingThis}>
          {isPlayingThis ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
        </IconButton>
        <IconButton label="Reading settings" onClick={() => setSettingsOpen(true)}>
          <Type size={16} />
        </IconButton>
      </header>

      <div className="px-4">
        {error && !content && <ErrorState message={error} onRetry={() => setRetry((r) => r + 1)} />}
        {!content && !error && (
          <div className="space-y-3 pt-3" aria-busy>
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-28 w-full rounded-2xl" />
            ))}
          </div>
        )}
        {content && (
          <motion.div variants={fadeIn} initial="hidden" animate="show">
            <div className="card my-3 px-5 py-6 text-center">
              <p lang="ar" dir="rtl" className="font-arabic text-3xl text-ink">
                {content.meta.name}
              </p>
              {showBismillah && (
                <p lang="ar" dir="rtl" className="font-arabic mt-3 text-xl text-brand-ink">
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </p>
              )}
            </div>

            <ol className="space-y-3" aria-label="Verses">
              {content.ayahs.map((ayah, i) => (
                <AyahCard
                  key={ayah.number}
                  surah={number}
                  ayah={ayah}
                  isCurrent={playingSurah === number && playingIndex === i}
                  isPlaying={playingSurah === number && playingIndex === i && playStatus === "playing"}
                  isLoading={playingSurah === number && playingIndex === i && playStatus === "loading"}
                  onPlay={() => playFrom(i)}
                  scale={prefs.arabicScale}
                  showTranslation={prefs.showTranslation}
                  showTransliteration={prefs.showTransliteration}
                  wide={wide}
                  stripBismillah={showBismillah && i === 0}
                />
              ))}
            </ol>

            <div className="mt-5 flex items-center justify-between gap-3">
              <button type="button" disabled={number <= 1} onClick={() => onChangeSurah(number - 1)} className="press focus-ring flex items-center gap-1 rounded-full bg-card px-4 py-2.5 text-sm font-medium hairline disabled:opacity-30">
                <ChevronLeft size={16} /> Previous
              </button>
              <button type="button" disabled={number >= 114} onClick={() => onChangeSurah(number + 1)} className="press focus-ring flex items-center gap-1 rounded-full bg-card px-4 py-2.5 text-sm font-medium hairline disabled:opacity-30">
                Next <ChevronRight size={16} />
              </button>
            </div>
            <p className="mt-5 text-center text-[11px] leading-relaxed text-faint">
              Arabic: Tanzil Uthmani text · Translation: {TRANSLATIONS.find((t) => t.id === content.translationEdition)?.name} · via Al Quran Cloud
            </p>
          </motion.div>
        )}
      </div>

      <ReaderSettings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}

const BISMILLAH_PREFIX = /^بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ\s*/;

const AyahCard = memo(function AyahCard({
  surah,
  ayah,
  isCurrent,
  isPlaying,
  isLoading,
  onPlay,
  scale,
  showTranslation,
  showTransliteration,
  wide,
  stripBismillah,
}: {
  surah: number;
  ayah: Ayah;
  isCurrent: boolean;
  isPlaying: boolean;
  isLoading: boolean;
  onPlay: () => void;
  scale: number;
  showTranslation: boolean;
  showTransliteration: boolean;
  wide: boolean;
  stripBismillah: boolean;
}) {
  const key = `${surah}:${ayah.numberInSurah}`;
  const saved = useStore(bookmarksStore, (b) => b.ayahs.includes(key));
  const toast = useToast();
  // The Uthmani edition prefixes the Basmalah to the first ayah; we display it separately in the header
  // (never altering the stored text) so the verse body remains readable.
  const arabic = useMemo(() => (stripBismillah ? ayah.arabic.replace(BISMILLAH_PREFIX, "") : ayah.arabic), [ayah.arabic, stripBismillah]);

  const share = async () => {
    const r = await shareOrCopy(`${ayah.arabic}\n\n${ayah.translation}\n— Quran ${surah}:${ayah.numberInSurah}\n\n${BRAND.shareSuffix}`, `Quran ${surah}:${ayah.numberInSurah}`);
    if (r === "copied") toast("Copied to clipboard", "success");
  };

  return (
    <li data-ayah={ayah.numberInSurah} className={cn("card p-4 transition-colors duration-300", isCurrent && "border-brand/40 bg-brand-soft")}>
      <div className="mb-3 flex items-center justify-between">
        <span className="grid h-7 min-w-7 place-items-center rounded-lg bg-card-2 px-1.5 text-xs font-semibold text-brand-ink tabular-nums">
          {surah}:{ayah.numberInSurah}
        </span>
        <div className="flex items-center gap-1">
          <button type="button" aria-label={isPlaying ? "Pause this Ayah" : "Play this Ayah"} onClick={onPlay} className={cn("focus-ring rounded-full p-2", isCurrent ? "text-brand-ink" : "text-faint")}>
            {isLoading ? <Loader2 size={16} className="animate-spin" /> : isPlaying ? <Pause size={16} /> : <Play size={16} />}
          </button>
          <button type="button" aria-label={saved ? "Remove bookmark" : "Bookmark Ayah"} onClick={() => bookmarksStore.set((b) => ({ ...b, ayahs: toggleInList(b.ayahs, key) }))} className={cn("focus-ring rounded-full p-2", saved ? "text-brand-ink" : "text-faint")}>
            <Bookmark size={16} fill={saved ? "currentColor" : "none"} />
          </button>
          <button type="button" aria-label="Share Ayah" onClick={share} className="focus-ring rounded-full p-2 text-faint">
            <Share2 size={16} />
          </button>
        </div>
      </div>
      <div className={cn(wide && showTranslation && "md:grid md:grid-cols-2 md:gap-5")}>
        <p lang="ar" dir="rtl" className="font-arabic text-ink" style={{ fontSize: `${26 * scale}px`, lineHeight: 2 }}>
          {arabic}
        </p>
        <div className={cn(wide ? "md:mt-0 mt-3" : "mt-3")}>
          {showTransliteration && ayah.transliteration && <p className="mb-2 text-[13px] italic leading-relaxed text-muted">{ayah.transliteration}</p>}
          {showTranslation && <p className="text-[15px] leading-relaxed text-ink/85">{ayah.translation}</p>}
        </div>
      </div>
    </li>
  );
});

function ReaderSettings({ open, onClose }: { open: boolean; onClose: () => void }) {
  const p = useStore(quranPrefsStore);
  return (
    <Sheet open={open} onClose={onClose} title="Reading settings">
      <label className="text-sm font-medium" htmlFor="arabic-size">
        Arabic text size
      </label>
      <div className="mt-1 flex items-center gap-3">
        <span className="font-arabic text-base">ا</span>
        <input id="arabic-size" type="range" min={0.8} max={1.7} step={0.05} value={p.arabicScale} onChange={(e) => quranPrefsStore.set({ arabicScale: Number(e.target.value) })} className="flex-1" />
        <span className="font-arabic text-3xl">ا</span>
      </div>
      <p lang="ar" dir="rtl" className="font-arabic mt-2 rounded-2xl bg-card-2 p-3 text-center" style={{ fontSize: `${26 * p.arabicScale}px`, lineHeight: 1.9 }}>
        ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ
      </p>

      <div className="mt-5 flex items-center justify-between">
        <p className="text-sm font-medium">Show translation</p>
        <Toggle checked={p.showTranslation} onChange={(v) => quranPrefsStore.set({ showTranslation: v })} label="Show translation" />
      </div>
      <div className="mt-3 flex items-center justify-between">
        <p className="text-sm font-medium">Show transliteration</p>
        <Toggle checked={p.showTransliteration} onChange={(v) => quranPrefsStore.set({ showTransliteration: v })} label="Show transliteration" />
      </div>
      <div className="mt-3 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">Side-by-side on wide screens</p>
          <p className="text-xs text-faint">Arabic beside translation on tablets/desktop</p>
        </div>
        <Toggle checked={p.sideBySide} onChange={(v) => quranPrefsStore.set({ sideBySide: v })} label="Side by side layout" />
      </div>

      <h3 className="mt-6 text-xs font-medium uppercase tracking-[0.14em] text-faint">Translation</h3>
      <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto">
        {TRANSLATIONS.map((t) => (
          <Chip key={t.id} active={p.translationEdition === t.id} onClick={() => quranPrefsStore.set({ translationEdition: t.id })}>
            {t.name}
          </Chip>
        ))}
      </div>

      <h3 className="mt-6 text-xs font-medium uppercase tracking-[0.14em] text-faint">Reciter</h3>
      <div className="mt-2 space-y-1.5">
        {RECITERS.map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => {
              quranPrefsStore.set({ reciter: r.id });
              audioController.setReciter(r.id);
            }}
            aria-pressed={p.reciter === r.id}
            className={cn("press focus-ring flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm hairline", p.reciter === r.id ? "bg-brand-soft text-brand-ink" : "bg-card-2")}
          >
            {r.name}
            <AnimatePresence>{p.reciter === r.id && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="h-2 w-2 rounded-full bg-brand" />}</AnimatePresence>
          </button>
        ))}
      </div>
      <p className="mt-3 flex items-center gap-1 text-[11px] text-faint">
        <Settings2 size={12} /> Audio streams from the Islamic Network CDN and supports lock-screen controls where available.
      </p>
    </Sheet>
  );
}
