import { motion } from "framer-motion";
import { Bookmark, Search, X } from "lucide-react";
import { useDeferredValue, useEffect, useMemo, useState } from "react";
import { EmptyState, ErrorState, ScreenHeader, Skeleton } from "../../components/ui";
import { fadeUp, staggerContainer } from "../../core/motion";
import { useStore } from "../../core/store";
import { describeError } from "../../services/http";
import { getSurahList, type SurahMeta } from "../../services/quranApi";
import { bookmarksStore } from "../../state/stores";
import { cn } from "../../utils/cn";

export function SurahList({ onOpen }: { onOpen: (n: number) => void }) {
  const [list, setList] = useState<SurahMeta[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const deferred = useDeferredValue(query);
  const [retry, setRetry] = useState(0);
  const lastRead = useStore(bookmarksStore, (b) => b.lastRead);
  const bookmarkedAyahs = useStore(bookmarksStore, (b) => b.ayahs);
  const bookmarkedSurahs = useMemo(() => new Set(bookmarkedAyahs.map((k) => Number(k.split(":")[0]))), [bookmarkedAyahs]);

  useEffect(() => {
    const ctrl = new AbortController();
    setError(null);
    getSurahList(ctrl.signal)
      .then((r) => setList(r.list))
      .catch((e) => !ctrl.signal.aborted && setError(describeError(e)));
    return () => ctrl.abort();
  }, [retry]);

  const filtered = useMemo(() => {
    if (!list) return [];
    const q = deferred.trim().toLowerCase();
    if (!q) return list;
    const n = Number(q);
    return list.filter(
      (s) =>
        s.number === n ||
        s.englishName.toLowerCase().includes(q) ||
        s.englishNameTranslation.toLowerCase().includes(q) ||
        s.name.includes(q) ||
        s.englishName.toLowerCase().replace(/[-'ʿ]/g, "").includes(q.replace(/[-'ʿ]/g, "")),
    );
  }, [list, deferred]);

  return (
    <div className="mx-auto max-w-xl pb-28">
      <ScreenHeader title="The Holy Quran" subtitle="114 Surahs" />
      <div className="px-4">
        <label className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 hairline">
          <Search size={16} className="text-faint" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or number"
            aria-label="Search Surahs"
            className="w-full bg-transparent text-sm outline-none placeholder:text-faint"
          />
          {query && (
            <button type="button" aria-label="Clear search" onClick={() => setQuery("")} className="text-faint">
              <X size={16} />
            </button>
          )}
        </label>

        {lastRead && !query && list && (
          <button
            type="button"
            onClick={() => onOpen(lastRead.surah)}
            className="press focus-ring mt-3 flex w-full items-center justify-between rounded-2xl bg-brand-soft px-4 py-3 text-left"
          >
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-brand-ink">Continue reading</p>
              <p className="text-sm font-medium">
                {list[lastRead.surah - 1]?.englishName} · Ayah {lastRead.ayah}
              </p>
            </div>
            <span className="font-arabic text-xl text-brand-ink">{list[lastRead.surah - 1]?.name}</span>
          </button>
        )}
      </div>

      <div className="mt-3 px-4">
        {error && !list && <ErrorState message={error} onRetry={() => setRetry((r) => r + 1)} />}
        {!list && !error && (
          <div className="space-y-2" aria-busy>
            {Array.from({ length: 10 }).map((_, i) => (
              <Skeleton key={i} className="h-[68px] w-full rounded-2xl" />
            ))}
          </div>
        )}
        {list && filtered.length === 0 && <EmptyState title="No Surah matches" hint="Try the English name, Arabic name, or Surah number." />}
        {list && filtered.length > 0 && (
          <motion.ul variants={staggerContainer} initial="hidden" animate="show" className="space-y-2" key={deferred}>
            {filtered.map((s) => (
              <motion.li key={s.number} variants={fadeUp}>
                <button
                  type="button"
                  onClick={() => onOpen(s.number)}
                  className={cn("card press focus-ring flex w-full items-center gap-3 px-4 py-3 text-left", lastRead?.surah === s.number && "border-brand/30")}
                >
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-card-2 text-sm font-semibold text-brand-ink tabular-nums">
                    {s.number}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-sm font-semibold">{s.englishName}</span>
                      {bookmarkedSurahs.has(s.number) && <Bookmark size={12} className="shrink-0 text-brand-ink" fill="currentColor" />}
                    </span>
                    <span className="block truncate text-xs text-faint">
                      {s.englishNameTranslation} · {s.numberOfAyahs} Ayahs · {s.revelationType === "Meccan" ? "Makki" : "Madani"}
                    </span>
                  </span>
                  <span lang="ar" className="font-arabic text-[22px] leading-none text-ink/90">
                    {s.name}
                  </span>
                </button>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </div>
    </div>
  );
}
