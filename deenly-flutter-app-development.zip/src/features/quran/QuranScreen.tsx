import { AnimatePresence, motion } from "framer-motion";
import { useEffect } from "react";
import { screenVariants } from "../../core/motion";
import { SurahList } from "./SurahList";
import { SurahReader } from "./SurahReader";

/**
 * Quran tab: list ↔ reader. The selected Surah is owned by the parent so the
 * tab's navigation state survives switching tabs and the browser back button works.
 */
export function QuranScreen({ surah, onSelectSurah }: { surah: number | null; onSelectSurah: (n: number | null) => void }) {
  useEffect(() => {
    if (surah) window.scrollTo({ top: 0 });
  }, [surah]);

  return (
    <AnimatePresence mode="wait" initial={false}>
      {surah ? (
        <motion.div key={`reader-${surah}`} variants={screenVariants} initial="initial" animate="animate" exit="exit">
          <SurahReader number={surah} onBack={() => onSelectSurah(null)} onChangeSurah={(n) => onSelectSurah(n)} />
        </motion.div>
      ) : (
        <motion.div key="list" variants={screenVariants} initial="initial" animate="animate" exit="exit">
          <SurahList onOpen={(n) => onSelectSurah(n)} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
