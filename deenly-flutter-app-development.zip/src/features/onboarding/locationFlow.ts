import { fetchTimingsByCity } from "../../services/aladhan";
import { getDeviceLocation, GeoError, type Coords } from "../../services/geolocation";
import { isValidCoordinate } from "../../services/geoData";
import type { ManualPlace } from "./onboardingStore";

export type PermissionState = "granted" | "prompt" | "denied" | "unsupported" | "unknown";

/** Reads the current geolocation permission without prompting (where the Permissions API exists). */
export async function queryLocationPermission(): Promise<PermissionState> {
  if (typeof navigator === "undefined" || !navigator.geolocation) return "unsupported";
  try {
    if (!navigator.permissions?.query) return "unknown";
    const res = await navigator.permissions.query({ name: "geolocation" });
    return res.state as PermissionState;
  } catch {
    return "unknown";
  }
}

export type DeviceLocationResult =
  | { ok: true; coords: Coords }
  | { ok: false; reason: "denied" | "blocked" | "unavailable" | "timeout" | "unsupported" | "invalid" };

/**
 * Runs the real OS/browser permission prompt (foreground, coarse accuracy is sufficient)
 * and validates the returned fix. `blocked` means the permission was already denied before
 * this call, so the browser will not show a prompt again — the UI routes to site settings.
 */
export async function requestDeviceLocation(): Promise<DeviceLocationResult> {
  const pre = await queryLocationPermission();
  if (pre === "unsupported") return { ok: false, reason: "unsupported" };
  if (pre === "denied") return { ok: false, reason: "blocked" };
  try {
    const coords = await getDeviceLocation(20_000);
    if (!isValidCoordinate(coords.lat, coords.lng)) return { ok: false, reason: "invalid" };
    return { ok: true, coords };
  } catch (e) {
    if (e instanceof GeoError) {
      if (e.kind === "denied") return { ok: false, reason: pre === "prompt" || pre === "unknown" ? "denied" : "blocked" };
      if (e.kind === "timeout") return { ok: false, reason: "timeout" };
      if (e.kind === "unsupported") return { ok: false, reason: "unsupported" };
    }
    return { ok: false, reason: "unavailable" };
  }
}

/**
 * Online fallback for cities missing from the bundled dataset. Uses the existing AlAdhan
 * `timingsByCity` integration, which returns the resolved coordinates in its metadata.
 * Only the city name and country are sent.
 */
export async function resolveCityOnline(city: string, countryName: string, countryCode: string, method: number, signal?: AbortSignal): Promise<ManualPlace> {
  const res = await fetchTimingsByCity(city.trim(), countryName, method, new Date(), signal);
  if (!isValidCoordinate(res.meta.lat, res.meta.lng)) throw new Error("Lookup returned invalid coordinates");
  return { countryCode, countryName, city: city.trim(), lat: res.meta.lat, lng: res.meta.lng, source: "online" };
}
