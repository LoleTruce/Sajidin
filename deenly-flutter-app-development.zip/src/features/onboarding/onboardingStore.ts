import { createStore, useStore } from "../../core/store";
import { locale, type LanguageCode } from "../../i18n";
import { defaultMethodForCountry } from "../../lib/calculationDefaults";
import type { Coords } from "../../services/geolocation";
import { isValidCoordinate } from "../../services/geoData";
import { quranPrefsStore, settingsStore } from "../../state/stores";
import { LANGUAGES } from "../../i18n/strings";

/* ------------------------------------------------------------------ */
/* First-launch flag                                                   */
/* ------------------------------------------------------------------ */

/** Stored as the string "true"/"false". Absent on a genuinely fresh installation. */
export const FIRST_LAUNCH_KEY = "deenly_isFirstLaunch";
const ONBOARDING_SCHEMA_KEY = "deenly_onboarding_schema";
const ONBOARDING_SCHEMA = 1;

export type LaunchState =
  | { kind: "first-launch" }
  | { kind: "completed" }
  /** Storage could not be read: do NOT assume setup is done; run onboarding and tell the user settings may not persist. */
  | { kind: "storage-error" };

interface Storage {
  getItem(k: string): string | null;
  setItem(k: string, v: string): void;
}

function storage(custom?: Storage): Storage | null {
  if (custom) return custom;
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null;
  }
}

/**
 * Decides whether to show onboarding. Synchronous so the root can be chosen before first paint.
 *
 * Migration: installs that pre-date the wizard have `deenly:settings.hasSeenWelcome === true`.
 * They are treated as completed (and the flag is written) so existing users are never re-onboarded.
 */
export function readLaunchState(custom?: Storage): LaunchState {
  const s = storage(custom);
  if (!s) return { kind: "storage-error" };
  try {
    const flag = s.getItem(FIRST_LAUNCH_KEY);
    if (flag === "false") return { kind: "completed" };
    if (flag === "true") return { kind: "first-launch" };
    // Never set → fresh install, unless this is a pre-wizard install.
    const legacy = s.getItem("deenly:settings");
    if (legacy) {
      try {
        const parsed = JSON.parse(legacy) as { hasSeenWelcome?: boolean };
        if (parsed?.hasSeenWelcome === true) {
          s.setItem(FIRST_LAUNCH_KEY, "false");
          s.setItem(ONBOARDING_SCHEMA_KEY, String(ONBOARDING_SCHEMA));
          return { kind: "completed" };
        }
      } catch {
        /* corrupt legacy settings → fall through to onboarding */
      }
    }
    return { kind: "first-launch" };
  } catch {
    return { kind: "storage-error" };
  }
}

/* ------------------------------------------------------------------ */
/* Wizard state                                                        */
/* ------------------------------------------------------------------ */

export type Step = 0 | 1 | 2;
export const STEP_COUNT = 3;

export interface ManualPlace {
  countryCode: string;
  countryName: string;
  city: string;
  lat: number;
  lng: number;
  /** "dataset" = bundled GeoNames; "online" = resolved via AlAdhan city lookup */
  source: "dataset" | "online";
}

export interface OnboardingState {
  step: Step;
  language: LanguageCode;
  /** Device-derived coordinates (if the user granted permission). */
  device: Coords | null;
  /** Manual selection (country/city). */
  manual: ManualPlace | null;
  /** Which of the two the user most recently chose. */
  locationMode: "device" | "manual" | "none";
  /** Country code used to pick a regional calculation default (device fixes have none → MWL). */
  countryCode: string | null;
  calculationMethod: number;
  methodTouched: boolean;
  completing: boolean;
  completeError: string | null;
}

export const onboardingStore = createStore<OnboardingState>({
  step: 0,
  language: locale.get(),
  device: null,
  manual: null,
  locationMode: "none",
  countryCode: null,
  calculationMethod: defaultMethodForCountry(null),
  methodTouched: false,
  completing: false,
  completeError: null,
});

export const onboarding = {
  goTo(step: number): void {
    const s = Math.max(0, Math.min(STEP_COUNT - 1, Math.round(step))) as Step;
    if (s !== onboardingStore.get().step) onboardingStore.set({ step: s });
  },
  next(): void {
    this.goTo(onboardingStore.get().step + 1);
  },
  back(): void {
    this.goTo(onboardingStore.get().step - 1);
  },

  /** Applies immediately so the wizard itself re-renders in the chosen language. */
  setLanguage(code: LanguageCode): void {
    onboardingStore.set({ language: code });
    locale.setLanguage(code);
  },

  setDeviceLocation(c: Coords): boolean {
    if (!isValidCoordinate(c.lat, c.lng)) return false;
    onboardingStore.set((s) => ({
      ...s,
      device: c,
      locationMode: "device",
      // A raw GPS fix carries no country; keep a previously chosen manual country for the method default.
      calculationMethod: s.methodTouched ? s.calculationMethod : defaultMethodForCountry(s.countryCode),
    }));
    return true;
  },

  setManualPlace(p: ManualPlace): boolean {
    if (!isValidCoordinate(p.lat, p.lng)) return false;
    onboardingStore.set((s) => ({
      ...s,
      manual: p,
      locationMode: "manual",
      countryCode: p.countryCode,
      calculationMethod: s.methodTouched ? s.calculationMethod : defaultMethodForCountry(p.countryCode),
    }));
    return true;
  },

  clearLocation(): void {
    onboardingStore.set({ device: null, manual: null, locationMode: "none" });
  },

  setCalculationMethod(id: number): void {
    onboardingStore.set({ calculationMethod: id, methodTouched: true });
  },

  /** The coordinates that will be saved, or null when the user proceeds without a location. */
  resolvedLocation(): Coords | null {
    const s = onboardingStore.get();
    if (s.locationMode === "device" && s.device) return s.device;
    if (s.locationMode === "manual" && s.manual) {
      return { lat: s.manual.lat, lng: s.manual.lng, label: `${s.manual.city}, ${s.manual.countryName}`, at: Date.now(), source: "manual" };
    }
    return null;
  },

  /**
   * Persists everything and only then marks onboarding complete.
   * Order: language → prayer/location settings → Quran edition → first-launch flag.
   * Any failure leaves the flag unset so the wizard runs again rather than losing setup.
   */
  async complete(opts: { allowNoLocation: boolean }, custom?: Storage): Promise<{ ok: true } | { ok: false; error: string }> {
    const s = onboardingStore.get();
    if (s.completing) return { ok: false, error: "A save is already in progress." };
    onboardingStore.set({ completing: true, completeError: null });
    try {
      const lang = LANGUAGES[s.language];
      if (!lang) throw new Error("Unsupported language selection.");
      const location = this.resolvedLocation();
      if (!location && !opts.allowNoLocation) throw new Error("Please choose a location or continue without one.");
      if (location && !isValidCoordinate(location.lat, location.lng)) throw new Error("The selected location has invalid coordinates.");

      // 1. Language (persisted by the locale module; failure means storage is unavailable).
      if (!locale.setLanguage(s.language)) throw new StorageUnavailable();

      // 2. Existing settings store (location + calculation method) — same store the Home/Qibla screens read.
      settingsStore.set((cur) => ({
        ...cur,
        location: location ?? cur.location,
        calculationMethod: location ? s.calculationMethod : cur.calculationMethod,
        hasSeenWelcome: true,
      }));

      // 3. The Quran reader's default translation follows the chosen language (changeable in reader settings).
      if (lang.quranEdition !== quranPrefsStore.get().translationEdition) {
        quranPrefsStore.set({ translationEdition: lang.quranEdition });
      }

      // 4. Verify the writes actually landed before flipping the flag.
      const st = storage(custom);
      if (!st) throw new StorageUnavailable();
      const roundTrip = st.getItem("deenly:settings");
      if (!roundTrip || !roundTrip.includes('"hasSeenWelcome":true')) throw new StorageUnavailable();

      try {
        st.setItem(FIRST_LAUNCH_KEY, "false");
        st.setItem(ONBOARDING_SCHEMA_KEY, String(ONBOARDING_SCHEMA));
      } catch {
        throw new StorageUnavailable(); // quota / private mode — never surface raw exceptions
      }
      if (st.getItem(FIRST_LAUNCH_KEY) !== "false") throw new StorageUnavailable();

      onboardingStore.set({ completing: false });
      return { ok: true };
    } catch (e) {
      const error = e instanceof StorageUnavailable ? locale.t("ob.loc.saveFailed") : e instanceof Error ? e.message : "Could not complete setup.";
      onboardingStore.set({ completing: false, completeError: error });
      return { ok: false, error };
    }
  },

  _resetForTests(): void {
    onboardingStore.set({
      step: 0,
      language: locale.get(),
      device: null,
      manual: null,
      locationMode: "none",
      countryCode: null,
      calculationMethod: defaultMethodForCountry(null),
      methodTouched: false,
      completing: false,
      completeError: null,
    });
  },
};

class StorageUnavailable extends Error {
  constructor() {
    super("storage-unavailable");
  }
}

export function useOnboarding(): OnboardingState {
  return useStore(onboardingStore);
}
