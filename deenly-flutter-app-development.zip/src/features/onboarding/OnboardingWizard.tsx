import { AnimatePresence, motion, useReducedMotion, type PanInfo } from "framer-motion";
import { ArrowLeft, ArrowRight, BookOpen, Check, ChevronDown, Compass, ExternalLink, Loader2, Lock, MapPin, Search, ShieldCheck } from "lucide-react";
import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { SajidinMark, PrimaryButton, Sheet } from "../../components/ui";
import { haptics } from "../../core/haptics";
import { useStore } from "../../core/store";
import { LANGUAGE_CODES, LANGUAGES, useT, type LanguageCode } from "../../i18n";
import { methodName } from "../../lib/calculationDefaults";
import { CALCULATION_METHODS } from "../../services/aladhan";
import { citiesFor, COUNTRIES, getCountry, guessCountryFromLocale, searchCities, searchCountries, type City, type Country } from "../../services/geoData";
import { describeError } from "../../services/http";
import { cn } from "../../utils/cn";
import { requestDeviceLocation, resolveCityOnline, type DeviceLocationResult } from "./locationFlow";
import { onboarding, onboardingStore, STEP_COUNT, type Step } from "./onboardingStore";

const EASE: [number, number, number, number] = [0.33, 1, 0.68, 1];
type DeviceFailure = Extract<DeviceLocationResult, { ok: false }>["reason"];

export function OnboardingWizard({ onComplete, storageWarning }: { onComplete: () => void; storageWarning?: boolean }) {
  const step = useStore(onboardingStore, (s) => s.step);
  const t = useT();
  const reduce = useReducedMotion();
  const dirRef = useRef<1 | -1>(1);
  const prevStep = useRef(step);
  if (step !== prevStep.current) {
    dirRef.current = step > prevStep.current ? 1 : -1;
    prevStep.current = step;
  }

  // Horizontal swipe between pages (disabled while a completion is in flight).
  const onDragEnd = useCallback((_: unknown, info: PanInfo) => {
    const { completing } = onboardingStore.get();
    if (completing) return;
    const rtl = document.documentElement.dir === "rtl";
    const dx = rtl ? -info.offset.x : info.offset.x;
    if (dx < -70 && Math.abs(info.velocity.x) > 50) onboarding.next();
    else if (dx > 70 && Math.abs(info.velocity.x) > 50) onboarding.back();
  }, []);

  const variants = {
    enter: (d: 1 | -1) => ({ x: reduce ? 0 : d * 40, opacity: 0 }),
    center: { x: 0, opacity: 1, transition: { duration: 0.3, ease: EASE } },
    exit: (d: 1 | -1) => ({ x: reduce ? 0 : d * -40, opacity: 0, transition: { duration: 0.2, ease: EASE } }),
  };

  return (
    <div className="mx-auto flex min-h-[100dvh] max-w-xl flex-col bg-bg text-ink" style={{ paddingTop: "var(--safe-top)", paddingBottom: "var(--safe-bottom)" }}>
      <div className="flex items-center justify-between px-5 pt-4" aria-live="polite">
        <ProgressDots step={step} />
        <span className="text-xs font-medium text-faint">{t("ob.step", { n: step + 1, total: STEP_COUNT })}</span>
      </div>

      {storageWarning && (
        <p role="alert" className="mx-5 mt-3 rounded-xl bg-warn-bg px-3 py-2 text-xs leading-relaxed text-warn-ink">
          {t("ob.loc.saveFailed")}
        </p>
      )}

      <div className="relative flex-1 overflow-hidden">
        <AnimatePresence mode="wait" custom={dirRef.current} initial={false}>
          <motion.section
            key={step}
            custom={dirRef.current}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            drag={step === 2 ? false : "x"}
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.12}
            onDragEnd={onDragEnd}
            className="absolute inset-0 overflow-y-auto no-scrollbar"
            aria-roledescription="onboarding step"
          >
            {step === 0 && <WelcomeStep />}
            {step === 1 && <LanguageStep />}
            {step === 2 && <LocationStep onComplete={onComplete} />}
          </motion.section>
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Progress                                                            */
/* ------------------------------------------------------------------ */

function ProgressDots({ step }: { step: Step }) {
  return (
    <div className="flex items-center gap-1.5" role="progressbar" aria-valuemin={1} aria-valuemax={STEP_COUNT} aria-valuenow={step + 1}>
      {Array.from({ length: STEP_COUNT }).map((_, i) => (
        <motion.span key={i} animate={{ width: i === step ? 22 : 7, opacity: i <= step ? 1 : 0.4 }} transition={{ duration: 0.3, ease: EASE }} className={cn("h-1.5 rounded-full", i <= step ? "bg-brand" : "bg-faint")} />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Step 1 — Welcome                                                    */
/* ------------------------------------------------------------------ */

function WelcomeStep() {
  const t = useT();
  return (
    <div className="flex min-h-full flex-col px-6 pb-8">
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.45, ease: EASE }}>
          <SajidinMark size={96} />
        </motion.div>
        <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.35, ease: EASE }} className="mt-7 text-[30px] font-semibold leading-tight tracking-tight">
          {t("ob.welcome.title")}
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18, duration: 0.35, ease: EASE }} className="mt-3 max-w-[30ch] text-[15px] leading-relaxed text-muted">
          {t("ob.welcome.body")}
        </motion.p>
        <motion.ul initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.26, duration: 0.35, ease: EASE }} className="mt-8 w-full max-w-xs space-y-2 text-start">
          <Point icon={<Compass size={16} />} text={t("ob.welcome.points.prayer")} />
          <Point icon={<BookOpen size={16} />} text={t("ob.welcome.points.quran")} />
          <Point icon={<Lock size={16} />} text={t("ob.welcome.points.private")} />
        </motion.ul>
      </div>
      <PrimaryButton className="w-full min-h-12 text-[15px]" onClick={() => onboarding.next()}>
        {t("ob.welcome.cta")} <ArrowRight size={18} className="rtl:-scale-x-100" />
      </PrimaryButton>
    </div>
  );
}

function Point({ icon, text }: { icon: ReactNode; text: string }) {
  return (
    <li className="flex items-center gap-3 rounded-2xl bg-card px-4 py-3 hairline">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-soft text-brand-ink">{icon}</span>
      <span className="text-sm font-medium">{text}</span>
    </li>
  );
}

/* ------------------------------------------------------------------ */
/* Step 2 — Language                                                   */
/* ------------------------------------------------------------------ */

function LanguageStep() {
  const t = useT();
  const selected = useStore(onboardingStore, (s) => s.language);
  const def = LANGUAGES[selected];
  return (
    <div className="flex min-h-full flex-col px-5 pb-8 pt-6">
      <h1 className="text-[26px] font-semibold tracking-tight">{t("ob.lang.title")}</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted">{t("ob.lang.body")}</p>

      <div role="radiogroup" aria-label={t("ob.lang.title")} className="mt-6 space-y-2">
        {LANGUAGE_CODES.map((code) => (
          <LanguageCard key={code} code={code} selected={code === selected} onSelect={() => onboarding.setLanguage(code)} />
        ))}
      </div>

      <p className="mt-4 text-xs leading-relaxed text-faint">
        {t("ob.lang.quran", { name: def.quranEditionName })} · {t("ob.lang.note")}
      </p>

      <div className="mt-auto flex gap-2 pt-8">
        <PrimaryButton variant="ghost" onClick={() => onboarding.back()} className="min-h-12 px-5">
          <ArrowLeft size={18} className="rtl:-scale-x-100" /> {t("common.back")}
        </PrimaryButton>
        <PrimaryButton onClick={() => onboarding.next()} className="min-h-12 flex-1 text-[15px]">
          {t("common.continue")} <ArrowRight size={18} className="rtl:-scale-x-100" />
        </PrimaryButton>
      </div>
    </div>
  );
}

function LanguageCard({ code, selected, onSelect }: { code: LanguageCode; selected: boolean; onSelect: () => void }) {
  const def = LANGUAGES[code];
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      aria-label={`${def.english} — ${def.native}`}
      onClick={() => {
        if (!selected) {
          haptics.light();
          onSelect();
        }
      }}
      className={cn("press focus-ring flex min-h-[60px] w-full items-center justify-between gap-3 rounded-2xl border bg-card px-4 py-3 text-start transition-colors duration-200", selected ? "border-brand bg-brand-soft" : "border-line")}
    >
      <span className="min-w-0">
        <span lang={code} dir={def.dir} className={cn("block text-base font-semibold", def.dir === "rtl" && "font-arabic text-lg leading-tight")}>
          {def.native}
        </span>
        {def.native !== def.english && <span className="block text-xs text-muted">{def.english}</span>}
      </span>
      <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-full border transition-colors", selected ? "border-brand bg-brand text-on-brand" : "border-line")} aria-hidden>
        {selected && <Check size={14} strokeWidth={3} />}
      </span>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Step 3 — Location                                                   */
/* ------------------------------------------------------------------ */

function LocationStep({ onComplete }: { onComplete: () => void }) {
  const t = useT();
  const st = useStore(onboardingStore);
  const [deviceState, setDeviceState] = useState<"idle" | "locating" | "done" | DeviceFailure>("idle");
  const [picker, setPicker] = useState<"none" | "country" | "city" | "method">("none");
  const [online, setOnline] = useState(() => (typeof navigator === "undefined" ? true : navigator.onLine));
  const busyRef = useRef(false);

  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);

  const enableDevice = async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setDeviceState("locating");
    const res = await requestDeviceLocation();
    busyRef.current = false;
    if (res.ok) {
      onboarding.setDeviceLocation(res.coords);
      haptics.success();
      setDeviceState("done");
    } else {
      setDeviceState(res.reason);
    }
  };

  const complete = async (allowNoLocation: boolean) => {
    if (st.completing) return;
    const r = await onboarding.complete({ allowNoLocation });
    if (r.ok) {
      haptics.success();
      onComplete();
    }
  };

  const country = st.manual ? getCountry(st.manual.countryCode) : st.countryCode ? getCountry(st.countryCode) : null;
  const hasLocation = st.locationMode !== "none" && onboarding.resolvedLocation() !== null;
  const deviceMessage = deviceState === "denied" ? t("ob.loc.denied") : deviceState === "blocked" ? t("ob.loc.blocked") : deviceState === "timeout" ? t("ob.loc.timeout") : deviceState === "unsupported" ? t("ob.loc.unsupported") : deviceState === "unavailable" || deviceState === "invalid" ? t("ob.loc.unavailable") : null;

  return (
    <div className="flex min-h-full flex-col px-5 pb-8 pt-6">
      <h1 className="text-[26px] font-semibold tracking-tight">{t("ob.loc.title")}</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted">{t("ob.loc.body")}</p>

      <div className="mt-3 flex items-start gap-2 rounded-2xl bg-card p-3 text-xs leading-relaxed text-muted hairline">
        <ShieldCheck size={16} className="mt-0.5 shrink-0 text-brand-ink" />
        <p>{t("ob.loc.privacy")}</p>
      </div>

      {/* Device location */}
      <div className="mt-5">
        {st.locationMode === "device" && st.device ? (
          <SelectedPlace label={t("ob.loc.granted")} detail={t("ob.loc.coords", { lat: st.device.lat.toFixed(3), lng: st.device.lng.toFixed(3) })} onChange={() => onboarding.clearLocation()} changeLabel={t("common.change")} />
        ) : (
          <PrimaryButton onClick={() => void enableDevice()} disabled={deviceState === "locating" || st.completing} className="w-full min-h-12 text-[15px]">
            {deviceState === "locating" ? <Loader2 size={18} className="animate-spin" /> : <MapPin size={18} />}
            {deviceState === "locating" ? t("ob.loc.locating") : t("ob.loc.enable")}
          </PrimaryButton>
        )}
        <AnimatePresence>
          {deviceMessage && st.locationMode !== "device" && (
            <motion.p key={deviceState} role="status" initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-2 rounded-xl bg-warn-bg px-3 py-2 text-xs leading-relaxed text-warn-ink">
              {deviceMessage}
              {deviceState === "blocked" && (
                <span className="mt-1 flex items-center gap-1 text-[11px] opacity-80">
                  <ExternalLink size={11} /> Browser › Site settings › Location
                </span>
              )}
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {/* Manual */}
      <div className="my-5 flex items-center gap-3 text-xs text-faint">
        <span className="h-px flex-1 bg-line" /> {t("ob.loc.or")} <span className="h-px flex-1 bg-line" />
      </div>
      <div className="space-y-2">
        <PickerField label={t("ob.loc.country")} value={country?.name ?? null} placeholder={t("ob.loc.countryPlaceholder")} onClick={() => setPicker("country")} />
        <PickerField label={t("ob.loc.city")} value={st.manual?.city ?? null} placeholder={t("ob.loc.cityPlaceholder")} onClick={() => setPicker("city")} disabled={!country} />
        {st.locationMode === "manual" && st.manual && (
          <p className="px-1 text-xs text-brand-ink">
            <Check size={12} className="mr-1 inline" />
            {t("ob.loc.selected", { place: `${st.manual.city}, ${st.manual.countryName}` })} · {t("ob.loc.coords", { lat: st.manual.lat.toFixed(3), lng: st.manual.lng.toFixed(3) })}
            {st.manual.source === "online" && " · online"}
          </p>
        )}
        {!online && <p className="px-1 text-xs text-faint">{t("ob.loc.offlineHint")}</p>}
      </div>

      {/* Calculation method */}
      {hasLocation && (
        <div className="mt-5">
          <PickerField label={t("ob.loc.method")} value={methodName(st.calculationMethod)} placeholder="" onClick={() => setPicker("method")} />
          <p className="mt-1 px-1 text-xs text-faint">{t("ob.loc.methodHint")}</p>
        </div>
      )}

      {st.completeError && (
        <p role="alert" className="mt-4 rounded-xl bg-danger-bg px-3 py-2 text-xs leading-relaxed text-danger-ink">
          {st.completeError}
        </p>
      )}

      {/* Actions */}
      <div className="mt-auto pt-8">
        <div className="flex gap-2">
          <PrimaryButton variant="ghost" onClick={() => onboarding.back()} disabled={st.completing} className="min-h-12 px-5">
            <ArrowLeft size={18} className="rtl:-scale-x-100" /> {t("common.back")}
          </PrimaryButton>
          <PrimaryButton onClick={() => void complete(false)} disabled={!hasLocation || st.completing} className="min-h-12 flex-1 text-[15px]">
            {st.completing ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />} {st.completing ? t("ob.loc.saving") : t("ob.loc.complete")}
          </PrimaryButton>
        </div>
        {!hasLocation && (
          <>
            <button type="button" onClick={() => void complete(true)} disabled={st.completing} className="focus-ring mx-auto mt-3 block rounded-full px-3 py-2 text-sm font-medium text-muted underline-offset-4 hover:underline disabled:opacity-40">
              {t("ob.loc.completeNoLocation")}
            </button>
            <p className="mt-1 text-center text-[11px] text-faint">{t("ob.loc.skipNote")}</p>
          </>
        )}
      </div>

      <CountryPicker open={picker === "country"} onClose={() => setPicker("none")} selected={country?.code ?? null} onSelect={(c) => {
        onboardingStore.set((s) => ({ ...s, countryCode: c.code, manual: null, locationMode: s.locationMode === "manual" ? "none" : s.locationMode }));
        setPicker("city");
      }} />
      {country && <CityPicker open={picker === "city"} onClose={() => setPicker("none")} country={country} method={st.calculationMethod} />}
      <MethodPicker open={picker === "method"} onClose={() => setPicker("none")} value={st.calculationMethod} onSelect={(id) => onboarding.setCalculationMethod(id)} />
    </div>
  );
}

function SelectedPlace({ label, detail, onChange, changeLabel }: { label: string; detail: string; onChange: () => void; changeLabel: string }) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="flex items-center gap-3 rounded-2xl border border-brand bg-brand-soft px-4 py-3" role="status">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brand text-on-brand">
        <Check size={18} strokeWidth={3} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold">{label}</span>
        <span className="block text-xs text-muted">{detail}</span>
      </span>
      <button type="button" onClick={onChange} className="focus-ring rounded-full px-2 py-1 text-xs font-semibold text-brand-ink">
        {changeLabel}
      </button>
    </motion.div>
  );
}

function PickerField({ label, value, placeholder, onClick, disabled }: { label: string; value: string | null; placeholder: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button type="button" onClick={onClick} disabled={disabled} aria-label={`${label}: ${value ?? placeholder}`} className="focus-ring press flex min-h-[56px] w-full items-center justify-between rounded-2xl bg-card px-4 py-2.5 text-start hairline disabled:opacity-40">
      <span className="min-w-0">
        <span className="block text-[11px] font-semibold uppercase tracking-[0.12em] text-faint">{label}</span>
        <span className={cn("block truncate text-sm", value ? "font-medium" : "text-faint")}>{value ?? placeholder}</span>
      </span>
      <ChevronDown size={18} className="shrink-0 text-faint" />
    </button>
  );
}

/* ---------- Country picker ---------- */
function CountryPicker({ open, onClose, selected, onSelect }: { open: boolean; onClose: () => void; selected: string | null; onSelect: (c: Country) => void }) {
  const t = useT();
  const [q, setQ] = useState("");
  const dq = useDeferredValue(q);
  const list = useMemo(() => searchCountries(dq), [dq]);
  const guess = useMemo(() => guessCountryFromLocale(), []);
  useEffect(() => {
    if (!open) setQ("");
  }, [open]);
  return (
    <Sheet open={open} onClose={onClose} title={t("ob.loc.country")}>
      <SearchBox value={q} onChange={setQ} placeholder={t("ob.loc.searchCountry")} />
      <ul className="mt-3 max-h-[55dvh] space-y-1 overflow-y-auto no-scrollbar" role="listbox" aria-label={t("ob.loc.country")}>
        {(!dq && guess ? [getCountry(guess)!, ...list.filter((c) => c.code !== guess)] : list).map((c) => (
          <li key={c.code}>
            <button type="button" role="option" aria-selected={c.code === selected} onClick={() => onSelect(c)} className={cn("focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-start text-sm", c.code === selected ? "bg-brand-soft text-brand-ink font-semibold" : "hover:bg-card-2")}>
              <span>
                {c.name}
                {c.code === guess && !dq && <span className="ml-2 rounded-full bg-card-2 px-1.5 py-0.5 text-[10px] text-faint">{c.code}</span>}
              </span>
              <span className="text-xs text-faint">{citiesFor(c.code).length || "—"}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-[11px] text-faint">{COUNTRIES.length} countries · GeoNames (CC BY 4.0)</p>
    </Sheet>
  );
}

/* ---------- City picker ---------- */
function CityPicker({ open, onClose, country, method }: { open: boolean; onClose: () => void; country: Country; method: number }) {
  const t = useT();
  const [q, setQ] = useState("");
  const dq = useDeferredValue(q);
  const [lookup, setLookup] = useState<"idle" | "busy" | "failed">("idle");
  const [lookupMsg, setLookupMsg] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const list = useMemo(() => searchCities(country.code, dq), [country.code, dq]);
  useEffect(() => {
    if (!open) {
      setQ("");
      setLookup("idle");
      setLookupMsg(null);
      abortRef.current?.abort();
    }
  }, [open]);

  const choose = (c: City) => {
    onboarding.setManualPlace({ countryCode: c.country, countryName: country.name, city: c.name, lat: c.lat, lng: c.lng, source: "dataset" });
    haptics.light();
    onClose();
  };

  const lookupOnline = async () => {
    if (lookup === "busy" || !q.trim()) return;
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLookup("busy");
    setLookupMsg(null);
    try {
      const place = await resolveCityOnline(q, country.name, country.code, method, ctrl.signal);
      if (ctrl.signal.aborted) return;
      onboarding.setManualPlace(place);
      setLookup("idle");
      onClose();
    } catch (e) {
      if (ctrl.signal.aborted) return;
      setLookup("failed");
      setLookupMsg(typeof navigator !== "undefined" && !navigator.onLine ? t("ob.loc.offlineHint") : `${t("ob.loc.lookupFailed")} (${describeError(e)})`);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title={`${t("ob.loc.city")} · ${country.name}`}>
      <SearchBox value={q} onChange={setQ} placeholder={t("ob.loc.searchCity")} />
      {list.length > 0 ? (
        <ul className="mt-3 max-h-[50dvh] space-y-1 overflow-y-auto no-scrollbar" role="listbox" aria-label={t("ob.loc.city")}>
          {list.slice(0, 200).map((c) => (
            <li key={`${c.name}-${c.lat}-${c.lng}`}>
              <button type="button" role="option" aria-selected={false} onClick={() => choose(c)} className="focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-start text-sm hover:bg-card-2">
                <span>
                  {c.name}
                  {c.capital && <span className="ml-2 rounded-full bg-brand-soft px-1.5 py-0.5 text-[10px] font-semibold text-brand-ink">★</span>}
                </span>
                <span className="text-xs tabular-nums text-faint">{c.popK >= 1000 ? `${(c.popK / 1000).toFixed(1)}M` : `${c.popK}k`}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-4 text-sm text-muted">{t("ob.loc.noCities")}</p>
      )}
      {q.trim().length >= 2 && (
        <div className="mt-3">
          <PrimaryButton variant="ghost" onClick={() => void lookupOnline()} disabled={lookup === "busy"} className="w-full">
            {lookup === "busy" ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />} {lookup === "busy" ? t("ob.loc.lookingUp") : t("ob.loc.lookupOnline", { city: q.trim() })}
          </PrimaryButton>
          {lookupMsg && (
            <p role="alert" className="mt-2 rounded-xl bg-danger-bg px-3 py-2 text-xs text-danger-ink">
              {lookupMsg}
            </p>
          )}
        </div>
      )}
    </Sheet>
  );
}

/* ---------- Method picker ---------- */
function MethodPicker({ open, onClose, value, onSelect }: { open: boolean; onClose: () => void; value: number; onSelect: (id: number) => void }) {
  const t = useT();
  return (
    <Sheet open={open} onClose={onClose} title={t("ob.loc.method")}>
      <ul className="space-y-1" role="listbox" aria-label={t("ob.loc.method")}>
        {CALCULATION_METHODS.map((m) => (
          <li key={m.id}>
            <button
              type="button"
              role="option"
              aria-selected={m.id === value}
              onClick={() => {
                onSelect(m.id);
                onClose();
              }}
              className={cn("focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-start text-sm", m.id === value ? "bg-brand-soft font-semibold text-brand-ink" : "hover:bg-card-2")}
            >
              {m.name}
              {m.id === value && <Check size={16} />}
            </button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <label className="flex items-center gap-2 rounded-2xl bg-card-2 px-4 py-3 hairline">
      <Search size={16} className="text-faint" />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder} autoFocus className="w-full bg-transparent text-sm outline-none placeholder:text-faint" />
    </label>
  );
}
