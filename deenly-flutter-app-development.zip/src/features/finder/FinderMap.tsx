import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { memo, useEffect, useMemo, useRef } from "react";
import { MapContainer, Marker, TileLayer, useMap } from "react-leaflet";
import type { NearbyPlace, PlaceCategory } from "./nearbyPlace";
import { displayName } from "./nearbyPlace";

/**
 * Tile provider: CARTO "Dark Matter" raster basemap (OSM data), served over HTTPS from CARTO's CDN.
 * CARTO's basemap terms permit free use for non-commercial projects with attribution; Sajidin is a
 * free, non-profit app. Attribution (OSM + CARTO) is rendered on the map. Tile requests contain the
 * tile x/y/z (i.e. the map area being viewed) and are sent directly from the device to CARTO.
 * The standard OSM tile layer is used as a fallback only if CARTO fails to load.
 */
export const CARTO_DARK_URL = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
export const OSM_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
export const ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions" target="_blank" rel="noreferrer">CARTO</a>';

const MOSQUE = "#00B388";
const HALAL = "#D4AF37";

function pinIcon(category: PlaceCategory, selected: boolean): L.DivIcon {
  const color = category === "mosque" ? MOSQUE : HALAL;
  const size = selected ? 40 : 30;
  const glyph = category === "mosque" ? mosqueGlyph : foodGlyph;
  return L.divIcon({
    className: "deenly-pin",
    iconSize: [size, size * 1.25],
    iconAnchor: [size / 2, size * 1.25],
    html: `<svg width="${size}" height="${size * 1.25}" viewBox="0 0 32 40" aria-hidden="true" style="filter: drop-shadow(0 3px 4px rgba(0,0,0,.45))">
      <path d="M16 39C16 39 2 24.5 2 14.5A14 14 0 0 1 30 14.5C30 24.5 16 39 16 39Z" fill="${color}" stroke="${selected ? "#ffffff" : "rgba(0,0,0,.35)"}" stroke-width="${selected ? 2.5 : 1}"/>
      <g transform="translate(8 6.5)" fill="${category === "mosque" ? "#06231C" : "#2B2208"}">${glyph}</g>
    </svg>`,
  });
}

const mosqueGlyph = `<path d="M8 1.2c.4 1.4 1.4 2.4 2.9 3.2A5.3 5.3 0 0 1 13 8.8H3a5.3 5.3 0 0 1 2.1-4.4C6.6 3.6 7.6 2.6 8 1.2Z"/><rect x="2" y="9.6" width="12" height="5.2" rx="1"/><rect x="0.4" y="6" width="1.6" height="8.8" rx=".8"/><rect x="14" y="6" width="1.6" height="8.8" rx=".8"/><rect x="7" y="11" width="2" height="3.8" fill="${MOSQUE}"/>`;
const foodGlyph = `<rect x="1.5" y="3" width="13" height="3.4" rx="1.7"/><rect x="1.5" y="7.6" width="13" height="2" rx="1"/><rect x="1.5" y="10.8" width="13" height="3.4" rx="1.7"/>`;

const originIcon = L.divIcon({
  className: "deenly-origin",
  iconSize: [20, 20],
  iconAnchor: [10, 10],
  html: `<span style="display:block;width:20px;height:20px;border-radius:50%;background:#2F8CFF;border:3px solid #fff;box-shadow:0 0 0 6px rgba(47,140,255,.25)"></span>`,
});

export interface FinderMapProps {
  origin: { lat: number; lng: number } | null;
  places: NearbyPlace[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  /** Incremented by the parent to request a recenter on the origin. */
  recenterToken: number;
  /** Extra bottom padding (px) so a selected marker is not hidden behind the detail card. */
  bottomPadding: number;
}

export const FinderMap = memo(function FinderMap({ origin, places, selectedId, onSelect, recenterToken, bottomPadding }: FinderMapProps) {
  const center = useMemo<[number, number]>(() => (origin ? [origin.lat, origin.lng] : [21.4225, 39.8262]), [origin]);
  return (
    <MapContainer center={center} zoom={origin ? 14 : 3} className="h-full w-full" zoomControl={false} attributionControl preferCanvas={false}>
      <TilesWithFallback />
      <Viewport origin={origin} places={places} selectedId={selectedId} recenterToken={recenterToken} bottomPadding={bottomPadding} />
      <ClickToDismiss onSelect={onSelect} />
      {origin && <Marker position={[origin.lat, origin.lng]} icon={originIcon} interactive={false} keyboard={false} zIndexOffset={-100} />}
      {places.map((p) => (
        <Marker
          key={p.id}
          position={[p.lat, p.lng]}
          icon={pinIcon(p.category, p.id === selectedId)}
          zIndexOffset={p.id === selectedId ? 1000 : 0}
          title={displayName(p)}
          alt={`${displayName(p)} marker`}
          eventHandlers={{ click: () => onSelect(p.id) }}
        />
      ))}
    </MapContainer>
  );
});

/** CARTO dark tiles; swaps to the standard OSM layer if CARTO errors repeatedly. */
function TilesWithFallback() {
  const errors = useRef(0);
  const swapped = useRef(false);
  const map = useMap();
  return (
    <TileLayer
      url={CARTO_DARK_URL}
      attribution={ATTRIBUTION}
      subdomains="abcd"
      maxZoom={19}
      crossOrigin
      eventHandlers={{
        tileerror: () => {
          if (swapped.current || ++errors.current < 6) return;
          swapped.current = true;
          map.eachLayer((l) => l instanceof L.TileLayer && map.removeLayer(l));
          L.tileLayer(OSM_URL, { attribution: ATTRIBUTION, maxZoom: 19, className: "deenly-osm-fallback" }).addTo(map);
        },
      }}
    />
  );
}

function Viewport({ origin, places, selectedId, recenterToken, bottomPadding }: Omit<FinderMapProps, "onSelect">) {
  const map = useMap();
  const lastOrigin = useRef<string | null>(null);
  const lastFit = useRef<string | null>(null);

  // New origin → centre on it; fit results the first time they arrive for this origin.
  useEffect(() => {
    if (!origin) return;
    const key = `${origin.lat},${origin.lng}`;
    if (lastOrigin.current !== key) {
      lastOrigin.current = key;
      lastFit.current = null;
      map.setView([origin.lat, origin.lng], 14, { animate: true });
    }
  }, [origin, map]);

  useEffect(() => {
    if (!origin || places.length === 0) return;
    const key = `${lastOrigin.current}:${places[0].category}:${places.length}`;
    if (lastFit.current === key) return;
    lastFit.current = key;
    const bounds = L.latLngBounds([[origin.lat, origin.lng], ...places.map((p) => [p.lat, p.lng] as [number, number])]);
    map.fitBounds(bounds, { padding: [48, 48], maxZoom: 15, animate: true });
  }, [origin, places, map]);

  // Explicit recenter requests.
  const seen = useRef(recenterToken);
  useEffect(() => {
    if (!origin || seen.current === recenterToken) return;
    seen.current = recenterToken;
    map.flyTo([origin.lat, origin.lng], Math.max(map.getZoom(), 14), { duration: 0.6 });
  }, [recenterToken, origin, map]);

  // Keep a selected marker visible above the detail card.
  useEffect(() => {
    if (!selectedId) return;
    const p = places.find((x) => x.id === selectedId);
    if (!p) return;
    const target = map.project([p.lat, p.lng], map.getZoom()).subtract([0, -bottomPadding / 2]);
    map.panTo(map.unproject(target, map.getZoom()), { animate: true, duration: 0.4 });
  }, [selectedId, places, map, bottomPadding]);

  // Leaflet needs a size recalculation once the flex layout has settled.
  useEffect(() => {
    const id = window.setTimeout(() => map.invalidateSize(), 50);
    const onResize = () => map.invalidateSize();
    window.addEventListener("resize", onResize);
    return () => {
      clearTimeout(id);
      window.removeEventListener("resize", onResize);
    };
  }, [map]);
  return null;
}

function ClickToDismiss({ onSelect }: { onSelect: (id: string | null) => void }) {
  const map = useMap();
  useEffect(() => {
    const handler = () => onSelect(null);
    map.on("click", handler);
    return () => {
      map.off("click", handler);
    };
  }, [map, onSelect]);
  return null;
}
