import { isValidCoordinate } from "../../services/geoData";
import { HttpError } from "../../services/http";
import { distanceMeters, SEARCH_RADIUS_M, type NearbyPlace, type PlaceCategory } from "./nearbyPlace";

/**
 * Overpass API client for nearby mosques / halal venues.
 *
 * Privacy: requests go straight from the device to the public Overpass instance (HTTPS), carrying
 * only the query (coordinates + radius + tags). No identifiers, tokens or device metadata are sent,
 * and nothing is relayed through any Sajidin server. The Overpass operator can see the query.
 *
 * Endpoints: primary overpass-api.de, fallback overpass.kumi.systems — both documented public
 * instances. The fallback is used only when the primary fails with a network/5xx/429 error, once.
 */
export const OVERPASS_ENDPOINTS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"] as const;

const QUERY_TIMEOUT_S = 25;
const HTTP_TIMEOUT_MS = 30_000;

/** Builds the Overpass QL for a category. Exported for tests. */
export function buildOverpassQuery(category: PlaceCategory, lat: number, lng: number, radiusM = SEARCH_RADIUS_M): string {
  if (!isValidCoordinate(lat, lng)) throw new Error("Invalid coordinates");
  const r = Math.max(100, Math.min(20_000, Math.round(radiusM)));
  const around = `(around:${r},${lat.toFixed(6)},${lng.toFixed(6)})`;
  if (category === "mosque") {
    // OSM convention is religion=muslim; religion=islam is accepted too so neither tagging is missed.
    return `[out:json][timeout:${QUERY_TIMEOUT_S}];nwr["amenity"="place_of_worship"]["religion"~"^(muslim|islam)$"]${around};out center tags;`;
  }
  // Union of the three halal rules; Overpass de-duplicates identical elements, and we dedupe by id again.
  return `[out:json][timeout:${QUERY_TIMEOUT_S}];(nwr["diet:halal"="yes"]${around};nwr["cuisine"~"halal"]${around};nwr["name"~"[Hh]alal"]${around};);out center tags;`;
}

/* ---------- Parsing (external data = untrusted) ---------- */

interface OverpassElement {
  type: string;
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat?: number; lon?: number };
  tags?: Record<string, unknown>;
}

function str(tags: Record<string, unknown> | undefined, key: string, max = 200): string | undefined {
  const v = tags?.[key];
  if (typeof v !== "string") return undefined;
  // Text only: strip control chars; React renders strings as text so no HTML interpretation occurs.
  const clean = v.replace(/[\u0000-\u001f\u007f]/g, " ").trim();
  return clean ? clean.slice(0, max) : undefined;
}

function resolveCoords(el: OverpassElement): { lat: number; lng: number } | null {
  if (el.type === "node" && isValidCoordinate(el.lat, el.lon)) return { lat: el.lat as number, lng: el.lon as number };
  if ((el.type === "way" || el.type === "relation") && el.center && isValidCoordinate(el.center.lat, el.center.lon)) {
    return { lat: el.center.lat as number, lng: el.center.lon as number };
  }
  return null;
}

function buildAddress(tags: Record<string, unknown> | undefined): string | undefined {
  const num = str(tags, "addr:housenumber", 20);
  const street = str(tags, "addr:street", 100);
  const line = [num, street].filter(Boolean).join(" ");
  return line || undefined;
}

export function parseOverpassResponse(json: unknown, category: PlaceCategory, origin?: { lat: number; lng: number }, radiusM = SEARCH_RADIUS_M): NearbyPlace[] {
  if (!json || typeof json !== "object" || !Array.isArray((json as { elements?: unknown }).elements)) {
    throw new HttpError("Unexpected response from the places service", undefined, "parse");
  }
  const seen = new Set<string>();
  const out: NearbyPlace[] = [];
  for (const raw of (json as { elements: unknown[] }).elements) {
    if (!raw || typeof raw !== "object") continue;
    const el = raw as OverpassElement;
    if ((el.type !== "node" && el.type !== "way" && el.type !== "relation") || typeof el.id !== "number") continue;
    const id = `${el.type}/${el.id}`;
    if (seen.has(id)) continue;
    const coords = resolveCoords(el);
    if (!coords) continue;
    // Defensive: Overpass `around` is authoritative, but never show something outside the radius.
    if (origin && distanceMeters(origin.lat, origin.lng, coords.lat, coords.lng) > radiusM * 1.05) continue;
    const tags = el.tags && typeof el.tags === "object" ? (el.tags as Record<string, unknown>) : undefined;

    let halalEvidence: NearbyPlace["halalEvidence"];
    if (category === "halal") {
      if (str(tags, "diet:halal") === "yes") halalEvidence = "diet:halal";
      else if (/halal/i.test(str(tags, "cuisine") ?? "")) halalEvidence = "cuisine";
      else if (/halal/i.test(str(tags, "name") ?? "")) halalEvidence = "name";
      else continue; // Should not happen given the query; skip anything that doesn't actually match.
    }

    seen.add(id);
    out.push({
      id,
      osmType: el.type,
      osmId: el.id,
      category,
      name: str(tags, "name", 120),
      lat: coords.lat,
      lng: coords.lng,
      address: buildAddress(tags),
      locality: str(tags, "addr:city", 80) ?? str(tags, "addr:suburb", 80),
      openingHours: str(tags, "opening_hours", 200),
      website: safeUrl(str(tags, "website", 300) ?? str(tags, "contact:website", 300)),
      phone: str(tags, "phone", 40) ?? str(tags, "contact:phone", 40),
      subtype: category === "mosque" ? str(tags, "denomination", 40) : (str(tags, "amenity", 40) ?? str(tags, "shop", 40))?.replace(/_/g, " "),
      halalEvidence,
    });
  }
  return out;
}

function safeUrl(u?: string): string | undefined {
  if (!u) return undefined;
  try {
    const url = new URL(u.startsWith("http") ? u : `https://${u}`);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : undefined;
  } catch {
    return undefined;
  }
}

/* ---------- Fetching with endpoint fallback ---------- */

export interface FetchDeps {
  fetchImpl?: typeof fetch;
  endpoints?: readonly string[];
}

export async function fetchNearby(category: PlaceCategory, lat: number, lng: number, signal?: AbortSignal, deps: FetchDeps = {}): Promise<NearbyPlace[]> {
  const query = buildOverpassQuery(category, lat, lng);
  const fetchImpl = deps.fetchImpl ?? fetch;
  const endpoints = deps.endpoints ?? OVERPASS_ENDPOINTS;
  let lastError: unknown;
  for (let i = 0; i < endpoints.length; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new HttpError("Request timed out", undefined, "timeout")), HTTP_TIMEOUT_MS);
    const onAbort = () => controller.abort(new HttpError("Aborted", undefined, "aborted"));
    signal?.addEventListener("abort", onAbort, { once: true });
    try {
      const res = await fetchImpl(endpoints[i], {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
        body: `data=${encodeURIComponent(query)}`,
        signal: controller.signal,
        credentials: "omit",
        referrerPolicy: "no-referrer",
      });
      if (res.status === 429 || res.status === 504 || res.status >= 500) {
        lastError = new HttpError(res.status === 429 ? "The places service is busy (rate limited)" : `Places service error (${res.status})`, res.status, "http");
        continue; // try the fallback endpoint once
      }
      if (!res.ok) throw new HttpError(`Places service error (${res.status})`, res.status, "http");
      let json: unknown;
      try {
        json = await res.json();
      } catch {
        throw new HttpError("Could not read the places response", res.status, "parse");
      }
      return parseOverpassResponse(json, category, { lat, lng });
    } catch (e) {
      if (signal?.aborted) throw new HttpError("Aborted", undefined, "aborted");
      if (e instanceof HttpError && (e.kind === "parse" || (e.kind === "http" && e.status && e.status < 500 && e.status !== 429))) throw e;
      lastError = e instanceof HttpError ? e : new HttpError("Network request failed", undefined, "network");
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
    }
  }
  throw lastError instanceof HttpError ? lastError : new HttpError("Places service unavailable", undefined, "network");
}

/* ---------- Session cache (memory only; bounded; never persisted) ---------- */

interface CacheEntry {
  at: number;
  places: NearbyPlace[];
}
const CACHE_TTL_MS = 10 * 60_000;
const CACHE_MAX = 12;
const cache = new Map<string, CacheEntry>();

/** Cache key rounds the origin to ~110 m so tiny GPS jitter reuses results; never written to storage. */
export function cacheKey(category: PlaceCategory, lat: number, lng: number): string {
  return `${category}:${lat.toFixed(3)}:${lng.toFixed(3)}`;
}
export function getCached(category: PlaceCategory, lat: number, lng: number, now = Date.now()): NearbyPlace[] | null {
  const e = cache.get(cacheKey(category, lat, lng));
  if (!e) return null;
  if (now - e.at > CACHE_TTL_MS) {
    cache.delete(cacheKey(category, lat, lng));
    return null;
  }
  return e.places;
}
export function setCached(category: PlaceCategory, lat: number, lng: number, places: NearbyPlace[], now = Date.now()): void {
  const key = cacheKey(category, lat, lng);
  cache.delete(key);
  cache.set(key, { at: now, places });
  while (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value as string);
}
export function clearFinderCache(): void {
  cache.clear();
  routeCache.clear();
}
export function cacheSize(): number {
  return cache.size;
}

/* ---------- Walking route (OSRM public demo server) ---------- */

export interface WalkingRoute {
  distanceM: number;
  durationS: number;
}
const routeCache = new Map<string, WalkingRoute>();

/**
 * Pedestrian route length from the OSRM demo server (router.project-osrm.org, foot profile).
 * The request contains origin and destination coordinates and is sent directly from the device.
 * The demo server is community-run with no uptime guarantee; callers must fall back to the
 * straight-line distance when this fails. One request per selected venue, cached in memory.
 */
export async function fetchWalkingRoute(from: { lat: number; lng: number }, to: { lat: number; lng: number }, signal?: AbortSignal, fetchImpl: typeof fetch = fetch): Promise<WalkingRoute> {
  if (!isValidCoordinate(from.lat, from.lng) || !isValidCoordinate(to.lat, to.lng)) throw new Error("Invalid coordinates");
  const key = `${from.lat.toFixed(4)},${from.lng.toFixed(4)}>${to.lat.toFixed(5)},${to.lng.toFixed(5)}`;
  const hit = routeCache.get(key);
  if (hit) return hit;
  const url = `https://router.project-osrm.org/route/v1/foot/${from.lng.toFixed(6)},${from.lat.toFixed(6)};${to.lng.toFixed(6)},${to.lat.toFixed(6)}?overview=false&alternatives=false&steps=false`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);
  signal?.addEventListener("abort", () => controller.abort(), { once: true });
  try {
    const res = await fetchImpl(url, { signal: controller.signal, credentials: "omit", referrerPolicy: "no-referrer" });
    if (!res.ok) throw new Error(`Routing service error (${res.status})`);
    const json = (await res.json()) as { code?: string; routes?: { distance?: number; duration?: number }[] };
    const r = json.routes?.[0];
    if (json.code !== "Ok" || !r || !Number.isFinite(r.distance) || !Number.isFinite(r.duration)) throw new Error("No walking route");
    const route = { distanceM: r.distance as number, durationS: r.duration as number };
    if (routeCache.size > 50) routeCache.delete(routeCache.keys().next().value as string);
    routeCache.set(key, route);
    return route;
  } finally {
    clearTimeout(timer);
  }
}

/* ---------- Navigation URLs (external apps; coordinates only) ---------- */

export function navigationUrls(to: { lat: number; lng: number }, label?: string): { primary: string; apple: string; web: string; geo: string } {
  if (!isValidCoordinate(to.lat, to.lng)) throw new Error("Invalid coordinates");
  const ll = `${to.lat.toFixed(6)},${to.lng.toFixed(6)}`;
  const q = label ? encodeURIComponent(label.slice(0, 80)) : ll;
  return {
    // Google Maps universal directions URL: opens the app where installed, otherwise the website.
    primary: `https://www.google.com/maps/dir/?api=1&destination=${ll}&travelmode=driving`,
    apple: `https://maps.apple.com/?daddr=${ll}&dirflg=d&q=${q}`,
    web: `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=;${ll}#map=16/${ll.replace(",", "/")}`,
    geo: `geo:${ll}?q=${ll}(${q})`,
  };
}
