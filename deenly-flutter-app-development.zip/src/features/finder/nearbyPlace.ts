export type PlaceCategory = "mosque" | "halal";

/** A venue discovered via OpenStreetMap. All text fields are untrusted external data (rendered as text only). */
export interface NearbyPlace {
  /** Stable id: `${osmType}/${osmId}` */
  id: string;
  osmType: "node" | "way" | "relation";
  osmId: number;
  category: PlaceCategory;
  /** May be undefined — never invented. */
  name?: string;
  lat: number;
  lng: number;
  address?: string;
  locality?: string;
  openingHours?: string;
  website?: string;
  phone?: string;
  /** Mosque: denomination; Halal: amenity/cuisine summary */
  subtype?: string;
  /** Which halal rule matched (for honest labelling): tag vs name match */
  halalEvidence?: "diet:halal" | "cuisine" | "name";
}

export const SEARCH_RADIUS_M = 5000;

export function categoryLabel(c: PlaceCategory): string {
  return c === "mosque" ? "Mosque" : "Halal food";
}

/** Display name without fabricating one: falls back to a neutral category label. */
export function displayName(p: NearbyPlace): string {
  return p.name?.trim() || (p.category === "mosque" ? "Unnamed mosque" : "Unnamed halal venue");
}

/** Haversine distance in metres. */
export function distanceMeters(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6_371_000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function formatDistance(m: number): string {
  if (!Number.isFinite(m) || m < 0) return "—";
  if (m < 1000) return `${Math.round(m / 10) * 10} m`;
  return `${(m / 1000).toFixed(m < 10_000 ? 1 : 0)} km`;
}

export function formatDuration(seconds: number): string {
  const min = Math.round(seconds / 60);
  if (min < 1) return "< 1 min";
  if (min < 60) return `${min} min`;
  return `${Math.floor(min / 60)} h ${min % 60} min`;
}
