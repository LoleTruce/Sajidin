import { useCallback, useEffect, useRef, useState } from "react";
import { describeError } from "../../services/http";
import { isValidCoordinate } from "../../services/geoData";
import { requestDeviceLocation, type DeviceLocationResult } from "../onboarding/locationFlow";
import { fetchNearby, fetchWalkingRoute, getCached, setCached, type WalkingRoute } from "./halalFinderService";
import type { NearbyPlace, PlaceCategory } from "./nearbyPlace";

export interface Origin {
  lat: number;
  lng: number;
  label: string;
  source: "device" | "manual";
}

export type OriginStatus = "idle" | "locating" | "ready" | DeviceFailure;
type DeviceFailure = Extract<DeviceLocationResult, { ok: false }>["reason"];

export type ResultsStatus = "idle" | "loading" | "ready" | "error";

export interface FinderState {
  origin: Origin | null;
  originStatus: OriginStatus;
  category: PlaceCategory;
  places: NearbyPlace[];
  resultsStatus: ResultsStatus;
  resultsError: string | null;
  fromCache: boolean;
  selectedId: string | null;
  route: WalkingRoute | null;
  routeStatus: "idle" | "loading" | "ready" | "unavailable";
}

/**
 * All finder state lives in this hook for the lifetime of the screen. Nothing here is persisted:
 * the origin, results and selection are discarded when the user leaves the finder.
 */
export function useFinder(initialOrigin?: Origin | null) {
  const [state, setState] = useState<FinderState>({
    origin: initialOrigin ?? null,
    originStatus: initialOrigin ? "ready" : "idle",
    category: "mosque",
    places: [],
    resultsStatus: "idle",
    resultsError: null,
    fromCache: false,
    selectedId: null,
    route: null,
    routeStatus: "idle",
  });
  const searchSeq = useRef(0);
  const searchAbort = useRef<AbortController | null>(null);
  const routeAbort = useRef<AbortController | null>(null);
  const locatingRef = useRef(false);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      searchAbort.current?.abort();
      routeAbort.current?.abort();
    };
  }, []);

  const patch = useCallback((p: Partial<FinderState> | ((s: FinderState) => Partial<FinderState>)) => {
    if (!mounted.current) return;
    setState((s) => ({ ...s, ...(typeof p === "function" ? p(s) : p) }));
  }, []);

  /** Runs a search for `category` at `origin`; stale responses are ignored via a sequence number. */
  const search = useCallback(
    async (category: PlaceCategory, origin: Origin, force = false) => {
      if (!isValidCoordinate(origin.lat, origin.lng)) return;
      const cached = force ? null : getCached(category, origin.lat, origin.lng);
      if (cached) {
        patch({ places: cached, resultsStatus: "ready", resultsError: null, fromCache: true });
        return;
      }
      searchAbort.current?.abort();
      const ctrl = new AbortController();
      searchAbort.current = ctrl;
      const seq = ++searchSeq.current;
      patch({ resultsStatus: "loading", resultsError: null, fromCache: false });
      try {
        const places = await fetchNearby(category, origin.lat, origin.lng, ctrl.signal);
        if (seq !== searchSeq.current || ctrl.signal.aborted) return;
        setCached(category, origin.lat, origin.lng, places);
        patch({ places, resultsStatus: "ready", fromCache: false });
      } catch (e) {
        if (seq !== searchSeq.current || ctrl.signal.aborted) return;
        patch({ resultsStatus: "error", resultsError: describeError(e), places: [] });
      }
    },
    [patch],
  );

  const setOrigin = useCallback(
    (origin: Origin) => {
      patch({ origin, originStatus: "ready", selectedId: null, route: null, routeStatus: "idle" });
      void search(state.category, origin);
    },
    [patch, search, state.category],
  );

  const locate = useCallback(async () => {
    if (locatingRef.current) return;
    locatingRef.current = true;
    patch({ originStatus: "locating" });
    const res = await requestDeviceLocation();
    locatingRef.current = false;
    if (!mounted.current) return;
    if (res.ok) {
      setOrigin({ lat: res.coords.lat, lng: res.coords.lng, label: "Current location", source: "device" });
    } else {
      patch((s) => ({ originStatus: res.reason, origin: s.origin }));
    }
  }, [patch, setOrigin]);

  const setCategory = useCallback(
    (category: PlaceCategory) => {
      if (category === state.category) return;
      patch((s) => ({
        category,
        places: [],
        selectedId: null,
        route: null,
        routeStatus: "idle",
        resultsStatus: s.origin ? "loading" : "idle",
        resultsError: null,
      }));
      if (state.origin) void search(category, state.origin);
    },
    [patch, search, state.category, state.origin],
  );

  const retry = useCallback(() => {
    if (state.origin) void search(state.category, state.origin, true);
    else void locate();
  }, [locate, search, state.category, state.origin]);

  const select = useCallback(
    (id: string | null) => {
      routeAbort.current?.abort();
      patch({ selectedId: id, route: null, routeStatus: id ? "loading" : "idle" });
      if (!id || !state.origin) return;
      const place = state.places.find((p) => p.id === id);
      if (!place) return;
      const ctrl = new AbortController();
      routeAbort.current = ctrl;
      fetchWalkingRoute(state.origin, place, ctrl.signal)
        .then((route) => !ctrl.signal.aborted && patch({ route, routeStatus: "ready" }))
        .catch(() => !ctrl.signal.aborted && patch({ route: null, routeStatus: "unavailable" }));
    },
    [patch, state.origin, state.places],
  );

  return { state, locate, setOrigin, setCategory, retry, select };
}
