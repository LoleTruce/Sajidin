import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Clock, ExternalLink, Footprints, Globe, Info, Loader2, LocateFixed, MapPin, Navigation, Phone, RefreshCw, Search, Trash2, X } from "lucide-react";
import { lazy, Suspense, useCallback, useDeferredValue, useEffect, useMemo, useState } from "react";
import { PrimaryButton, Sheet, useToast } from "../../components/ui";
import { haptics } from "../../core/haptics";
import { useStore } from "../../core/store";
import { citiesFor, COUNTRIES, getCountry, guessCountryFromLocale, searchCities, searchCountries } from "../../services/geoData";
import { settingsStore } from "../../state/stores";
import { cn } from "../../utils/cn";
import { clearFinderCache, navigationUrls } from "./halalFinderService";
import { categoryLabel, displayName, distanceMeters, formatDistance, formatDuration, SEARCH_RADIUS_M, type NearbyPlace, type PlaceCategory } from "./nearbyPlace";
import { useFinder, type Origin } from "./useFinder";

const FinderMap = lazy(() => import("./FinderMap").then((m) => ({ default: m.FinderMap })));

const CARD_HEIGHT = 260;

export function HalalFinderView({ onBack }: { onBack: () => void }) {
  // Seed from the location the user already configured for prayer times (stored on-device by them).
  const saved = useStore(settingsStore, (s) => s.location);
  const seed: Origin | null = useMemo(() => (saved ? { lat: saved.lat, lng: saved.lng, label: saved.label ?? "Saved location", source: saved.source === "device" ? "device" : "manual" } : null), [saved]);
  const { state, locate, setOrigin, setCategory, retry, select } = useFinder(seed);
  const [recenter, setRecenter] = useState(0);
  const [manualOpen, setManualOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const toast = useToast();

  // First open: search the seeded origin, or ask for device location (explained in the overlay first).
  useEffect(() => {
    if (seed && state.resultsStatus === "idle") setOrigin(seed);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = state.selectedId ? state.places.find((p) => p.id === state.selectedId) ?? null : null;
  const onSelect = useCallback(
    (id: string | null) => {
      if (id) haptics.light();
      select(id);
    },
    [select],
  );

  const originFailure = state.originStatus !== "idle" && state.originStatus !== "locating" && state.originStatus !== "ready";

  return (
    <div className="relative mx-auto flex h-[100dvh] max-w-3xl flex-col bg-bg">
      {/* Header */}
      <header className="z-20 flex items-center gap-2 bg-bg/95 px-3 pb-2 backdrop-blur-xl" style={{ paddingTop: "calc(var(--safe-top) + 10px)" }}>
        <button type="button" onClick={onBack} aria-label="Back to Tools" className="focus-ring press grid h-10 w-10 place-items-center rounded-full text-ink">
          <ArrowLeft size={20} />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-base font-semibold">Halal Places & Masjid Finder</h1>
          <button type="button" onClick={() => setManualOpen(true)} className="focus-ring flex items-center gap-1 truncate text-xs text-muted">
            <MapPin size={11} className="shrink-0 text-brand-ink" />
            <span className="truncate">{state.origin ? `${state.origin.label} · ${SEARCH_RADIUS_M / 1000} km radius` : "No location set"}</span>
          </button>
        </div>
        <button type="button" onClick={() => setInfoOpen(true)} aria-label="Privacy and data sources" className="focus-ring grid h-10 w-10 place-items-center rounded-full text-muted">
          <Info size={18} />
        </button>
      </header>

      {/* Category selector */}
      <div className="z-20 px-4 pb-2">
        <div role="radiogroup" aria-label="Venue category" className="grid grid-cols-2 rounded-2xl bg-card p-1 hairline">
          {(["mosque", "halal"] as PlaceCategory[]).map((c) => {
            const active = state.category === c;
            return (
              <button key={c} type="button" role="radio" aria-checked={active} onClick={() => setCategory(c)} className={cn("focus-ring relative z-10 min-h-10 rounded-xl text-sm font-semibold transition-colors", active ? (c === "mosque" ? "text-[#06231C]" : "text-[#2B2208]") : "text-muted")}>
                {active && <motion.span layoutId="finder-pill" transition={{ type: "spring", stiffness: 420, damping: 34 }} className={cn("absolute inset-0 -z-10 rounded-xl", c === "mosque" ? "bg-[#00B388]" : "bg-[#D4AF37]")} />}
                <span aria-hidden className="mr-1.5">{c === "mosque" ? "🕌" : "🍔"}</span>
                {c === "mosque" ? "Mosques Only" : "Halal Food Only"}
              </button>
            );
          })}
        </div>
      </div>

      {/* Map */}
      <div className="relative flex-1 overflow-hidden">
        <Suspense fallback={<div className="grid h-full place-items-center text-muted"><Loader2 className="animate-spin" /></div>}>
          <FinderMap origin={state.origin} places={state.places} selectedId={state.selectedId} onSelect={onSelect} recenterToken={recenter} bottomPadding={selected ? CARD_HEIGHT : 0} />
        </Suspense>

        {/* Status chip */}
        <div className="pointer-events-none absolute inset-x-0 top-3 z-[500] flex justify-center px-4" aria-live="polite">
          <AnimatePresence mode="wait">
            {state.resultsStatus === "loading" && (
              <Chip key="loading"><Loader2 size={14} className="animate-spin" /> Searching {categoryLabel(state.category).toLowerCase()} within {SEARCH_RADIUS_M / 1000} km…</Chip>
            )}
            {state.resultsStatus === "ready" && (
              <Chip key={`ready-${state.places.length}`}>
                <span className={cn("h-2 w-2 rounded-full", state.category === "mosque" ? "bg-[#00B388]" : "bg-[#D4AF37]")} /> {state.places.length} {state.places.length === 1 ? "result" : "results"}
                {state.fromCache && <span className="text-faint"> · cached</span>}
              </Chip>
            )}
          </AnimatePresence>
        </div>

        {/* Recenter */}
        {state.origin && (
          <button type="button" aria-label="Recenter on my location" onClick={() => setRecenter((n) => n + 1)} className="focus-ring press absolute right-4 z-[500] grid h-12 w-12 place-items-center rounded-full bg-card text-ink shadow-soft hairline" style={{ bottom: selected ? CARD_HEIGHT + 16 : 16 }}>
            <LocateFixed size={20} />
          </button>
        )}

        {/* Overlays: no origin / errors / empty */}
        <AnimatePresence>
          {!state.origin && (
            <Overlay key="no-origin">
              <span className="grid h-12 w-12 place-items-center rounded-full bg-brand-soft text-brand-ink"><MapPin size={22} /></span>
              <h2 className="mt-3 text-base font-semibold">Find places near you</h2>
              <p className="mt-1 text-sm text-muted">Sajidin needs a location to search within {SEARCH_RADIUS_M / 1000} km. Your coordinates are sent only to OpenStreetMap's Overpass service for the search itself — never to Sajidin.</p>
              {originFailure && <p role="alert" className="mt-3 rounded-xl bg-warn-bg px-3 py-2 text-xs text-warn-ink">{originMessage(state.originStatus)}</p>}
              <PrimaryButton className="mt-4 w-full" onClick={() => void locate()} disabled={state.originStatus === "locating"}>
                {state.originStatus === "locating" ? <Loader2 size={16} className="animate-spin" /> : <LocateFixed size={16} />} {state.originStatus === "locating" ? "Finding your location…" : "Use my location"}
              </PrimaryButton>
              <PrimaryButton variant="ghost" className="mt-2 w-full" onClick={() => setManualOpen(true)}>
                <Search size={16} /> Choose a city instead
              </PrimaryButton>
            </Overlay>
          )}
          {state.origin && state.resultsStatus === "error" && (
            <Overlay key="error" compact>
              <p className="text-sm font-semibold">Couldn't load nearby places</p>
              <p className="mt-1 text-xs text-muted">{state.resultsError}</p>
              <div className="mt-3 flex gap-2">
                <PrimaryButton className="flex-1" onClick={retry}><RefreshCw size={14} /> Retry Search</PrimaryButton>
                <PrimaryButton variant="ghost" onClick={() => setManualOpen(true)}>Change Location</PrimaryButton>
              </div>
            </Overlay>
          )}
          {state.origin && state.resultsStatus === "ready" && state.places.length === 0 && (
            <Overlay key="empty" compact>
              <p className="text-sm font-semibold">No {categoryLabel(state.category).toLowerCase()} venues found within {SEARCH_RADIUS_M / 1000} km</p>
              <p className="mt-1 text-xs text-muted">OpenStreetMap may not have {state.category === "mosque" ? "mosques" : "halal venues"} mapped here yet{state.category === "halal" ? " — many halal restaurants aren't tagged as such" : ""}.</p>
              <div className="mt-3 flex gap-2">
                <PrimaryButton className="flex-1" onClick={retry}><RefreshCw size={14} /> Retry Search</PrimaryButton>
                <PrimaryButton variant="ghost" onClick={() => setManualOpen(true)}>Change Location</PrimaryButton>
              </div>
            </Overlay>
          )}
        </AnimatePresence>

        {/* Detail card */}
        <AnimatePresence>
          {selected && state.origin && (
            <PlaceCard key={selected.id} place={selected} origin={state.origin} route={state.route} routeStatus={state.routeStatus} onClose={() => select(null)} onNavigateFail={() => toast("Couldn't open a maps app", "error")} />
          )}
        </AnimatePresence>
      </div>

      <ManualLocationSheet open={manualOpen} onClose={() => setManualOpen(false)} onPick={(o) => { setOrigin(o); setManualOpen(false); }} onUseDevice={() => { setManualOpen(false); void locate(); }} />
      <PrivacySheet open={infoOpen} onClose={() => setInfoOpen(false)} onClearCache={() => { clearFinderCache(); toast("Cached results cleared", "success"); }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */

function originMessage(s: ReturnType<typeof useFinder>["state"]["originStatus"]): string {
  switch (s) {
    case "denied":
      return "Location permission was denied. You can still search by choosing a city.";
    case "blocked":
      return "Location is blocked for this site. Allow it in your browser's site settings, or choose a city.";
    case "timeout":
      return "Finding your location took too long. Try again or choose a city.";
    case "unsupported":
      return "This browser doesn't support device location. Choose a city instead.";
    default:
      return "Your location isn't available right now. Try again or choose a city.";
  }
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }} className="flex items-center gap-2 rounded-full bg-card/95 px-3.5 py-1.5 text-xs font-medium text-ink shadow-soft backdrop-blur hairline">
      {children}
    </motion.div>
  );
}

function Overlay({ children, compact }: { children: React.ReactNode; compact?: boolean }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className={cn("absolute inset-x-0 z-[600] flex justify-center px-4", compact ? "bottom-20" : "inset-y-0 items-center bg-bg/70 backdrop-blur-sm")}>
      <div className="w-full max-w-sm rounded-3xl bg-card p-5 text-center shadow-soft hairline">{children}</div>
    </motion.div>
  );
}

/* ---------- Detail card ---------- */
function PlaceCard({ place, origin, route, routeStatus, onClose, onNavigateFail }: { place: NearbyPlace; origin: Origin; route: { distanceM: number; durationS: number } | null; routeStatus: string; onClose: () => void; onNavigateFail: () => void }) {
  const straight = distanceMeters(origin.lat, origin.lng, place.lat, place.lng);
  const urls = navigationUrls(place, place.name);
  const isApple = typeof navigator !== "undefined" && /iPhone|iPad|Macintosh/.test(navigator.userAgent);
  const open = (url: string) => {
    try {
      const w = window.open(url, "_blank", "noopener,noreferrer");
      if (!w) onNavigateFail();
    } catch {
      onNavigateFail();
    }
  };
  return (
    <motion.section
      initial={{ y: "110%" }}
      animate={{ y: 0 }}
      exit={{ y: "110%" }}
      transition={{ type: "spring", stiffness: 380, damping: 36 }}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: 0, bottom: 0.4 }}
      onDragEnd={(_, i) => i.offset.y > 80 && onClose()}
      aria-label={`${displayName(place)} details`}
      className="absolute inset-x-0 bottom-0 z-[700] mx-auto max-w-xl rounded-t-[26px] bg-card px-5 pt-3 shadow-soft hairline"
      style={{ paddingBottom: "calc(16px + var(--safe-bottom))", minHeight: CARD_HEIGHT }}
    >
      <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-faint/40" />
      <div className="flex items-start gap-3">
        <span className={cn("mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-xl text-lg", place.category === "mosque" ? "bg-[#00B388]/15" : "bg-[#D4AF37]/15")} aria-hidden>{place.category === "mosque" ? "🕌" : "🍔"}</span>
        <div className="min-w-0 flex-1">
          <h2 className="break-words text-base font-semibold leading-snug">{displayName(place)}</h2>
          <p className="text-xs text-muted">
            {categoryLabel(place.category)}
            {place.subtype && ` · ${place.subtype}`}
            {place.halalEvidence === "name" && " · matched by name only"}
          </p>
        </div>
        <button type="button" onClick={onClose} aria-label="Close details" className="focus-ring grid h-9 w-9 place-items-center rounded-full text-muted"><X size={18} /></button>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <Stat label="Straight-line" value={formatDistance(straight)} />
        <Stat
          label="Walking (OSRM)"
          value={routeStatus === "loading" ? "…" : route ? `${formatDistance(route.distanceM)} · ${formatDuration(route.durationS)}` : "Unavailable"}
          icon={<Footprints size={12} />}
        />
      </div>
      <p className="mt-1.5 text-[11px] leading-snug text-faint">
        {route ? "Walking route from the public OSRM router; actual paths may differ." : routeStatus === "unavailable" ? "No walking route available — straight-line distance shown; the real walking distance will be longer." : "Straight-line distance is as the crow flies, not a walking distance."}
      </p>

      <ul className="mt-3 space-y-1 text-xs text-muted">
        {(place.address || place.locality) && <li className="flex items-start gap-2"><MapPin size={13} className="mt-0.5 shrink-0" /><span className="break-words">{[place.address, place.locality].filter(Boolean).join(", ")}</span></li>}
        {place.openingHours && <li className="flex items-start gap-2"><Clock size={13} className="mt-0.5 shrink-0" /><span className="break-words">{place.openingHours} <span className="text-faint">(as mapped in OSM)</span></span></li>}
        {place.phone && <li className="flex items-center gap-2"><Phone size={13} className="shrink-0" /><a href={`tel:${place.phone.replace(/[^\d+]/g, "")}`} className="underline-offset-2 hover:underline">{place.phone}</a></li>}
        {place.website && <li className="flex items-center gap-2"><Globe size={13} className="shrink-0" /><a href={place.website} target="_blank" rel="noreferrer noopener" className="truncate underline-offset-2 hover:underline">{place.website.replace(/^https?:\/\//, "")}</a></li>}
      </ul>

      <div className="mt-4 flex gap-2">
        <PrimaryButton className="flex-1" onClick={() => open(isApple ? urls.apple : urls.primary)}>
          <Navigation size={16} /> Navigate
        </PrimaryButton>
        <PrimaryButton variant="ghost" onClick={() => open(isApple ? urls.primary : urls.web)} aria-label={isApple ? "Open in Google Maps" : "Open directions in browser"}>
          <ExternalLink size={16} />
        </PrimaryButton>
      </div>
      <p className="mt-2 text-center text-[11px] text-faint">Opens {isApple ? "Apple Maps" : "Google Maps"} with the venue's coordinates for driving directions.</p>
    </motion.section>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-card-2 px-3 py-2 hairline">
      <p className="flex items-center gap-1 text-[10px] uppercase tracking-[0.12em] text-faint">{icon}{label}</p>
      <p className="mt-0.5 truncate text-sm font-semibold text-ink">{value}</p>
    </div>
  );
}

/* ---------- Manual location ---------- */
function ManualLocationSheet({ open, onClose, onPick, onUseDevice }: { open: boolean; onClose: () => void; onPick: (o: Origin) => void; onUseDevice: () => void }) {
  const [country, setCountry] = useState<string | null>(() => guessCountryFromLocale());
  const [q, setQ] = useState("");
  const dq = useDeferredValue(q);
  const [mode, setMode] = useState<"country" | "city">("city");
  useEffect(() => {
    if (!open) setQ("");
  }, [open]);
  const c = country ? getCountry(country) : null;
  const countries = useMemo(() => searchCountries(dq), [dq]);
  const cities = useMemo(() => (country ? searchCities(country, dq) : []), [country, dq]);
  return (
    <Sheet open={open} onClose={onClose} title="Search location">
      <PrimaryButton variant="ghost" className="w-full" onClick={onUseDevice}><LocateFixed size={16} /> Use my location</PrimaryButton>
      <div className="my-4 flex items-center gap-3 text-xs text-faint"><span className="h-px flex-1 bg-line" /> or pick a city <span className="h-px flex-1 bg-line" /></div>
      <div className="flex gap-2">
        <button type="button" onClick={() => { setMode("country"); setQ(""); }} className={cn("focus-ring flex-1 rounded-xl px-3 py-2 text-start text-xs hairline", mode === "country" ? "bg-brand-soft text-brand-ink" : "bg-card-2")}>
          <span className="block text-[10px] uppercase tracking-wider text-faint">Country</span>
          <span className="block truncate font-medium">{c?.name ?? "Select"}</span>
        </button>
        <button type="button" disabled={!c} onClick={() => { setMode("city"); setQ(""); }} className={cn("focus-ring flex-1 rounded-xl px-3 py-2 text-start text-xs hairline disabled:opacity-40", mode === "city" ? "bg-brand-soft text-brand-ink" : "bg-card-2")}>
          <span className="block text-[10px] uppercase tracking-wider text-faint">City</span>
          <span className="block truncate font-medium">{c ? `${citiesFor(c.code).length} available` : "—"}</span>
        </button>
      </div>
      <label className="mt-3 flex items-center gap-2 rounded-2xl bg-card-2 px-4 py-3 hairline">
        <Search size={16} className="text-faint" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={mode === "country" ? "Search countries" : "Search cities"} aria-label={mode === "country" ? "Search countries" : "Search cities"} className="w-full bg-transparent text-sm outline-none placeholder:text-faint" />
      </label>
      <ul className="mt-2 max-h-[40dvh] space-y-1 overflow-y-auto no-scrollbar" role="listbox">
        {mode === "country"
          ? countries.map((x) => (
              <li key={x.code}><button type="button" role="option" aria-selected={x.code === country} onClick={() => { setCountry(x.code); setMode("city"); setQ(""); }} className={cn("focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-start text-sm", x.code === country ? "bg-brand-soft text-brand-ink font-semibold" : "hover:bg-card-2")}>{x.name}<span className="text-xs text-faint">{citiesFor(x.code).length || "—"}</span></button></li>
            ))
          : cities.slice(0, 150).map((x) => (
              <li key={`${x.name}${x.lat}${x.lng}`}><button type="button" role="option" aria-selected={false} onClick={() => onPick({ lat: x.lat, lng: x.lng, label: `${x.name}, ${c!.name}`, source: "manual" })} className="focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-start text-sm hover:bg-card-2">{x.name}{x.capital && <span className="text-[10px] text-brand-ink">★</span>}</button></li>
            ))}
        {mode === "city" && c && cities.length === 0 && <li className="px-3 py-4 text-center text-xs text-muted">No match. The built-in list covers {COUNTRIES.length} countries and cities over 100k (GeoNames). Set a precise location from Home › prayer settings to search elsewhere.</li>}
      </ul>
      <p className="mt-3 text-[11px] text-faint">City coordinates come from a dataset bundled in the app — no lookup request is sent. The search itself still goes to OpenStreetMap's Overpass service.</p>
    </Sheet>
  );
}

/* ---------- Privacy / sources ---------- */
function PrivacySheet({ open, onClose, onClearCache }: { open: boolean; onClose: () => void; onClearCache: () => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="Privacy & data sources">
      <div className="space-y-3 text-sm leading-relaxed text-muted">
        <p><strong className="text-ink">Nothing goes to Sajidin.</strong> There is no Sajidin server in this feature. Your position, searches, selections and navigation taps are never uploaded, logged or synced, and results are kept only in memory for this session (10-minute cache, cleared when you leave).</p>
        <p><strong className="text-ink">What external services receive:</strong></p>
        <ul className="list-disc space-y-1 pl-5 text-xs">
          <li><strong>Overpass API</strong> (overpass-api.de, fallback overpass.kumi.systems): the search coordinates, {SEARCH_RADIUS_M / 1000} km radius and venue tags — sent directly over HTTPS without identifiers.</li>
          <li><strong>CARTO / OpenStreetMap tiles</strong>: the map tile positions you view (i.e. the area of the map).</li>
          <li><strong>OSRM demo router</strong> (router.project-osrm.org): origin and venue coordinates, only when you open a venue card, to estimate walking distance.</li>
          <li><strong>Your maps app</strong>: the venue's coordinates when you tap Navigate.</li>
        </ul>
        <p className="text-xs">Venue data © OpenStreetMap contributors (ODbL). Mosques: <code>amenity=place_of_worship</code> + <code>religion=muslim</code>. Halal: <code>diet:halal=yes</code>, <code>cuisine=halal</code>, or “halal” in the name. Coverage depends on what volunteers have mapped; missing or unnamed venues are shown as such, never invented.</p>
      </div>
      <PrimaryButton variant="ghost" className="mt-4 w-full" onClick={onClearCache}><Trash2 size={16} /> Clear cached results</PrimaryButton>
    </Sheet>
  );
}
