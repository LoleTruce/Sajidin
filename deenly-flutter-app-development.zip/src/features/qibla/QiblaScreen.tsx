import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Compass, Info, MapPin, Settings2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { PrimaryButton, ScreenHeader, Sheet, IconButton } from "../../components/ui";
import { haptics } from "../../core/haptics";
import { useStore } from "../../core/store";
import { angleDelta, continuousRotation, distanceToKaabaKm, isAligned, normalizeDegrees, qiblaBearing, smoothHeading } from "../../lib/qibla";
import { compassSupported, needsPermissionGesture, startCompass, type CompassStatus, type CompassSubscription } from "../../services/compass";
import { settingsStore } from "../../state/stores";
import { LocationSheet } from "../home/HomeSettings";
import { cn } from "../../utils/cn";

export function QiblaScreen({ onAlignedChange }: { onAlignedChange: (aligned: boolean) => void }) {
  const location = useStore(settingsStore, (s) => s.location);
  const declination = useStore(settingsStore, (s) => s.magneticDeclination);
  const tolerance = useStore(settingsStore, (s) => s.qiblaToleranceDeg);
  const [status, setStatus] = useState<CompassStatus>("idle");
  const [heading, setHeading] = useState<number | null>(null);
  const [accuracy, setAccuracy] = useState<number | undefined>();
  const [aligned, setAligned] = useState(false);
  const [sheet, setSheet] = useState<"none" | "location" | "settings" | "help">("none");

  const subRef = useRef<CompassSubscription | null>(null);
  const smoothRef = useRef<number | null>(null);
  const alignedRef = useRef(false);
  const lastUiUpdate = useRef(0);

  const bearing = location ? qiblaBearing(location.lat, location.lng) : null;
  const distance = location ? distanceToKaabaKm(location.lat, location.lng) : null;

  // Motion values: the dial rotates by -heading; the needle for Qibla sits at `bearing` on the dial.
  const dialRotation = useMotionValue(0);
  const dialSpring = useSpring(dialRotation, { stiffness: 90, damping: 18, mass: 0.6 });
  const bearingMV = useMotionValue(bearing ?? 0);
  useEffect(() => {
    bearingMV.set(bearing ?? 0);
  }, [bearing, bearingMV]);
  const needleRotation = useTransform([dialSpring, bearingMV], ([r, b]) => (r as number) + (b as number));

  const handleSample = useCallback(
    (magnetic: number) => {
      const trueHeading = normalizeDegrees(magnetic + declination);
      const smoothed = smoothHeading(smoothRef.current, trueHeading);
      smoothRef.current = smoothed;
      dialRotation.set(continuousRotation(dialRotation.get(), normalizeDegrees(-smoothed)));

      // Throttle React state updates to ~8/s; the dial itself animates through motion values.
      const now = performance.now();
      if (now - lastUiUpdate.current > 120) {
        lastUiUpdate.current = now;
        setHeading(smoothed);
      }

      if (bearing != null) {
        // Hysteresis: enter at `tolerance`, leave at `tolerance + 2` to avoid flicker at the edge.
        const inside = alignedRef.current ? isAligned(smoothed, bearing, tolerance + 2) : isAligned(smoothed, bearing, tolerance);
        if (inside !== alignedRef.current) {
          alignedRef.current = inside;
          setAligned(inside);
          if (inside) haptics.success();
        }
      }
    },
    [bearing, declination, tolerance, dialRotation],
  );

  const handleRef = useRef(handleSample);
  handleRef.current = handleSample;

  const start = useCallback(async () => {
    subRef.current?.stop();
    smoothRef.current = null;
    const sub = await startCompass(
      (s) => {
        handleRef.current(s.heading);
        setAccuracy(s.accuracy);
      },
      (st) => setStatus(st),
    );
    subRef.current = sub;
  }, []);

  // Auto-start where no gesture is needed (Android); iOS requires the button tap.
  useEffect(() => {
    if (compassSupported() && !needsPermissionGesture()) void start();
    return () => {
      subRef.current?.stop();
      subRef.current = null;
    };
  }, [start]);

  // Pause sensors when tab hidden to save battery.
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "hidden") {
        subRef.current?.stop();
        subRef.current = null;
      } else if (status === "active" && !needsPermissionGesture()) {
        void start();
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [status, start]);

  useEffect(() => {
    onAlignedChange(aligned);
    return () => onAlignedChange(false);
  }, [aligned, onAlignedChange]);

  // If location or bearing changes while aligned, re-evaluate.
  useEffect(() => {
    if (!bearing && alignedRef.current) {
      alignedRef.current = false;
      setAligned(false);
    }
  }, [bearing]);

  const delta = heading != null && bearing != null ? angleDelta(heading, bearing) : null;
  const fg = aligned ? "text-on-brand" : "text-ink";
  const fgMuted = aligned ? "text-on-brand/70" : "text-muted";

  return (
    <div className={cn("mx-auto flex min-h-[calc(100dvh-56px-var(--safe-top))] max-w-xl flex-col pb-28 transition-colors duration-500", fg)}>
      <ScreenHeader
        title="Qibla"
        subtitle="Direction to the Kaaba"
        right={
          <div className="flex gap-2">
            <IconButton label="How the compass works" onClick={() => setSheet("help")} className={cn(aligned && "bg-on-brand/10 border-on-brand/10 text-on-brand")}>
              <Info size={16} />
            </IconButton>
            <IconButton label="Compass settings" onClick={() => setSheet("settings")} className={cn(aligned && "bg-on-brand/10 border-on-brand/10 text-on-brand")}>
              <Settings2 size={16} />
            </IconButton>
          </div>
        }
      />

      <div className="px-5">
        <button type="button" onClick={() => setSheet("location")} className={cn("focus-ring flex items-center gap-1.5 rounded-full text-xs font-medium", fgMuted)}>
          <MapPin size={13} className={aligned ? "" : "text-brand-ink"} />
          {location ? location.label ?? `${location.lat.toFixed(3)}, ${location.lng.toFixed(3)}` : "Set your location to calculate the Qibla"}
        </button>
      </div>

      {!location ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
          <span className="grid h-16 w-16 place-items-center rounded-full bg-card text-brand-ink hairline">
            <Compass size={28} />
          </span>
          <p className="text-sm text-muted">The Qibla bearing is calculated on your device from your coordinates — no internet required once set.</p>
          <PrimaryButton onClick={() => setSheet("location")}>
            <MapPin size={16} /> Set location
          </PrimaryButton>
        </div>
      ) : (
        <>
          <div className="relative mx-auto mt-6 aspect-square w-[min(78vw,340px)]" role="img" aria-label={`Qibla is at ${Math.round(bearing!)} degrees${heading != null ? `, your heading is ${Math.round(heading)} degrees` : ""}`}>
            {/* Fixed device pointer at the top */}
            <div className={cn("absolute left-1/2 top-[-6px] z-10 h-0 w-0 -translate-x-1/2 border-x-[9px] border-b-[14px] border-x-transparent transition-colors duration-500", aligned ? "border-b-on-brand" : "border-b-brand")} aria-hidden />

            {/* Rotating dial */}
            <motion.div style={{ rotate: dialSpring }} className={cn("absolute inset-0 rounded-full border transition-colors duration-500", aligned ? "border-on-brand/15 bg-on-brand/5" : "border-line bg-card")}>
              {Array.from({ length: 72 }).map((_, i) => (
                <span key={i} className="absolute inset-0" style={{ transform: `rotate(${i * 5}deg)` }} aria-hidden>
                  <span
                    className={cn(
                      "absolute left-1/2 top-2 -translate-x-1/2 rounded-full",
                      i % 18 === 0 ? "h-4 w-[2px]" : i % 6 === 0 ? "h-3 w-[1.5px]" : "h-2 w-px",
                      aligned ? "bg-on-brand/50" : i % 18 === 0 ? "bg-ink/70" : "bg-ink/20",
                    )}
                  />
                </span>
              ))}
              {["N", "E", "S", "W"].map((l, i) => (
                <span key={l} className="absolute inset-0" style={{ transform: `rotate(${i * 90}deg)` }}>
                  <span
                    className={cn("absolute left-1/2 top-8 -translate-x-1/2 text-sm font-semibold", l === "N" && !aligned ? "text-brand-ink" : aligned ? "text-on-brand" : "text-muted")}
                    style={{ display: "inline-block", transform: `translateX(-50%) rotate(${-i * 90}deg)` }}
                  >
                    {l}
                  </span>
                </span>
              ))}
            </motion.div>

            {/* Qibla needle (rotates with dial + bearing) */}
            <motion.div style={{ rotate: needleRotation }} className="absolute inset-0">
              <span className={cn("absolute bottom-1/2 left-1/2 top-[22%] w-[3px] -translate-x-1/2 rounded-full transition-colors duration-500", aligned ? "bg-on-brand" : "bg-brand")} />
              <motion.span
                animate={{ scale: aligned ? 1.15 : 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 18 }}
                className={cn("absolute left-1/2 top-[11%] grid h-9 w-9 -translate-x-1/2 place-items-center rounded-xl text-lg shadow-soft transition-colors duration-500", aligned ? "bg-on-brand text-brand" : "bg-brand text-on-brand")}
                aria-hidden
              >
                🕋
              </motion.span>
            </motion.div>

            {/* Centre */}
            <div className={cn("absolute left-1/2 top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] transition-colors duration-500", aligned ? "border-on-brand bg-brand" : "border-brand bg-bg")} />
          </div>

          <div className="mt-6 px-5 text-center">
            <AnimatePresence mode="wait">
              <motion.p key={aligned ? "aligned" : "not"} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.25 }} className="text-lg font-semibold">
                {aligned ? "You are facing the Qibla" : delta == null ? "Qibla direction ready" : Math.abs(delta) < 15 ? "Almost there" : `Turn ${delta > 0 ? "right" : "left"} ${Math.round(Math.abs(delta))}°`}
              </motion.p>
            </AnimatePresence>
            <div className={cn("mt-3 grid grid-cols-3 gap-2 text-xs", fgMuted)}>
              <Stat label="Qibla" value={`${bearing!.toFixed(1)}°`} aligned={aligned} />
              <Stat label="Heading" value={heading == null ? "—" : `${Math.round(heading)}°`} aligned={aligned} />
              <Stat label="Distance" value={`${Math.round(distance!).toLocaleString()} km`} aligned={aligned} />
            </div>

            <div className="mt-4 min-h-10">
              {status === "idle" && needsPermissionGesture() && (
                <PrimaryButton onClick={() => void start()} className="w-full">
                  <Compass size={16} /> Start compass
                </PrimaryButton>
              )}
              {status === "requesting" && <p className={cn("text-xs", fgMuted)}>Requesting motion & orientation access…</p>}
              {status === "denied" && (
                <Notice tone="warn">Motion & orientation access was denied. On iPhone: Settings › Safari › Motion & Orientation Access. The bearing above is still correct — align using a physical compass.</Notice>
              )}
              {status === "unsupported" && <Notice tone="warn">This device doesn't expose a compass. Use the bearing of {Math.round(bearing!)}° from true north with any compass.</Notice>}
              {status === "no-data" && <Notice tone="warn">No heading data yet. Move the device in a figure-of-8 to calibrate, and make sure compass/location services are on.</Notice>}
              {status === "active" && accuracy != null && accuracy > 25 && <Notice tone="warn">Compass accuracy is low (±{Math.round(accuracy)}°). Move away from metal and wave the device in a figure-of-8.</Notice>}
              {status === "active" && declination === 0 && <p className={cn("text-[11px]", fgMuted)}>Heading is magnetic. Set your local declination in settings for true-north accuracy.</p>}
            </div>
          </div>
        </>
      )}

      <LocationSheet open={sheet === "location"} onClose={() => setSheet("none")} />
      <QiblaSettingsSheet open={sheet === "settings"} onClose={() => setSheet("none")} />
      <Sheet open={sheet === "help"} onClose={() => setSheet("none")} title="About the Qibla compass">
        <div className="space-y-3 text-sm leading-relaxed text-muted">
          <p>
            Sajidin computes the <strong className="text-ink">great-circle bearing</strong> from your coordinates to the Kaaba (21.4225° N, 39.8262° E) entirely on your device. This works offline.
          </p>
          <p>
            The live heading comes from your phone's fused orientation sensors. Compass sensors report <strong className="text-ink">magnetic</strong> north; enter your local magnetic declination in settings to convert to true north (typically between −20° and +20°; look it up for your city).
          </p>
          <p>Hold the phone flat, away from magnets and metal. If readings drift, move it in a figure-of-8 pattern to recalibrate.</p>
          <p>When you're within the tolerance the screen turns green and vibrates once; it won't vibrate again until you turn away and realign.</p>
        </div>
      </Sheet>
    </div>
  );
}

function Stat({ label, value, aligned }: { label: string; value: string; aligned: boolean }) {
  return (
    <div className={cn("rounded-2xl px-2 py-2.5 transition-colors duration-500", aligned ? "bg-on-brand/10" : "bg-card hairline")}>
      <p className="text-[10px] uppercase tracking-[0.12em] opacity-70">{label}</p>
      <p className="mt-0.5 text-sm font-semibold tabular-nums">{value}</p>
    </div>
  );
}

function Notice({ children, tone }: { children: React.ReactNode; tone: "warn" }) {
  return (
    <p role="status" className={cn("rounded-xl px-3 py-2 text-left text-xs leading-relaxed", tone === "warn" && "bg-warn-bg text-warn-ink")}>
      {children}
    </p>
  );
}

function QiblaSettingsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useStore(settingsStore);
  return (
    <Sheet open={open} onClose={onClose} title="Compass settings">
      <label htmlFor="decl" className="text-sm font-medium">
        Magnetic declination: {s.magneticDeclination > 0 ? "+" : ""}
        {s.magneticDeclination.toFixed(1)}° {s.magneticDeclination === 0 ? "" : s.magneticDeclination > 0 ? "(east)" : "(west)"}
      </label>
      <input id="decl" type="range" min={-30} max={30} step={0.5} value={s.magneticDeclination} onChange={(e) => settingsStore.set({ magneticDeclination: Number(e.target.value) })} className="mt-1 w-full" />
      <p className="mt-1 text-xs text-faint">Added to the sensor heading so the dial points to true north. East is positive.</p>

      <label htmlFor="tol" className="mt-6 block text-sm font-medium">
        Alignment tolerance: ±{s.qiblaToleranceDeg}°
      </label>
      <input id="tol" type="range" min={2} max={15} step={1} value={s.qiblaToleranceDeg} onChange={(e) => settingsStore.set({ qiblaToleranceDeg: Number(e.target.value) })} className="mt-1 w-full" />
      <p className="mt-1 text-xs text-faint">How close your heading must be to the Qibla before the screen turns green.</p>
    </Sheet>
  );
}
