import { Cloud, CloudOff, HardDrive, Loader2, LogIn, LogOut, RefreshCw, ShieldCheck, UserRound } from "lucide-react";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ConfirmDialog, PrimaryButton, Sheet, useToast } from "../../components/ui";
import { useStore } from "../../core/store";
import { describeUser, getAuthProvider, useAuthSession, useHasAuthProvider } from "../../auth/session";
import { bookmarksStore, tasbihStore } from "../../state/stores";
import { useThemeSync, type SyncStatus } from "../../theme/themeStore";
import { getDefaultSync } from "../../theme/sync";
import { cn } from "../../utils/cn";

export function AccountSheet({ open, onClose, onOpenSettings }: { open: boolean; onClose: () => void; onOpenSettings: () => void }) {
  const session = useAuthSession();
  const hasProvider = useHasAuthProvider();
  const sync = useThemeSync();
  const toast = useToast();
  const [confirmLogout, setConfirmLogout] = useState(false);
  const [busy, setBusy] = useState<"signin" | "signout" | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const busyRef = useRef(false);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const bookmarkCount = useStore(bookmarksStore, (b) => b.ayahs.length + b.duas.length + b.hadiths.length);
  const tasbihTotal = useStore(tasbihStore, (t) => t.totalLifetime);
  const who = useMemo(() => describeUser(session.user), [session.user]);

  const run = async (kind: "signin" | "signout") => {
    if (busyRef.current) return; // prevent duplicate requests on rapid taps
    const provider = getAuthProvider();
    if (!provider) return;
    busyRef.current = true;
    setBusy(kind);
    setActionError(null);
    try {
      if (kind === "signout") {
        await provider.signOut();
        if (mounted.current) {
          toast("Signed out", "success");
          onClose();
        }
      } else {
        await provider.signIn();
      }
    } catch (e) {
      if (mounted.current) setActionError(e instanceof Error && e.message ? e.message : `Could not ${kind === "signout" ? "sign out" : "sign in"}.`);
    } finally {
      busyRef.current = false;
      if (mounted.current) setBusy(null);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Account">
      {/* ---------- Identity ---------- */}
      <div className="flex items-center gap-3">
        <span className={cn("grid h-12 w-12 shrink-0 place-items-center rounded-full", session.status === "signed-in" ? "bg-brand-soft text-brand-ink" : "bg-card-2 text-muted")}>
          {session.status === "loading" ? <Loader2 size={20} className="animate-spin" /> : <UserRound size={22} />}
        </span>
        <div className="min-w-0">
          <p className="truncate text-base font-semibold">{session.status === "loading" ? "Checking session…" : who.title}</p>
          <p className="truncate text-xs text-muted">{who.subtitle ?? authStatusText(session.status, hasProvider)}</p>
        </div>
        <StatusPill status={session.status} />
      </div>

      {session.status === "error" && session.error && (
        <p role="alert" className="mt-3 rounded-xl bg-danger-bg px-3 py-2 text-xs text-danger-ink">
          {session.error}
        </p>
      )}

      {/* ---------- Backup & sync ---------- */}
      <h3 className="mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-muted">Backup & sync</h3>
      <div className="mt-2 space-y-2">
        <Row
          icon={syncIcon(sync.sync)}
          tone={sync.sync === "error" ? "danger" : sync.sync === "synced" ? "brand" : "neutral"}
          title="Appearance preferences"
          text={sync.syncError ?? syncText(sync.sync, sync.lastSyncedAt)}
          action={
            session.status === "signed-in" && (sync.sync === "pending" || sync.sync === "error") ? (
              <button type="button" onClick={() => void getDefaultSync()?.syncNow()} aria-label="Retry sync" className="focus-ring rounded-full p-2 text-muted">
                <RefreshCw size={15} />
              </button>
            ) : undefined
          }
        />
        <Row
          icon={<HardDrive size={16} />}
          tone="neutral"
          title="Quran, Dua & Hadith bookmarks"
          text={`${bookmarkCount} saved on this device${bookmarkCount ? "" : " yet"}. Cloud backup for bookmarks isn't available in this build.`}
        />
        <Row icon={<ShieldCheck size={16} />} tone="neutral" title="Tasbih & settings" text={`${tasbihTotal.toLocaleString()} lifetime counts, prayer settings and location are stored locally only.`} />
      </div>

      {/* ---------- Actions ---------- */}
      <div className="mt-6 space-y-2">
        {session.status === "signed-in" ? (
          <PrimaryButton variant="danger" className="w-full" disabled={busy !== null} onClick={() => setConfirmLogout(true)}>
            {busy === "signout" ? <Loader2 size={16} className="animate-spin" /> : <LogOut size={16} />} Log out
          </PrimaryButton>
        ) : hasProvider ? (
          <PrimaryButton className="w-full" disabled={busy !== null || session.status === "loading"} onClick={() => void run("signin")}>
            {busy === "signin" ? <Loader2 size={16} className="animate-spin" /> : <LogIn size={16} />} Sign in
          </PrimaryButton>
        ) : (
          <div className="rounded-2xl bg-card-2 p-3 text-xs leading-relaxed text-muted hairline">
            <strong className="text-ink">Accounts aren't available in this build.</strong> Sajidin works fully without one — everything you save stays on this device. When sign-in is added, your appearance preferences will follow you across devices.
          </div>
        )}
        {actionError && (
          <p role="alert" className="rounded-xl bg-danger-bg px-3 py-2 text-xs text-danger-ink">
            {actionError}
          </p>
        )}
        <PrimaryButton variant="ghost" className="w-full" onClick={onOpenSettings}>
          Appearance & customization
        </PrimaryButton>
      </div>

      <ConfirmDialog
        open={confirmLogout}
        title="Log out?"
        message="You'll stay customised: appearance, bookmarks and Tasbih counts remain on this device. Only your session is ended."
        confirmLabel="Log out"
        danger
        onCancel={() => setConfirmLogout(false)}
        onConfirm={() => {
          setConfirmLogout(false);
          void run("signout");
        }}
      />
    </Sheet>
  );
}

/* ------------------------------------------------------------------ */

function StatusPill({ status }: { status: ReturnType<typeof useAuthSession>["status"] }) {
  const map: Record<typeof status, { text: string; cls: string }> = {
    "signed-in": { text: "Signed in", cls: "bg-brand-soft text-brand-ink" },
    "signed-out": { text: "Signed out", cls: "bg-card-2 text-muted" },
    loading: { text: "Loading", cls: "bg-card-2 text-muted" },
    error: { text: "Error", cls: "bg-danger-bg text-danger-ink" },
    unavailable: { text: "Local only", cls: "bg-card-2 text-muted" },
  };
  const m = map[status];
  return <span className={cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold", m.cls)}>{m.text}</span>;
}

function Row({ icon, tone, title, text, action }: { icon: ReactNode; tone: "brand" | "neutral" | "danger"; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex items-start gap-3 rounded-2xl bg-card-2 p-3 hairline">
      <span className={cn("mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg", tone === "brand" && "bg-brand-soft text-brand-ink", tone === "neutral" && "bg-bg/60 text-muted", tone === "danger" && "bg-danger-bg text-danger-ink")}>
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium">{title}</p>
        <p className="mt-0.5 text-xs leading-relaxed text-muted">{text}</p>
      </div>
      {action}
    </div>
  );
}

function authStatusText(status: ReturnType<typeof useAuthSession>["status"], hasProvider: boolean): string {
  switch (status) {
    case "signed-in":
      return "Signed in";
    case "signed-out":
      return "Sign in to sync your appearance across devices.";
    case "loading":
      return "Restoring your session…";
    case "error":
      return "We couldn't verify your session.";
    default:
      return hasProvider ? "Session unavailable" : "No account needed — your data stays on this device.";
  }
}

function syncIcon(s: SyncStatus): ReactNode {
  if (s === "syncing") return <Loader2 size={16} className="animate-spin" />;
  if (s === "synced") return <Cloud size={16} />;
  return <CloudOff size={16} />;
}

function syncText(s: SyncStatus, last: number | null): string {
  switch (s) {
    case "synced":
      return last ? `Synced to your profile · ${new Date(last).toLocaleTimeString()}` : "Synced to your profile.";
    case "syncing":
      return "Synchronisation in progress…";
    case "pending":
      return "Saved locally — waiting to sync.";
    case "error":
      return "Sync failed. Your local settings are unaffected.";
    case "signed-out":
    default:
      return "Saved on this device. Not synchronised to a profile.";
  }
}
