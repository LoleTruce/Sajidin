import { createStore, useStore } from "../core/store";
import { DICTIONARIES, format, isLanguageCode, LANGUAGES, type LanguageCode, type StringKey } from "./strings";

export * from "./strings";

export const LANGUAGE_PREF_KEY = "deenly_language";

interface LocaleState {
  language: LanguageCode;
}

function readSaved(): LanguageCode | null {
  try {
    const v = localStorage.getItem(LANGUAGE_PREF_KEY);
    return isLanguageCode(v) ? v : null;
  } catch {
    return null;
  }
}

/** Picks the best supported language from the browser's preferences (used only when nothing is saved). */
export function detectLanguage(): LanguageCode {
  try {
    const langs = typeof navigator !== "undefined" ? navigator.languages ?? [navigator.language] : [];
    for (const l of langs) {
      const base = l.toLowerCase().split("-")[0];
      if (isLanguageCode(base)) return base;
    }
  } catch {
    /* ignore */
  }
  return "en";
}

export const localeStore = createStore<LocaleState>({ language: readSaved() ?? detectLanguage() });

function applyToDocument(code: LanguageCode): void {
  if (typeof document === "undefined") return;
  document.documentElement.lang = code;
  document.documentElement.dir = LANGUAGES[code].dir;
}

export const locale = {
  /** Applies the current language to <html>. Call once at boot. */
  init(): LanguageCode {
    applyToDocument(localeStore.get().language);
    return localeStore.get().language;
  },
  /** Returns false if the preference could not be persisted (state still updates in memory). */
  setLanguage(code: LanguageCode): boolean {
    if (!isLanguageCode(code)) return false;
    localeStore.set({ language: code });
    applyToDocument(code);
    try {
      localStorage.setItem(LANGUAGE_PREF_KEY, code);
      return true;
    } catch {
      return false;
    }
  },
  get(): LanguageCode {
    return localeStore.get().language;
  },
  hasSavedPreference(): boolean {
    return readSaved() !== null;
  },
  t(key: StringKey, params?: Record<string, string | number>, code = localeStore.get().language): string {
    return format(DICTIONARIES[code][key] ?? DICTIONARIES.en[key], params);
  },
};

export function useLanguage(): LanguageCode {
  return useStore(localeStore, (s) => s.language);
}

/** Hook returning a translator bound to the active language; re-renders only when the language changes. */
export function useT(): (key: StringKey, params?: Record<string, string | number>) => string {
  const code = useLanguage();
  return (key, params) => locale.t(key, params, code);
}
