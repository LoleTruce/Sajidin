import { useSyncExternalStore } from "react";

/**
 * Minimal typed external store with optional localStorage persistence.
 * Keeps state outside React so unrelated components don't re-render.
 */
export interface Store<T> {
  get: () => T;
  set: (updater: Partial<T> | ((prev: T) => T)) => void;
  subscribe: (listener: () => void) => () => void;
}

const PREFIX = "deenly:";

export function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw == null) return fallback;
    return { ...fallback, ...(JSON.parse(raw) as T) };
  } catch {
    return fallback;
  }
}

export function writeStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* quota or private mode — ignore, state still lives in memory */
  }
}

export function createStore<T extends object>(initial: T, persistKey?: string): Store<T> {
  let state: T = persistKey ? readStorage<T>(persistKey, initial) : initial;
  const listeners = new Set<() => void>();

  return {
    get: () => state,
    set: (updater) => {
      const next = typeof updater === "function" ? updater(state) : { ...state, ...updater };
      if (Object.is(next, state)) return;
      state = next;
      if (persistKey) writeStorage(persistKey, state);
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
  };
}

export function useStore<T extends object, S = T>(store: Store<T>, selector: (s: T) => S = (s) => s as unknown as S): S {
  return useSyncExternalStore(store.subscribe, () => selector(store.get()), () => selector(store.get()));
}
