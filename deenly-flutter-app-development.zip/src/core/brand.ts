/**
 * Single source of truth for public-facing brand strings.
 * Internal identifiers (storage keys prefixed `deenly:` / `deenly_`, the IndexedDB name,
 * CSS class names) are intentionally NOT derived from this file — they are stable
 * compatibility identifiers and renaming them would wipe existing users' settings.
 */
export const BRAND = {
  name: "Sajidin",
  publisher: "UA Digital Labs",
  tagline: "Islamic Companion",
  /** Used in share footers. */
  shareSuffix: "Shared from Sajidin",
} as const;
