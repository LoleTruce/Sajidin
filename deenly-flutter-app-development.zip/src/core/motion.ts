import type { Transition, Variants } from "framer-motion";

/** Shared animation language: 200–350ms, easeOutCubic-style curves. */
export const EASE_OUT: [number, number, number, number] = [0.33, 1, 0.68, 1];
export const EASE_IN_OUT: [number, number, number, number] = [0.65, 0, 0.35, 1];

export const fast: Transition = { duration: 0.2, ease: EASE_OUT };
export const base: Transition = { duration: 0.28, ease: EASE_OUT };
export const slow: Transition = { duration: 0.35, ease: EASE_IN_OUT };

export const staggerContainer: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.04 } },
};

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: base },
};

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: base },
  exit: { opacity: 0, transition: fast },
};

export const screenVariants: Variants = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0, transition: base },
  exit: { opacity: 0, y: -6, transition: fast },
};

export const sheetVariants: Variants = {
  hidden: { y: "100%" },
  show: { y: 0, transition: { duration: 0.32, ease: EASE_OUT } },
  exit: { y: "100%", transition: { duration: 0.24, ease: EASE_IN_OUT } },
};
