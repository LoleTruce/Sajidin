import { settingsStore } from "../state/stores";

/**
 * Vibration feedback. Always optional: respects the user's "Haptic feedback" setting, and is a
 * silent no-op where `navigator.vibrate` is missing (iOS Safari, many desktops, some Android
 * WebViews) or throws. Never blocks or precedes the visual feedback it accompanies.
 */
function vibrate(pattern: number | number[]): void {
  try {
    if (!settingsStore.get().hapticsEnabled) return;
    if (typeof navigator === "undefined" || typeof navigator.vibrate !== "function") return;
    navigator.vibrate(pattern);
  } catch {
    /* unsupported or blocked (e.g. no user activation yet) */
  }
}

export const haptics = {
  light(): void {
    vibrate(8);
  },
  medium(): void {
    vibrate(20);
  },
  success(): void {
    vibrate([30, 40, 30]);
  },
  /** Whether the device exposes a vibration API at all (used to hide the toggle where meaningless). */
  get supported(): boolean {
    try {
      return typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
    } catch {
      return false;
    }
  },
};
