/**
 * Daily supplications drawn from Hisn al-Muslim (Fortress of the Muslim, Saʿīd ibn ʿAlī al-Qaḥṭānī),
 * each with its primary hadith reference. Arabic follows the standard text; transliteration is
 * included only where it is well established.
 */
export type DuaCategory =
  | "Morning & Evening"
  | "Eating"
  | "Sleep & Waking"
  | "Home"
  | "Mosque"
  | "Travel"
  | "Distress & Forgiveness"
  | "General Remembrance";

export interface Dua {
  id: string;
  category: DuaCategory;
  title: string;
  arabic: string;
  transliteration?: string;
  english: string;
  reference: string;
  note?: string;
}

export const DUA_CATEGORIES: DuaCategory[] = [
  "Morning & Evening",
  "Eating",
  "Sleep & Waking",
  "Home",
  "Mosque",
  "Travel",
  "Distress & Forgiveness",
  "General Remembrance",
];

export const DUAS: Dua[] = [
  {
    id: "morning-1",
    category: "Morning & Evening",
    title: "Upon reaching the morning",
    arabic:
      "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
    english:
      "We have reached the morning and at this very time all sovereignty belongs to Allah. All praise is for Allah. None has the right to be worshipped except Allah, alone, without partner; to Him belongs all sovereignty and praise and He is over all things omnipotent. My Lord, I ask You for the good of this day and the good of what follows it, and I seek refuge in You from the evil of this day and the evil of what follows it. My Lord, I seek refuge in You from laziness and senility. My Lord, I seek refuge in You from torment in the Fire and punishment in the grave.",
    reference: "Sahih Muslim 2723 · Hisn al-Muslim 75",
  },
  {
    id: "evening-1",
    category: "Morning & Evening",
    title: "Upon reaching the evening",
    arabic:
      "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
    english:
      "We have reached the evening and at this very time all sovereignty belongs to Allah. All praise is for Allah. None has the right to be worshipped except Allah, alone, without partner; to Him belongs all sovereignty and praise and He is over all things omnipotent. My Lord, I ask You for the good of this night and the good of what follows it, and I seek refuge in You from the evil of this night and the evil of what follows it. My Lord, I seek refuge in You from laziness and senility. My Lord, I seek refuge in You from torment in the Fire and punishment in the grave.",
    reference: "Sahih Muslim 2723 · Hisn al-Muslim 75",
  },
  {
    id: "sayyid-istighfar",
    category: "Morning & Evening",
    title: "Sayyid al-Istighfar (the master of seeking forgiveness)",
    arabic:
      "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
    transliteration:
      "Allāhumma anta rabbī lā ilāha illā ant, khalaqtanī wa anā ʿabduk, wa anā ʿalā ʿahdika wa waʿdika mastaṭaʿt, aʿūdhu bika min sharri mā ṣanaʿt, abūʾu laka bi-niʿmatika ʿalayy, wa abūʾu bi-dhanbī faghfir lī fa-innahu lā yaghfiru-dh-dhunūba illā ant.",
    english:
      "O Allah, You are my Lord; none has the right to be worshipped except You. You created me and I am Your servant, and I abide by Your covenant and promise as best I can. I seek refuge in You from the evil of what I have done. I acknowledge Your favour upon me and I acknowledge my sin, so forgive me, for verily none forgives sins except You.",
    reference: "Sahih al-Bukhari 6306 · Hisn al-Muslim 78",
    note: "Whoever says it with certainty in the evening and dies that night enters Paradise, and likewise in the morning.",
  },
  {
    id: "bismillah-ladhi",
    category: "Morning & Evening",
    title: "Protection from all harm (three times)",
    arabic:
      "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    transliteration:
      "Bismillāhi-lladhī lā yaḍurru maʿa-smihi shayʾun fi-l-arḍi wa lā fi-s-samāʾi wa huwa-s-samīʿu-l-ʿalīm.",
    english:
      "In the name of Allah, with Whose name nothing on earth or in the heaven can cause harm, and He is the All-Hearing, the All-Knowing.",
    reference: "Sunan Abi Dawud 5088 · Jami` at-Tirmidhi 3388 · Hisn al-Muslim 86",
    note: "Recited three times in the morning and evening.",
  },
  {
    id: "audhu-kalimat",
    category: "Morning & Evening",
    title: "Refuge in the perfect words of Allah (evening, three times)",
    arabic: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
    transliteration: "Aʿūdhu bi-kalimāti-llāhi-t-tāmmāti min sharri mā khalaq.",
    english: "I seek refuge in the perfect words of Allah from the evil of what He has created.",
    reference: "Sahih Muslim 2709 · Hisn al-Muslim 85",
  },
  {
    id: "before-eating",
    category: "Eating",
    title: "Before eating",
    arabic: "بِسْمِ اللَّهِ",
    transliteration: "Bismillāh.",
    english: "In the name of Allah.",
    reference: "Sunan Abi Dawud 3767 · Jami` at-Tirmidhi 1858 · Hisn al-Muslim 176",
    note: "If one forgets at the start, say: بِسْمِ اللَّهِ فِي أَوَّلِهِ وَآخِرِهِ — “In the name of Allah at its beginning and its end.”",
  },
  {
    id: "after-eating",
    category: "Eating",
    title: "After eating",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ",
    transliteration: "Al-ḥamdu lillāhi-lladhī aṭʿamanī hādhā wa razaqanīhi min ghayri ḥawlin minnī wa lā quwwah.",
    english: "All praise is for Allah Who fed me this and provided it for me without any might or power on my part.",
    reference: "Sunan Abi Dawud 4023 · Jami` at-Tirmidhi 3458 · Hisn al-Muslim 178",
  },
  {
    id: "before-sleep",
    category: "Sleep & Waking",
    title: "Before sleeping",
    arabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    transliteration: "Bismika-llāhumma amūtu wa aḥyā.",
    english: "In Your name, O Allah, I die and I live.",
    reference: "Sahih al-Bukhari 6324 · Hisn al-Muslim 102",
  },
  {
    id: "after-waking",
    category: "Sleep & Waking",
    title: "Upon waking",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
    transliteration: "Al-ḥamdu lillāhi-lladhī aḥyānā baʿda mā amātanā wa ilayhi-n-nushūr.",
    english: "All praise is for Allah Who gave us life after having taken it from us, and unto Him is the resurrection.",
    reference: "Sahih al-Bukhari 6312 · Hisn al-Muslim 1",
  },
  {
    id: "entering-home",
    category: "Home",
    title: "Entering the home",
    arabic: "بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى رَبِّنَا تَوَكَّلْنَا",
    transliteration: "Bismillāhi walajnā, wa bismillāhi kharajnā, wa ʿalā rabbinā tawakkalnā.",
    english: "In the name of Allah we enter, in the name of Allah we leave, and upon our Lord we place our trust.",
    reference: "Sunan Abi Dawud 5096 · Hisn al-Muslim 18",
    note: "Then greet one's family with salām.",
  },
  {
    id: "leaving-home",
    category: "Home",
    title: "Leaving the home",
    arabic: "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    transliteration: "Bismillāh, tawakkaltu ʿala-llāh, wa lā ḥawla wa lā quwwata illā billāh.",
    english: "In the name of Allah, I place my trust in Allah, and there is no might nor power except with Allah.",
    reference: "Sunan Abi Dawud 5095 · Jami` at-Tirmidhi 3426 · Hisn al-Muslim 16",
  },
  {
    id: "entering-toilet",
    category: "Home",
    title: "Entering the toilet",
    arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ",
    transliteration: "Allāhumma innī aʿūdhu bika mina-l-khubuthi wa-l-khabāʾith.",
    english: "O Allah, I seek refuge in You from the male and female devils.",
    reference: "Sahih al-Bukhari 142 · Sahih Muslim 375 · Hisn al-Muslim 10",
  },
  {
    id: "leaving-toilet",
    category: "Home",
    title: "Leaving the toilet",
    arabic: "غُفْرَانَكَ",
    transliteration: "Ghufrānak.",
    english: "I seek Your forgiveness.",
    reference: "Sunan Abi Dawud 30 · Jami` at-Tirmidhi 7 · Hisn al-Muslim 11",
  },
  {
    id: "entering-mosque",
    category: "Mosque",
    title: "Entering the mosque",
    arabic: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ",
    transliteration: "Allāhumma-ftaḥ lī abwāba raḥmatik.",
    english: "O Allah, open for me the gates of Your mercy.",
    reference: "Sahih Muslim 713 · Hisn al-Muslim 20",
  },
  {
    id: "leaving-mosque",
    category: "Mosque",
    title: "Leaving the mosque",
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ",
    transliteration: "Allāhumma innī asʾaluka min faḍlik.",
    english: "O Allah, I ask You from Your bounty.",
    reference: "Sahih Muslim 713 · Hisn al-Muslim 21",
  },
  {
    id: "travel",
    category: "Travel",
    title: "Supplication for travel",
    arabic:
      "اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ، اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ مَا تَرْضَى، اللَّهُمَّ هَوِّنْ عَلَيْنَا سَفَرَنَا هَذَا وَاطْوِ عَنَّا بُعْدَهُ، اللَّهُمَّ أَنْتَ الصَّاحِبُ فِي السَّفَرِ، وَالْخَلِيفَةُ فِي الْأَهْلِ، اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ وَعْثَاءِ السَّفَرِ، وَكَآبَةِ الْمَنْظَرِ، وَسُوءِ الْمُنْقَلَبِ فِي الْمَالِ وَالْأَهْلِ",
    english:
      "Allah is the greatest, Allah is the greatest, Allah is the greatest. Glory be to Him Who has subjected this to us, and we could never have accomplished it by ourselves; and surely to our Lord we shall return. O Allah, we ask You on this journey of ours for righteousness and piety, and for deeds that please You. O Allah, make this journey easy for us and fold up its distance for us. O Allah, You are the Companion on the journey and the Guardian of the family. O Allah, I seek refuge in You from the hardship of travel, from a sorrowful sight, and from an ill return in wealth and family.",
    reference: "Sahih Muslim 1342 · Qur'an 43:13–14 · Hisn al-Muslim 206",
  },
  {
    id: "distress",
    category: "Distress & Forgiveness",
    title: "At times of distress",
    arabic:
      "لَا إِلَهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ السَّمَوَاتِ وَرَبُّ الْأَرْضِ وَرَبُّ الْعَرْشِ الْكَرِيمِ",
    transliteration:
      "Lā ilāha illa-llāhu-l-ʿaẓīmu-l-ḥalīm, lā ilāha illa-llāhu rabbu-l-ʿarshi-l-ʿaẓīm, lā ilāha illa-llāhu rabbu-s-samāwāti wa rabbu-l-arḍi wa rabbu-l-ʿarshi-l-karīm.",
    english:
      "None has the right to be worshipped except Allah, the Magnificent, the Forbearing. None has the right to be worshipped except Allah, Lord of the Magnificent Throne. None has the right to be worshipped except Allah, Lord of the heavens, Lord of the earth and Lord of the Noble Throne.",
    reference: "Sahih al-Bukhari 6346 · Sahih Muslim 2730 · Hisn al-Muslim 120",
  },
  {
    id: "anxiety",
    category: "Distress & Forgiveness",
    title: "For anxiety and sorrow",
    arabic:
      "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ",
    transliteration:
      "Allāhumma innī aʿūdhu bika mina-l-hammi wa-l-ḥazan, wa-l-ʿajzi wa-l-kasal, wa-l-bukhli wa-l-jubn, wa ḍalaʿi-d-dayni wa ghalabati-r-rijāl.",
    english:
      "O Allah, I seek refuge in You from anxiety and sorrow, from weakness and laziness, from miserliness and cowardice, from being overcome by debt and overpowered by men.",
    reference: "Sahih al-Bukhari 6369 · Hisn al-Muslim 121",
  },
  {
    id: "forgiveness",
    category: "Distress & Forgiveness",
    title: "Seeking forgiveness and repentance",
    arabic: "رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ",
    transliteration: "Rabbi-ghfir lī wa tub ʿalayya innaka anta-t-tawwābu-r-raḥīm.",
    english: "My Lord, forgive me and accept my repentance; verily You are the Accepter of repentance, the Most Merciful.",
    reference: "Sunan Abi Dawud 1516 · Jami` at-Tirmidhi 3434 · Hisn al-Muslim 251",
  },
  {
    id: "tasbih-light",
    category: "General Remembrance",
    title: "Two phrases light on the tongue",
    arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
    transliteration: "Subḥāna-llāhi wa bi-ḥamdih, subḥāna-llāhi-l-ʿaẓīm.",
    english: "Glory and praise be to Allah; glory be to Allah, the Magnificent.",
    reference: "Sahih al-Bukhari 6406 · Sahih Muslim 2694 · Hisn al-Muslim 254",
    note: "Light on the tongue, heavy on the scales, beloved to the Most Merciful.",
  },
  {
    id: "rabbana-atina",
    category: "General Remembrance",
    title: "Good in this world and the next",
    arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    transliteration: "Rabbanā ātinā fi-d-dunyā ḥasanatan wa fi-l-ākhirati ḥasanatan wa qinā ʿadhāba-n-nār.",
    english: "Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
    reference: "Qur'an 2:201 · Sahih al-Bukhari 6389",
  },
  {
    id: "clothes",
    category: "General Remembrance",
    title: "When wearing a garment",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي كَسَانِي هَذَا الثَّوْبَ وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ",
    transliteration: "Al-ḥamdu lillāhi-lladhī kasānī hādha-th-thawba wa razaqanīhi min ghayri ḥawlin minnī wa lā quwwah.",
    english: "All praise is for Allah Who has clothed me with this garment and provided it for me without any might or power on my part.",
    reference: "Sunan Abi Dawud 4023 · Hisn al-Muslim 6",
  },
];
