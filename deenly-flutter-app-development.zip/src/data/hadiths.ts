/**
 * Curated, well-attested hadith with their primary-source references.
 * Arabic text follows the standard printed editions; English renderings are
 * literal translations. Grades follow the collection (Bukhari/Muslim = Sahih by consensus;
 * Tirmidhi grade quoted from the compiler).
 */
export interface Hadith {
  id: string;
  arabic: string;
  english: string;
  narrator: string;
  collection: string;
  reference: string;
  grade: string;
}

export const HADITHS: Hadith[] = [
  {
    id: "bukhari-1",
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    english: "Actions are judged only by intentions, and every person shall have only what they intended.",
    narrator: "ʿUmar ibn al-Khaṭṭāb",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 1 · Sahih Muslim 1907",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "bukhari-13",
    arabic: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ",
    english: "None of you truly believes until he loves for his brother what he loves for himself.",
    narrator: "Anas ibn Mālik",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 13 · Sahih Muslim 45",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "bukhari-6018",
    arabic: "مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ",
    english: "Whoever believes in Allah and the Last Day, let him speak good or remain silent.",
    narrator: "Abū Hurayrah",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 6018 · Sahih Muslim 47",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "muslim-2699-knowledge",
    arabic: "وَمَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ",
    english: "Whoever treads a path in search of knowledge, Allah will make easy for him a path to Paradise.",
    narrator: "Abū Hurayrah",
    collection: "Sahih Muslim",
    reference: "Sahih Muslim 2699",
    grade: "Sahih",
  },
  {
    id: "bukhari-10",
    arabic: "الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ",
    english: "The Muslim is the one from whose tongue and hand the Muslims are safe.",
    narrator: "ʿAbdullāh ibn ʿAmr",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 10 · Sahih Muslim 40",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "bukhari-6114",
    arabic: "لَيْسَ الشَّدِيدُ بِالصُّرَعَةِ، إِنَّمَا الشَّدِيدُ الَّذِي يَمْلِكُ نَفْسَهُ عِنْدَ الْغَضَبِ",
    english:
      "The strong one is not the one who overpowers others in wrestling; the strong one is the one who controls himself when angry.",
    narrator: "Abū Hurayrah",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 6114 · Sahih Muslim 2609",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "tirmidhi-1924",
    arabic: "الرَّاحِمُونَ يَرْحَمُهُمُ الرَّحْمَنُ، ارْحَمُوا أَهْلَ الأَرْضِ يَرْحَمْكُمْ مَنْ فِي السَّمَاءِ",
    english:
      "The merciful are shown mercy by the Most Merciful. Be merciful to those on the earth and the One above the heavens will be merciful to you.",
    narrator: "ʿAbdullāh ibn ʿAmr",
    collection: "Jami` at-Tirmidhi",
    reference: "Jami` at-Tirmidhi 1924",
    grade: "Hasan Sahih (at-Tirmidhi)",
  },
  {
    id: "muslim-2564",
    arabic: "إِنَّ اللَّهَ لاَ يَنْظُرُ إِلَى صُوَرِكُمْ وَأَمْوَالِكُمْ، وَلَكِنْ يَنْظُرُ إِلَى قُلُوبِكُمْ وَأَعْمَالِكُمْ",
    english: "Indeed, Allah does not look at your appearances or your wealth, but He looks at your hearts and your deeds.",
    narrator: "Abū Hurayrah",
    collection: "Sahih Muslim",
    reference: "Sahih Muslim 2564",
    grade: "Sahih",
  },
  {
    id: "bukhari-6464",
    arabic: "أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ",
    english: "The most beloved of deeds to Allah are those done most consistently, even if they are few.",
    narrator: "ʿĀʾishah",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 6464 · Sahih Muslim 782",
    grade: "Sahih (agreed upon)",
  },
  {
    id: "muslim-2588",
    arabic:
      "مَا نَقَصَتْ صَدَقَةٌ مِنْ مَالٍ، وَمَا زَادَ اللَّهُ عَبْدًا بِعَفْوٍ إِلاَّ عِزًّا، وَمَا تَوَاضَعَ أَحَدٌ لِلَّهِ إِلاَّ رَفَعَهُ اللَّهُ",
    english:
      "Charity does not diminish wealth; Allah increases a servant in honour through pardoning; and no one humbles himself for Allah except that Allah raises him.",
    narrator: "Abū Hurayrah",
    collection: "Sahih Muslim",
    reference: "Sahih Muslim 2588",
    grade: "Sahih",
  },
  {
    id: "bukhari-39",
    arabic: "إِنَّ الدِّينَ يُسْرٌ، وَلَنْ يُشَادَّ الدِّينَ أَحَدٌ إِلاَّ غَلَبَهُ، فَسَدِّدُوا وَقَارِبُوا وَأَبْشِرُوا",
    english:
      "The religion is ease, and no one overburdens himself in the religion except that it overwhelms him. So be moderate, aim for what is right, and be glad.",
    narrator: "Abū Hurayrah",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 39",
    grade: "Sahih",
  },
  {
    id: "bukhari-5027",
    arabic: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    english: "The best of you are those who learn the Qur'an and teach it.",
    narrator: "ʿUthmān ibn ʿAffān",
    collection: "Sahih al-Bukhari",
    reference: "Sahih al-Bukhari 5027",
    grade: "Sahih",
  },
  {
    id: "muslim-2699-help",
    arabic: "وَاللَّهُ فِي عَوْنِ الْعَبْدِ مَا كَانَ الْعَبْدُ فِي عَوْنِ أَخِيهِ",
    english: "Allah is in the aid of His servant so long as the servant is in the aid of his brother.",
    narrator: "Abū Hurayrah",
    collection: "Sahih Muslim",
    reference: "Sahih Muslim 2699",
    grade: "Sahih",
  },
  {
    id: "muslim-2586",
    arabic:
      "مَثَلُ الْمُؤْمِنِينَ فِي تَوَادِّهِمْ وَتَرَاحُمِهِمْ وَتَعَاطُفِهِمْ مَثَلُ الْجَسَدِ، إِذَا اشْتَكَى مِنْهُ عُضْوٌ تَدَاعَى لَهُ سَائِرُ الْجَسَدِ بِالسَّهَرِ وَالْحُمَّى",
    english:
      "The likeness of the believers in their mutual love, mercy and compassion is that of one body: when a limb of it aches, the rest of the body responds with sleeplessness and fever.",
    narrator: "an-Nuʿmān ibn Bashīr",
    collection: "Sahih Muslim",
    reference: "Sahih Muslim 2586",
    grade: "Sahih",
  },
];

/** Deterministic "hadith of the day" so the same hadith shows all day, offline or online. */
export function hadithForDate(d = new Date()): Hadith {
  const start = Date.UTC(d.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - start) / 86_400_000);
  return HADITHS[dayOfYear % HADITHS.length];
}
