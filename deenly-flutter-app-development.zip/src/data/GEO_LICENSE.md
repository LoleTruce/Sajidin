# Bundled location dataset

`geo.json` is derived from the GeoNames gazetteer (https://www.geonames.org/):

* `cities15000.txt` — filtered to population ≥ 100,000 **plus** every national capital (PPLC), 6,366 entries.
  Fields kept: name, ISO country code, latitude, longitude (4 dp), population (thousands), capital flag.
* `countryInfo.txt` — all 252 countries/territories: ISO code, English name, continent.

Licence: Creative Commons Attribution 4.0 (CC BY 4.0). Attribution is shown in the country picker.
Regenerate with the script described in README §1d (Sajidin).
