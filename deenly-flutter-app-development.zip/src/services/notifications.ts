import { BRAND } from "../core/brand";
import type { PrayerName, PrayerTimesDay } from "../lib/prayer";
import { getServiceWorkerRegistration } from "./serviceWorker";

/**
 * Prayer reminders using the Web Notifications API.
 *
 * Honest limitation: browsers cannot run arbitrary timers while the page is closed.
 * Reminders fire reliably while Sajidin is open (foreground or background tab) and
 * when installed to the home screen on platforms that keep the page alive.
 * This is surfaced to the user in the settings UI.
 */
export type NotificationPermissionState = "granted" | "denied" | "default" | "unsupported";

export function notificationPermission(): NotificationPermissionState {
  if (typeof Notification === "undefined") return "unsupported";
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermissionState> {
  if (typeof Notification === "undefined") return "unsupported";
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

const timers = new Map<string, number>();

export function clearScheduled(): void {
  timers.forEach((id) => clearTimeout(id));
  timers.clear();
}

export interface ScheduleOptions {
  enabled: Record<PrayerName, boolean>;
  /** Minutes before the prayer to notify (0 = at adhan time) */
  leadMinutes: number;
}

/** (Re)schedules in-page notifications for every enabled prayer still ahead today. Returns the count scheduled. */
export function schedulePrayerNotifications(day: PrayerTimesDay, opts: ScheduleOptions, now = Date.now()): number {
  clearScheduled();
  if (notificationPermission() !== "granted") return 0;
  let count = 0;
  (Object.keys(day.times) as PrayerName[]).forEach((name) => {
    if (!opts.enabled[name]) return;
    const fireAt = day.times[name] - opts.leadMinutes * 60_000;
    const delay = fireAt - now;
    if (delay <= 0 || delay > 2_147_000_000) return; // past, or beyond setTimeout's 32-bit range
    const id = window.setTimeout(() => {
      show(name, opts.leadMinutes);
      timers.delete(name);
    }, delay);
    timers.set(name, id);
    count++;
  });
  return count;
}

function show(name: PrayerName, lead: number): void {
  const title = `${BRAND.name} · ${name}`;
  const body = lead > 0 ? `${name} is in ${lead} minute${lead === 1 ? "" : "s"}.` : `It is time for ${name}.`;
  const tag = `prayer-${name}`;
  // Android Chrome throws "Illegal constructor" for `new Notification`; the service worker path works everywhere.
  const reg = getServiceWorkerRegistration();
  if (reg?.active) {
    try {
      reg.active.postMessage({ type: "show-notification", title, body, tag });
      return;
    } catch {
      /* fall through to the page API */
    }
  }
  try {
    const n = new Notification(title, { body, tag, silent: false });
    n.onclick = () => {
      window.focus();
      n.close();
    };
  } catch {
    /* No supported notification path in this browser; the settings sheet already explains the limitation. */
  }
}

/** True when some notification display path exists (page API or an active service worker). */
export function canDisplayNotifications(): boolean {
  if (typeof Notification === "undefined") return false;
  if (getServiceWorkerRegistration()?.active) return true;
  try {
    // Feature-detect the page constructor without showing anything: Android Chrome throws here.
    return typeof Notification === "function" && !/Android/i.test(navigator.userAgent);
  } catch {
    return false;
  }
}
