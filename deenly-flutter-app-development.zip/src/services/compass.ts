import { normalizeDegrees } from "../lib/qibla";

/**
 * Heading provider built on DeviceOrientation.
 *  - iOS Safari exposes `webkitCompassHeading` (a fused compass heading) and requires
 *    an explicit permission request from a user gesture.
 *  - Android Chrome exposes `deviceorientationabsolute` whose `alpha` is referenced to
 *    magnetic north; we convert to a clockwise heading and compensate for screen rotation.
 * The raw magnetometer is never read directly — the platform's fused orientation is used,
 * and callers apply magnetic declination to obtain a true-north heading.
 */
export type CompassStatus = "idle" | "requesting" | "active" | "denied" | "unsupported" | "no-data";

export interface HeadingSample {
  /** Magnetic heading in degrees clockwise (0 = magnetic north) */
  heading: number;
  /** Accuracy in degrees if reported (iOS); undefined otherwise */
  accuracy?: number;
  absolute: boolean;
}

type IOSOrientationEvent = DeviceOrientationEvent & { webkitCompassHeading?: number; webkitCompassAccuracy?: number };
type Ctor = typeof DeviceOrientationEvent & { requestPermission?: () => Promise<"granted" | "denied"> };

export function compassSupported(): boolean {
  return typeof window !== "undefined" && typeof (window as { DeviceOrientationEvent?: unknown }).DeviceOrientationEvent === "function";
}

export function needsPermissionGesture(): boolean {
  const ctor = (typeof DeviceOrientationEvent !== "undefined" ? DeviceOrientationEvent : undefined) as Ctor | undefined;
  return typeof ctor?.requestPermission === "function";
}

function screenAngle(): number {
  try {
    if (screen.orientation && typeof screen.orientation.angle === "number") return screen.orientation.angle;
  } catch {
    /* ignore */
  }
  const legacy = (window as unknown as { orientation?: number }).orientation;
  return typeof legacy === "number" ? legacy : 0;
}

export function headingFromEvent(e: IOSOrientationEvent): HeadingSample | null {
  if (typeof e.webkitCompassHeading === "number" && !Number.isNaN(e.webkitCompassHeading)) {
    return { heading: normalizeDegrees(e.webkitCompassHeading), accuracy: e.webkitCompassAccuracy, absolute: true };
  }
  if (typeof e.alpha === "number" && !Number.isNaN(e.alpha)) {
    // alpha is counter-clockwise from north → heading is clockwise; compensate for screen rotation.
    return { heading: normalizeDegrees(360 - e.alpha + screenAngle()), absolute: !!e.absolute };
  }
  return null;
}

export interface CompassSubscription {
  stop: () => void;
}

/**
 * Starts listening for heading updates. Resolves with a subscription or a status explaining
 * why the compass isn't available. Must be called from a user gesture on iOS.
 */
export async function startCompass(
  onSample: (s: HeadingSample) => void,
  onStatus: (s: CompassStatus) => void,
): Promise<CompassSubscription | null> {
  if (!compassSupported()) {
    onStatus("unsupported");
    return null;
  }
  const ctor = DeviceOrientationEvent as Ctor;
  if (typeof ctor.requestPermission === "function") {
    onStatus("requesting");
    try {
      const res = await ctor.requestPermission();
      if (res !== "granted") {
        onStatus("denied");
        return null;
      }
    } catch {
      onStatus("denied");
      return null;
    }
  }

  let gotData = false;
  let usingAbsolute = false;
  const handler = (ev: Event) => {
    const sample = headingFromEvent(ev as IOSOrientationEvent);
    if (!sample) return;
    if (ev.type === "deviceorientationabsolute") usingAbsolute = true;
    // Prefer the absolute event when both fire (Android).
    if (ev.type === "deviceorientation" && usingAbsolute && !(ev as IOSOrientationEvent).webkitCompassHeading) return;
    if (!gotData) {
      gotData = true;
      onStatus("active");
    }
    onSample(sample);
  };

  window.addEventListener("deviceorientationabsolute", handler as EventListener, true);
  window.addEventListener("deviceorientation", handler as EventListener, true);

  const timeout = window.setTimeout(() => {
    if (!gotData) onStatus("no-data");
  }, 3500);

  return {
    stop: () => {
      clearTimeout(timeout);
      window.removeEventListener("deviceorientationabsolute", handler as EventListener, true);
      window.removeEventListener("deviceorientation", handler as EventListener, true);
    },
  };
}
