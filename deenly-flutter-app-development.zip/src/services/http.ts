export class HttpError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
    public readonly kind: "network" | "timeout" | "http" | "parse" | "aborted" = "http",
  ) {
    super(message);
    this.name = "HttpError";
  }
}

export interface FetchOptions {
  signal?: AbortSignal;
  timeoutMs?: number;
  headers?: Record<string, string>;
}

/** fetch + JSON with timeout, abort support and typed error classification. */
export async function fetchJson<T>(url: string, opts: FetchOptions = {}): Promise<T> {
  const { timeoutMs = 12_000, signal, headers } = opts;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new HttpError("Request timed out", undefined, "timeout")), timeoutMs);
  const onOuterAbort = () => controller.abort(new HttpError("Aborted", undefined, "aborted"));
  signal?.addEventListener("abort", onOuterAbort, { once: true });

  try {
    const res = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json", ...headers } });
    if (!res.ok) throw new HttpError(`Service responded with ${res.status}`, res.status, "http");
    try {
      return (await res.json()) as T;
    } catch {
      throw new HttpError("Could not parse response", res.status, "parse");
    }
  } catch (e) {
    if (e instanceof HttpError) throw e;
    if (controller.signal.aborted && controller.signal.reason instanceof HttpError) throw controller.signal.reason;
    if (typeof navigator !== "undefined" && !navigator.onLine)
      throw new HttpError("You appear to be offline", undefined, "network");
    throw new HttpError("Network request failed", undefined, "network");
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuterAbort);
  }
}

export function describeError(e: unknown): string {
  if (e instanceof HttpError) {
    switch (e.kind) {
      case "timeout":
        return "The request took too long. Please try again.";
      case "network":
        return "No connection. Check your network and retry.";
      case "parse":
        return "Received an unexpected response from the server.";
      case "http":
        return e.status === 429 ? "Too many requests — please wait a moment." : `Server error (${e.status ?? "?"}).`;
      default:
        return e.message;
    }
  }
  if (e instanceof Error) return e.message;
  return "Something went wrong.";
}
