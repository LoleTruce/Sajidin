export interface Coords {
  lat: number;
  lng: number;
  /** Human label if known (e.g. "London, UK" or "Current location") */
  label?: string;
  /** epoch ms when obtained */
  at: number;
  source: "device" | "manual" | "cached";
}

export type GeoErrorKind = "unsupported" | "denied" | "unavailable" | "timeout";

export class GeoError extends Error {
  constructor(public readonly kind: GeoErrorKind) {
    super(kind);
  }
}

export function getDeviceLocation(timeoutMs = 15_000): Promise<Coords> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      reject(new GeoError("unsupported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          lat: +pos.coords.latitude.toFixed(5),
          lng: +pos.coords.longitude.toFixed(5),
          label: "Current location",
          at: Date.now(),
          source: "device",
        }),
      (err) => {
        if (err.code === err.PERMISSION_DENIED) reject(new GeoError("denied"));
        else if (err.code === err.TIMEOUT) reject(new GeoError("timeout"));
        else reject(new GeoError("unavailable"));
      },
      { enableHighAccuracy: false, timeout: timeoutMs, maximumAge: 5 * 60_000 },
    );
  });
}

export function describeGeoError(e: unknown): string {
  if (e instanceof GeoError) {
    switch (e.kind) {
      case "denied":
        return "Location permission was denied. You can set your location manually.";
      case "unsupported":
        return "Location services aren't available in this browser.";
      case "timeout":
        return "Finding your location took too long.";
      default:
        return "Your location is currently unavailable.";
    }
  }
  return "Could not determine your location.";
}
