import geo from "../data/geo.json";

/**
 * Offline country/city dataset for manual location selection.
 *
 * Source: GeoNames `cities15000` + `countryInfo` (CC BY 4.0), filtered to every country/territory
 * (252) and cities with population ≥ 100,000 plus all national capitals (6,366 cities, 244 countries
 * have at least one entry). Coordinates are GeoNames values rounded to 4 dp (~11 m).
 * Cities outside this set are resolved online through AlAdhan's city lookup (see `resolveCityOnline`).
 */
export interface Country {
  code: string; // ISO 3166-1 alpha-2
  name: string;
  continent: string; // AF, AS, EU, NA, OC, SA, AN
}

export interface City {
  name: string;
  country: string;
  lat: number;
  lng: number;
  /** Population in thousands */
  popK: number;
  capital: boolean;
}

interface GeoFile {
  source: string;
  countries: { c: string; n: string; k: string }[];
  cities: [string, string, number, number, number, number][];
}

const file = geo as unknown as GeoFile;

export const GEO_SOURCE = file.source;

export const COUNTRIES: Country[] = file.countries.map((c) => ({ code: c.c, name: c.n, continent: c.k }));

const countryByCode = new Map(COUNTRIES.map((c) => [c.code, c]));
const citiesByCountry = new Map<string, City[]>();
for (const [name, country, lat, lng, popK, cap] of file.cities) {
  const list = citiesByCountry.get(country) ?? [];
  list.push({ name, country, lat, lng, popK, capital: cap === 1 });
  citiesByCountry.set(country, list);
}

export function getCountry(code: string): Country | undefined {
  return countryByCode.get(code);
}

/** Cities for a country, capital first then by population (as stored). */
export function citiesFor(countryCode: string): City[] {
  const list = citiesByCountry.get(countryCode) ?? [];
  return [...list].sort((a, b) => Number(b.capital) - Number(a.capital) || b.popK - a.popK);
}

export function searchCities(countryCode: string, query: string): City[] {
  const q = normalise(query);
  const list = citiesFor(countryCode);
  if (!q) return list;
  return list.filter((c) => normalise(c.name).includes(q));
}

export function searchCountries(query: string): Country[] {
  const q = normalise(query);
  if (!q) return COUNTRIES;
  return COUNTRIES.filter((c) => normalise(c.name).includes(q) || c.code.toLowerCase() === q);
}

/** Finite and within geographic bounds. */
export function isValidCoordinate(lat: unknown, lng: unknown): lat is number {
  return typeof lat === "number" && typeof lng === "number" && Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
}

function normalise(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

/** Best-effort country guess from the browser locale (e.g. "en-GB" → GB). Used only to pre-select the picker. */
export function guessCountryFromLocale(): string | null {
  try {
    const locales = typeof navigator !== "undefined" ? navigator.languages ?? [navigator.language] : [];
    for (const l of locales) {
      const region = new Intl.Locale(l).region;
      if (region && countryByCode.has(region)) return region;
    }
  } catch {
    /* Intl.Locale unsupported */
  }
  return null;
}
