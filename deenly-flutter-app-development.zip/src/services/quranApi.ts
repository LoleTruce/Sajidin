import { fetchJson } from "./http";
import { idbGet, idbSet } from "./idb";

/**
 * Quran data source: Al Quran Cloud (api.alquran.cloud) — a public, documented,
 * no-authentication API serving the Tanzil Uthmani text and licensed translations.
 * Audio is served from the Islamic Network CDN that accompanies it.
 */
const BASE = "https://api.alquran.cloud/v1";
export const AUDIO_CDN = "https://cdn.islamic.network/quran/audio/128";

export interface SurahMeta {
  number: number;
  name: string; // Arabic
  englishName: string; // transliteration
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: "Meccan" | "Medinan";
}

export interface Ayah {
  /** Global ayah number 1..6236 (used for audio URLs) */
  number: number;
  numberInSurah: number;
  arabic: string;
  translation: string;
  transliteration?: string;
  juz?: number;
  page?: number;
}

export interface SurahContent {
  meta: SurahMeta;
  ayahs: Ayah[];
  translationEdition: string;
  fetchedAt: number;
}

export const TRANSLATIONS = [
  { id: "en.sahih", name: "Saheeh International" },
  { id: "en.asad", name: "Muhammad Asad" },
  { id: "en.pickthall", name: "Pickthall" },
  { id: "en.yusufali", name: "Yusuf Ali" },
  { id: "ur.jalandhry", name: "Urdu · Jalandhry" },
  { id: "ur.ahmedali", name: "Urdu · Ahmed Ali" },
  { id: "tr.diyanet", name: "Türkçe · Diyanet İşleri" },
  { id: "id.indonesian", name: "Indonesia · Kemenag" },
] as const;

export const RECITERS = [
  { id: "ar.alafasy", name: "Mishary Rashid Alafasy" },
  { id: "ar.abdurrahmaansudais", name: "Abdur-Rahman as-Sudais" },
  { id: "ar.husary", name: "Mahmoud Khalil Al-Husary" },
  { id: "ar.minshawi", name: "Mohamed Siddiq El-Minshawi" },
  { id: "ar.abdulbasitmurattal", name: "Abdul Basit (Murattal)" },
] as const;

interface ApiEnvelope<T> {
  code: number;
  status: string;
  data: T;
}

interface ApiEdition {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: "Meccan" | "Medinan";
  edition: { identifier: string };
  ayahs: { number: number; numberInSurah: number; text: string; juz: number; page: number }[];
}

export function parseSurahList(json: ApiEnvelope<SurahMeta[]>): SurahMeta[] {
  if (!json || json.code !== 200 || !Array.isArray(json.data) || json.data.length !== 114) {
    throw new Error("Unexpected Surah list response");
  }
  return json.data.map((s) => ({
    number: Number(s.number),
    name: String(s.name),
    englishName: String(s.englishName),
    englishNameTranslation: String(s.englishNameTranslation),
    numberOfAyahs: Number(s.numberOfAyahs),
    revelationType: s.revelationType === "Medinan" ? "Medinan" : "Meccan",
  }));
}

export function parseSurahContent(json: ApiEnvelope<ApiEdition[]>, translationEdition: string): SurahContent {
  if (!json || json.code !== 200 || !Array.isArray(json.data) || json.data.length < 2) {
    throw new Error("Unexpected Surah content response");
  }
  const arabic = json.data.find((e) => e.edition.identifier === "quran-uthmani");
  const trans = json.data.find((e) => e.edition.identifier === translationEdition);
  const translit = json.data.find((e) => e.edition.identifier === "en.transliteration");
  if (!arabic || !trans || arabic.ayahs.length !== trans.ayahs.length) throw new Error("Editions do not align");
  return {
    meta: {
      number: arabic.number,
      name: arabic.name,
      englishName: arabic.englishName,
      englishNameTranslation: arabic.englishNameTranslation,
      numberOfAyahs: arabic.numberOfAyahs,
      revelationType: arabic.revelationType,
    },
    ayahs: arabic.ayahs.map((a, i) => ({
      number: a.number,
      numberInSurah: a.numberInSurah,
      arabic: a.text,
      translation: trans.ayahs[i].text,
      transliteration: translit?.ayahs[i]?.text,
      juz: a.juz,
      page: a.page,
    })),
    translationEdition,
    fetchedAt: Date.now(),
  };
}

export async function getSurahList(signal?: AbortSignal): Promise<{ list: SurahMeta[]; fromCache: boolean }> {
  const cached = await idbGet<SurahMeta[]>("surah-list");
  if (cached?.length === 114) return { list: cached, fromCache: true };
  const json = await fetchJson<ApiEnvelope<SurahMeta[]>>(`${BASE}/surah`, { signal });
  const list = parseSurahList(json);
  void idbSet("surah-list", list);
  return { list, fromCache: false };
}

export async function getSurah(
  number: number,
  translationEdition: string,
  signal?: AbortSignal,
): Promise<{ content: SurahContent; fromCache: boolean }> {
  const key = `surah:${number}:${translationEdition}`;
  const cached = await idbGet<SurahContent>(key);
  if (cached) return { content: cached, fromCache: true };
  const editions = `quran-uthmani,${translationEdition},en.transliteration`;
  const json = await fetchJson<ApiEnvelope<ApiEdition[]>>(`${BASE}/surah/${number}/editions/${editions}`, { signal });
  const content = parseSurahContent(json, translationEdition);
  void idbSet(key, content);
  return { content, fromCache: false };
}

export function ayahAudioUrl(reciter: string, globalAyahNumber: number): string {
  return `${AUDIO_CDN}/${reciter}/${globalAyahNumber}.mp3`;
}
