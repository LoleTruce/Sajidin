import { PRAYER_NAMES, type PrayerTimesDay, timeStringToEpoch } from "../lib/prayer";
import { fetchJson } from "./http";

const BASE = "https://api.aladhan.com/v1";

export const CALCULATION_METHODS: { id: number; name: string }[] = [
  { id: 3, name: "Muslim World League" },
  { id: 2, name: "ISNA (North America)" },
  { id: 5, name: "Egyptian General Authority" },
  { id: 4, name: "Umm al-Qura, Makkah" },
  { id: 1, name: "University of Islamic Sciences, Karachi" },
  { id: 8, name: "Gulf Region" },
  { id: 9, name: "Kuwait" },
  { id: 10, name: "Qatar" },
  { id: 11, name: "MUIS Singapore" },
  { id: 12, name: "UOIF France" },
  { id: 13, name: "Diyanet Turkey" },
  { id: 14, name: "Spiritual Administration, Russia" },
  { id: 15, name: "Moonsighting Committee" },
  { id: 16, name: "Dubai" },
  { id: 17, name: "JAKIM Malaysia" },
  { id: 20, name: "KEMENAG Indonesia" },
  { id: 21, name: "Morocco" },
  { id: 22, name: "Portugal" },
  { id: 23, name: "Jordan" },
];

export interface AladhanTimingsResponse {
  code: number;
  status: string;
  data: {
    timings: Record<string, string>;
    date: {
      gregorian: { date: string };
      hijri: { day: string; month: { en: string; ar?: string }; year: string; weekday: { en: string } };
    };
    meta: {
      latitude: number;
      longitude: number;
      timezone: string;
      method: { id: number; name: string };
    };
  };
}

export interface FetchTimingsParams {
  lat: number;
  lng: number;
  method: number;
  /** JS Date for the requested day */
  date: Date;
}

export interface TimingsResult {
  day: PrayerTimesDay;
  meta: { lat: number; lng: number; timezone: string };
}

/** Converts a Date into the DD-MM-YYYY format AlAdhan expects. */
export function ddmmyyyy(date: Date): string {
  const d = String(date.getDate()).padStart(2, "0");
  const m = String(date.getMonth() + 1).padStart(2, "0");
  return `${d}-${m}-${date.getFullYear()}`;
}

/** Transforms a raw AlAdhan response into our typed, epoch-based model. Throws on malformed data. */
export function parseTimings(json: AladhanTimingsResponse): TimingsResult {
  if (!json || json.code !== 200 || !json.data?.timings || !json.data.meta?.timezone) {
    throw new Error("Malformed response from prayer times service");
  }
  const { timings, meta, date } = json.data;
  const [dd, mm, yyyy] = date.gregorian.date.split("-");
  const dateISO = `${yyyy}-${mm}-${dd}`;
  const times = {} as PrayerTimesDay["times"];
  for (const name of PRAYER_NAMES) {
    const raw = timings[name];
    if (!raw || !/^\d{1,2}:\d{2}/.test(raw)) throw new Error(`Missing timing for ${name}`);
    times[name] = timeStringToEpoch(raw, dateISO, meta.timezone);
  }
  return {
    day: {
      date: dateISO,
      times,
      timezone: meta.timezone,
      method: meta.method?.name,
      hijri: date.hijri
        ? { day: date.hijri.day, month: date.hijri.month.en, year: date.hijri.year, weekday: date.hijri.weekday.en }
        : undefined,
    },
    meta: { lat: meta.latitude, lng: meta.longitude, timezone: meta.timezone },
  };
}

export async function fetchTimings(p: FetchTimingsParams, signal?: AbortSignal): Promise<TimingsResult> {
  const url = `${BASE}/timings/${ddmmyyyy(p.date)}?latitude=${p.lat}&longitude=${p.lng}&method=${p.method}`;
  const json = await fetchJson<AladhanTimingsResponse>(url, { signal });
  return parseTimings(json);
}

/** Manual location: resolves a city/country to timings (and coordinates in meta). */
export async function fetchTimingsByCity(
  city: string,
  country: string,
  method: number,
  date: Date,
  signal?: AbortSignal,
): Promise<TimingsResult> {
  const url = `${BASE}/timingsByCity/${ddmmyyyy(date)}?city=${encodeURIComponent(city)}&country=${encodeURIComponent(
    country,
  )}&method=${method}`;
  const json = await fetchJson<AladhanTimingsResponse>(url, { signal });
  return parseTimings(json);
}
