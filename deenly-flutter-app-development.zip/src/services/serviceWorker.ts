/**
 * Registers the app-shell service worker (public/sw.js). Failure is non-fatal: without it the
 * app still works online, and in-app data caches (localStorage/IndexedDB) still apply.
 */
export type SwStatus = "unsupported" | "registered" | "failed" | "skipped";

let registration: ServiceWorkerRegistration | null = null;

export async function registerServiceWorker(): Promise<SwStatus> {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return "unsupported";
  if (typeof window === "undefined" || !/^https?:$/.test(window.location.protocol)) return "skipped";
  try {
    const base = new URL(".", window.location.href);
    registration = await navigator.serviceWorker.register(new URL("sw.js", base).toString(), { scope: base.pathname });
    return "registered";
  } catch {
    return "failed"; // e.g. sw.js not served at this origin, or insecure context
  }
}

export function getServiceWorkerRegistration(): ServiceWorkerRegistration | null {
  return registration;
}
